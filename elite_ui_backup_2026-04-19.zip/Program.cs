using System.Diagnostics;

using System.Diagnostics;

namespace Project
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            foreach (var proc in Process.GetProcessesByName(
     System.IO.Path.GetFileNameWithoutExtension(Application.ExecutablePath)))
            {
                if (proc.Id != Environment.ProcessId)
                {
                    proc.Kill();
                    proc.WaitForExit(3000); // wait up to 3 seconds
                }
            }

            ApplicationConfiguration.Initialize();
            Application.Run(new SplashScreen());
        }
    }
}