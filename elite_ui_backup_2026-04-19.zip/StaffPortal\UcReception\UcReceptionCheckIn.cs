using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Project.UcReception
{
    public partial class UcReceptionCheckIn : UserControl
    {
        public UcReceptionCheckIn()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            int arrivalsToday = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_reservations WHERE CheckInDate = CURDATE() OR VisitDate = CURDATE();");
            int checkedIn = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_reservations WHERE Status = 'Checked-In';");
            int confirmed = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_reservations WHERE Status = 'Confirmed';");
            int dayVisitWalkins = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_reservations WHERE BookingType = 'Day Visit' AND VisitDate = CURDATE();");

            var pendingCheckIns = StaffPortalDb.GetTable(@"
SELECT r.ReservationID AS `Reservation Ref`,
       CONCAT(g.FirstName, ' ', g.LastName) AS `Guest`,
       COALESCE(c.CabinName, 'Day Visit / Experience') AS `Cabin or Visit`,
       COALESCE(r.ArrivalTime, 'Front Desk Confirmation') AS `Arrival Time`,
       r.BookingType AS `Booking Type`,
       r.Status
FROM tbl_reservations r
LEFT JOIN tbl_guests g ON g.GuestID = r.GuestID
LEFT JOIN tbl_cabins c ON c.CabinID = r.CabinID
WHERE r.Status IN ('Confirmed','Pending')
  AND (r.CheckInDate = CURDATE() OR r.VisitDate = CURDATE())
ORDER BY r.CreatedAt DESC;");

            var actionCard = StaffPortalUi.ActionCard("Process Check-In", panel =>
            {
                var lbl = new Label
                {
                    Text = "Enter a reservation reference to mark it as Checked-In.",
                    Font = WildNestUI.FontBody(10f),
                    ForeColor = WildNestUI.TextDark,
                    BackColor = Color.Transparent,
                    AutoSize = true,
                    Location = new Point(18, 62)
                };
                var tb = new TextBox
                {
                    PlaceholderText = "Reservation ID (e.g. WN-...)",
                    Font = WildNestUI.FontBody(10f),
                    BorderStyle = BorderStyle.FixedSingle,
                    Location = new Point(18, 92),
                    Width = 280
                };
                var btn = WildNestUI.BtnPrimary("Mark Checked-In", 150, 30);
                btn.Location = new Point(310, 90);
                btn.Click += (s, e) =>
                {
                    if (string.IsNullOrWhiteSpace(tb.Text))
                    {
                        MessageBox.Show("Enter a reservation reference first.");
                        return;
                    }

                    int affected = 0;
                    try
                    {
                        StaffPortalDb.Execute(
                            "UPDATE tbl_reservations SET Status='Checked-In' WHERE ReservationID=@id;",
                            new MySqlParameter("@id", tb.Text.Trim()));
                        affected = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_reservations WHERE ReservationID=@id AND Status='Checked-In';",
                            new MySqlParameter("@id", tb.Text.Trim()));
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Check-in failed: " + ex.Message);
                        return;
                    }

                    MessageBox.Show(affected > 0
                        ? "Reservation marked as Checked-In."
                        : "No matching reservation was updated.");
                    Render();
                };

                panel.Controls.Add(lbl);
                panel.Controls.Add(tb);
                panel.Controls.Add(btn);
            }, 160);

            var page = StaffPortalUi.BuildPage(
                "Check-In",
                "Reception check-in view powered by tbl_reservations and tbl_guests.",
                new List<Control>
                {
                    StaffPortalUi.StatsRow(
                        (arrivalsToday.ToString(), "Due Today", WildNestUI.Green),
                        (checkedIn.ToString(), "Already Checked-In", WildNestUI.Blue),
                        (confirmed.ToString(), "Confirmed Reservations", WildNestUI.Amber),
                        (dayVisitWalkins.ToString(), "Day Visits Today", WildNestUI.Green)),
                    actionCard,
                    StaffPortalUi.GridCard("Pending Check-Ins", pendingCheckIns, "No pending check-ins for today.")
                });

            Controls.Add(page);
        }
    }
}
