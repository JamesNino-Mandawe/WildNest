using System;
using System.Drawing;
using System.Windows.Forms;

namespace Project.UcAdministrator
{
    /// <summary>
    /// Administrator shell dashboard.
    /// Sidebar: WILDNEST branding, nav buttons, sign-out.
    /// Content area: loads child UserControls per nav click.
    /// All visual style via WildNestUI helpers.
    /// All original logic (navigation, sign-out, chat) preserved.
    /// </summary>
    public partial class UcAdminDashboard : UserControl
    {
        private StaffDashboard _parent;
        private Button         _activeBtn;
        private Button         _btnNavStaffChat = null!;
        private string         _displayName     = "Admin User";

        public UcAdminDashboard()
        {
            InitializeComponent();
            this.Load += OnLoad;
        }

        // ── Public API (called by StaffDashboard) ─────────────────────────────
        public void SetParentDashboard(StaffDashboard parent) => _parent = parent;

        public void SetDisplayName(string name)
        {
            _displayName       = name;
            lblSideUser.Text   = name;
            lblSideRole.Text   = "System Administrator";
        }

        // ── Load ──────────────────────────────────────────────────────────────
        private void OnLoad(object sender, EventArgs e)
        {
            BuildSidebar();
            WireNavButtons();
            WildNestUI.SetActive(ref _activeBtn, btnNavDashboard);
            LoadPage(new UcAdminDashboardContent());
        }

        // ── Sidebar layout ────────────────────────────────────────────────────
        private void BuildSidebar()
        {
            // Dynamically create the Staff Chat button (same pattern as original)
            _btnNavStaffChat = new Button
            {
                Text = "💬  Staff Chat",
                Name = "btnNavStaffChat"
            };
            pnlAdminSidebar.Controls.Add(_btnNavStaffChat);

            Button[] navBtns =
            {
                btnNavDashboard, btnNavCabins, btnNavReservations,
                btnNavGuests,    btnNavAnimals, btnNavEncounters,
                btnNavUsers,     btnNavBills,   _btnNavStaffChat
            };

            WildNestUI.StyleSidebar(
                pnlAdminSidebar, pnlAdminContent,
                lblSideTitle, lblSideRole, lblSideUser,
                navBtns, btnSignOut,
                ref _activeBtn);

            // Fix nav button labels to match prototype icons
            btnNavDashboard.Text    = "📊  Dashboard";
            btnNavCabins.Text       = "🏡  Cabin Management";
            btnNavReservations.Text = "📅  Reservations";
            btnNavGuests.Text       = "👤  Guest Profiles";
            btnNavAnimals.Text      = "🦁  Animal Registry";
            btnNavEncounters.Text   = "🎯  Encounter Packages";
            btnNavUsers.Text        = "👥  User Management";
            btnNavBills.Text        = "🧾  Billing & Reports";
            _btnNavStaffChat.Text   = "💬  Staff Chat";
        }

        // ── Navigation wiring (all original logic preserved) ──────────────────
        private void WireNavButtons()
        {
            btnNavDashboard.Click    += (s, e) => Navigate(btnNavDashboard,    new UcAdminDashboardContent());
            btnNavCabins.Click       += (s, e) => Navigate(btnNavCabins,       new UcAdminCabins());
            btnNavReservations.Click += (s, e) => Navigate(btnNavReservations, new UcAdminReservations());
            btnNavGuests.Click       += (s, e) => Navigate(btnNavGuests,       new UcAdminGuests());
            btnNavAnimals.Click      += (s, e) => Navigate(btnNavAnimals,      new UcAdminAnimals());
            btnNavEncounters.Click   += (s, e) => Navigate(btnNavEncounters,   new UcAdminEncounters());
            btnNavUsers.Click        += (s, e) => Navigate(btnNavUsers,        new UcAdminUsers());
            btnNavBills.Click        += (s, e) => Navigate(btnNavBills,        new UcAdminBills());
            btnSignOut.Click         += (s, e) => _parent?.SignOut();

            // Staff Chat wired after sidebar build (original pattern)
            this.Load += (s, e) =>
            {
                if (_btnNavStaffChat != null)
                    _btnNavStaffChat.Click += (ss, ee) =>
                        Navigate(_btnNavStaffChat,
                            new Project.UcStaffChat("Administrator", _displayName));
            };
        }

        // ── Helpers ───────────────────────────────────────────────────────────
        private void Navigate(Button btn, UserControl uc)
        {
            WildNestUI.SetActive(ref _activeBtn, btn);
            LoadPage(uc);
        }

        private void LoadPage(UserControl uc)
        {
            pnlAdminContent.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            pnlAdminContent.Controls.Add(uc);
            uc.BringToFront();
        }
    }
}
