using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcTourGuide
{
    public partial class UcTourGuideHistory : UserControl
    {
        public UcTourGuideHistory()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            int pastBookings = StaffPortalDb.Count(@"
SELECT COUNT(DISTINCT be.ReservationID)
FROM tbl_bookingexperiences be
JOIN tbl_reservations r ON r.ReservationID = be.ReservationID
WHERE COALESCE(r.VisitDate, r.CheckInDate) < CURDATE();");
            int guestsServed = StaffPortalDb.Count(@"
SELECT COALESCE(SUM(be.Quantity),0)
FROM tbl_bookingexperiences be
JOIN tbl_reservations r ON r.ReservationID = be.ReservationID
WHERE COALESCE(r.VisitDate, r.CheckInDate) < CURDATE();");
            decimal historicRevenue = StaffPortalDb.Sum(@"
SELECT COALESCE(SUM(be.TotalCost),0)
FROM tbl_bookingexperiences be
JOIN tbl_reservations r ON r.ReservationID = be.ReservationID
WHERE COALESCE(r.VisitDate, r.CheckInDate) < CURDATE();");
            int experienceCount = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_experiences;");

            var history = StaffPortalDb.GetTable(@"
SELECT r.ReservationID AS `Reservation Ref`,
       CONCAT(g.FirstName, ' ', g.LastName) AS `Guest`,
       GROUP_CONCAT(e.ExperienceName SEPARATOR ', ') AS `Experience Lineup`,
       SUM(be.Quantity) AS `Attendees`,
       COALESCE(DATE_FORMAT(r.VisitDate, '%Y-%m-%d'), DATE_FORMAT(r.CheckInDate, '%Y-%m-%d')) AS `Completed Date`,
       r.Status
FROM tbl_bookingexperiences be
JOIN tbl_reservations r ON r.ReservationID = be.ReservationID
JOIN tbl_guests g ON g.GuestID = r.GuestID
JOIN tbl_experiences e ON e.ExperienceID = be.ExperienceID
WHERE COALESCE(r.VisitDate, r.CheckInDate) < CURDATE()
GROUP BY r.ReservationID, g.FirstName, g.LastName, r.VisitDate, r.CheckInDate, r.Status
ORDER BY `Completed Date` DESC;");

            Controls.Add(StaffPortalUi.BuildPage(
                "Tour History",
                "Historical experience manifest derived from past reservation dates.",
                new List<Control>
                {
                    StaffPortalUi.StatsRow(
                        (pastBookings.ToString(), "Past Experience Bookings", WildNestUI.Blue),
                        (guestsServed.ToString(), "Guests Served", WildNestUI.Green),
                        (StaffPortalUi.Peso(historicRevenue), "Historical Revenue", WildNestUI.Amber),
                        (experienceCount.ToString(), "Experience Types", WildNestUI.Green)),
                    StaffPortalUi.GridCard("Past Experience History", history, "No past experience history found yet.")
                }));
        }
    }
}
