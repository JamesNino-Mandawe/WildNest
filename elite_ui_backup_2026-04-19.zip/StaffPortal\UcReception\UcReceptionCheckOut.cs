using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Project.UcReception
{
    public partial class UcReceptionCheckOut : UserControl
    {
        public UcReceptionCheckOut()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            int dueToday = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_reservations WHERE CheckOutDate = CURDATE();");
            int paidToday = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_payments WHERE DATE(PaidAt) = CURDATE();");
            decimal revenueToday = StaffPortalDb.Sum("SELECT COALESCE(SUM(Amount),0) FROM tbl_payments WHERE DATE(PaidAt) = CURDATE();");
            int unpaid = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_payments WHERE Status IN ('Pending','Unpaid');");

            var departures = StaffPortalDb.GetTable(@"
SELECT r.ReservationID AS `Reservation Ref`,
       CONCAT(g.FirstName, ' ', g.LastName) AS `Guest`,
       c.CabinName AS `Cabin`,
       r.TotalAmount AS `Reservation Total`,
       COALESCE(p.Amount, 0) AS `Payment Amount`,
       COALESCE(p.Status, 'No Payment Record') AS `Payment Status`,
       r.Status AS `Reservation Status`
FROM tbl_reservations r
LEFT JOIN tbl_guests g ON g.GuestID = r.GuestID
LEFT JOIN tbl_cabins c ON c.CabinID = r.CabinID
LEFT JOIN tbl_payments p ON p.ReservationID = r.ReservationID
WHERE r.CheckOutDate = CURDATE() OR r.Status = 'Checked-In'
ORDER BY r.CheckOutDate, r.CreatedAt DESC;");

            var actionCard = StaffPortalUi.ActionCard("Finalize Check-Out", panel =>
            {
                var info = new Label
                {
                    Text = "Enter a reservation reference and choose the payment result to finalize departure.",
                    Font = WildNestUI.FontBody(10f),
                    ForeColor = WildNestUI.TextDark,
                    BackColor = Color.Transparent,
                    AutoSize = true,
                    Location = new Point(18, 62)
                };
                var tb = new TextBox
                {
                    PlaceholderText = "Reservation ID",
                    Font = WildNestUI.FontBody(10f),
                    BorderStyle = BorderStyle.FixedSingle,
                    Location = new Point(18, 92),
                    Width = 260
                };
                var cmb = new ComboBox
                {
                    Location = new Point(290, 92),
                    Width = 150,
                    DropDownStyle = ComboBoxStyle.DropDownList,
                    Font = WildNestUI.FontBody(10f)
                };
                cmb.Items.AddRange(new object[] { "Paid", "Pending", "Unpaid" });
                cmb.SelectedIndex = 0;

                var btn = WildNestUI.BtnPrimary("Complete Check-Out", 170, 30);
                btn.Location = new Point(452, 90);
                btn.Click += (s, e) =>
                {
                    string reservationId = tb.Text.Trim();
                    if (string.IsNullOrWhiteSpace(reservationId))
                    {
                        MessageBox.Show("Enter a reservation reference first.");
                        return;
                    }

                    try
                    {
                        StaffPortalDb.Execute(
                            "UPDATE tbl_reservations SET Status='Checked-Out' WHERE ReservationID=@id;",
                            new MySqlParameter("@id", reservationId));

                        int paymentRows = StaffPortalDb.Count(
                            "SELECT COUNT(*) FROM tbl_payments WHERE ReservationID=@id;",
                            new MySqlParameter("@id", reservationId));

                        if (paymentRows == 0)
                        {
                            StaffPortalDb.Execute(@"
INSERT INTO tbl_payments (ReservationID, Amount, PaymentMethod, Status, PaidAt)
SELECT ReservationID, TotalAmount, 'Front Desk Settlement', @status,
       CASE WHEN @status='Paid' THEN NOW() ELSE NULL END
FROM tbl_reservations
WHERE ReservationID=@id;",
                                new MySqlParameter("@id", reservationId),
                                new MySqlParameter("@status", cmb.Text));
                        }
                        else
                        {
                            StaffPortalDb.Execute(@"
UPDATE tbl_payments
SET Status=@status,
    PaidAt = CASE WHEN @status='Paid' THEN NOW() ELSE PaidAt END
WHERE ReservationID=@id;",
                                new MySqlParameter("@id", reservationId),
                                new MySqlParameter("@status", cmb.Text));
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Check-out failed: " + ex.Message);
                        return;
                    }

                    MessageBox.Show("Reservation and payment status updated.");
                    Render();
                };

                panel.Controls.Add(info);
                panel.Controls.Add(tb);
                panel.Controls.Add(cmb);
                panel.Controls.Add(btn);
            }, 168);

            var page = StaffPortalUi.BuildPage(
                "Check-Out & Billing",
                "Departure and payment control using tbl_reservations and tbl_payments.",
                new List<Control>
                {
                    StaffPortalUi.StatsRow(
                        (dueToday.ToString(), "Due to Check Out Today", WildNestUI.Green),
                        (paidToday.ToString(), "Payments Logged Today", WildNestUI.Blue),
                        (StaffPortalUi.Peso(revenueToday), "Revenue Today", WildNestUI.Amber),
                        (unpaid.ToString(), "Pending / Unpaid Payments", WildNestUI.Red)),
                    actionCard,
                    StaffPortalUi.GridCard("Departure & Billing Queue", departures, "No departures matched this view.")
                });

            Controls.Add(page);
        }
    }
}
