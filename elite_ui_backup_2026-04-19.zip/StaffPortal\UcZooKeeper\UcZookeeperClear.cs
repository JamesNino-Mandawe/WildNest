using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcZooKeeper
{
    public partial class UcZookeeperClear : UserControl
    {
        public UcZookeeperClear()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            Controls.Add(StaffPortalUi.BuildPage(
                "Clear Animal",
                "Prepared control endpoint for future alert-clearance actions.",
                new List<Control>
                {
                    StaffPortalUi.MessageCard(
                        "Animal Clearance Needs a Dedicated Status Table",
                        "This page is ready to become the clearance endpoint later, but the current SQL schema does not yet persist animal statuses or health alert clearances.",
                        alert: true)
                }));
        }
    }
}
