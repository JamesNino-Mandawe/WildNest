using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcZooKeeper
{
    public partial class UcZookeeperFeeding : UserControl
    {
        public UcZookeeperFeeding()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            var todayDemand = StaffPortalDb.GetTable(@"
SELECT COALESCE(DATE_FORMAT(r.VisitDate, '%Y-%m-%d'), DATE_FORMAT(r.CheckInDate, '%Y-%m-%d')) AS `Operational Date`,
       e.ExperienceName AS `Experience`,
       SUM(be.Quantity) AS `Guest Slots`,
       e.DurationMinutes AS `Duration (mins)`
FROM tbl_bookingexperiences be
JOIN tbl_reservations r ON r.ReservationID = be.ReservationID
JOIN tbl_experiences e ON e.ExperienceID = be.ExperienceID
GROUP BY `Operational Date`, e.ExperienceName, e.DurationMinutes
ORDER BY `Operational Date` DESC, `Guest Slots` DESC;");

            Controls.Add(StaffPortalUi.BuildPage(
                "Feeding Schedule",
                "Current schema does not store animal feeding tables yet, so this view shows guest demand timing by wildlife experience.",
                new List<Control>
                {
                    StaffPortalUi.MessageCard(
                        "Feeding Table Not Yet Present",
                        "Add a dedicated feeding schedule table later if you want true animal meal planning. For now, this page helps estimate operational timing pressure from experience demand.",
                        alert: true),
                    StaffPortalUi.GridCard("Experience Demand by Date", todayDemand)
                }));
        }
    }
}
