using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcReception
{
    public class UcReceptionDashboardContent : UserControl
    {
        public UcReceptionDashboardContent()
        {
            Dock = DockStyle.Fill;
            BackColor = WildNestUI.Sand;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            int arrivals = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_reservations WHERE CheckInDate = CURDATE() OR VisitDate = CURDATE();");
            int activeReservations = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_reservations WHERE Status IN ('Confirmed','Checked-In');");
            int availableCabins = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_cabins WHERE Status = 'Available';");
            int guests = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_guests;");

            var arrivalsTable = StaffPortalDb.GetTable(@"
SELECT r.ReservationID AS `Reservation Ref`,
       CONCAT(g.FirstName, ' ', g.LastName) AS `Guest`,
       COALESCE(c.CabinName, 'Day Visit / Experience') AS `Cabin or Visit`,
       COALESCE(r.ArrivalTime, 'Front Desk Confirmation') AS `Arrival Time`,
       r.BookingType AS `Booking Type`,
       r.Status
FROM tbl_reservations r
LEFT JOIN tbl_guests g ON g.GuestID = r.GuestID
LEFT JOIN tbl_cabins c ON c.CabinID = r.CabinID
WHERE r.CheckInDate = CURDATE() OR r.VisitDate = CURDATE()
ORDER BY r.CreatedAt DESC;");

            var activeTable = StaffPortalDb.GetTable(@"
SELECT r.ReservationID AS `Reservation Ref`,
       CONCAT(g.FirstName, ' ', g.LastName) AS `Guest`,
       COALESCE(c.CabinName, 'Day Visit / Experience') AS `Cabin or Visit`,
       COALESCE(DATE_FORMAT(r.CheckInDate, '%Y-%m-%d'), DATE_FORMAT(r.VisitDate, '%Y-%m-%d')) AS `Start`,
       DATE_FORMAT(r.CheckOutDate, '%Y-%m-%d') AS `End`,
       r.Status,
       r.TotalAmount AS `Total Amount`
FROM tbl_reservations r
LEFT JOIN tbl_guests g ON g.GuestID = r.GuestID
LEFT JOIN tbl_cabins c ON c.CabinID = r.CabinID
WHERE r.Status IN ('Confirmed','Checked-In')
ORDER BY r.CreatedAt DESC;");

            var page = StaffPortalUi.BuildPage(
                "Front Desk Dashboard",
                $"Live reception overview from reservations, cabins, and guests — {DateTime.Now:MMMM d, yyyy}",
                new List<Control>
                {
                    StaffPortalUi.StatsRow(
                        (arrivals.ToString(), "Arrivals / Visits Today", WildNestUI.Green),
                        (activeReservations.ToString(), "Active Reservations", WildNestUI.Blue),
                        (availableCabins.ToString(), "Available Cabins", WildNestUI.Amber),
                        (guests.ToString(), "Guest Profiles", WildNestUI.Green)),
                    StaffPortalUi.GridCard("Today's Arrivals", arrivalsTable, "No arrivals or day visits scheduled today."),
                    StaffPortalUi.GridCard("Active Front Desk Reservations", activeTable)
                });

            Controls.Add(page);
        }
    }
}
