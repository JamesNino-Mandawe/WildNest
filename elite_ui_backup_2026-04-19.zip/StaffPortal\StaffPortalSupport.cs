using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Project
{
    internal static class StaffPortalDb
    {
        internal const string ConnString = "server=localhost;user=root;database=wildnest_db;password=Natsudragneel_525;Allow User Variables=True;";

        internal static DataTable GetTable(string sql, params MySqlParameter[] parameters)
        {
            var table = new DataTable();
            using var conn = new MySqlConnection(ConnString);
            using var cmd = new MySqlCommand(sql, conn);
            if (parameters?.Length > 0)
                cmd.Parameters.AddRange(parameters);
            using var adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(table);
            return table;
        }

        internal static int Count(string sql, params MySqlParameter[] parameters)
        {
            object? value = Scalar(sql, parameters);
            return value == null || value == DBNull.Value ? 0 : Convert.ToInt32(value);
        }

        internal static decimal Sum(string sql, params MySqlParameter[] parameters)
        {
            object? value = Scalar(sql, parameters);
            return value == null || value == DBNull.Value ? 0m : Convert.ToDecimal(value);
        }

        internal static object? Scalar(string sql, params MySqlParameter[] parameters)
        {
            using var conn = new MySqlConnection(ConnString);
            using var cmd = new MySqlCommand(sql, conn);
            if (parameters?.Length > 0)
                cmd.Parameters.AddRange(parameters);
            conn.Open();
            return cmd.ExecuteScalar();
        }

        internal static void Execute(string sql, params MySqlParameter[] parameters)
        {
            using var conn = new MySqlConnection(ConnString);
            using var cmd = new MySqlCommand(sql, conn);
            if (parameters?.Length > 0)
                cmd.Parameters.AddRange(parameters);
            conn.Open();
            cmd.ExecuteNonQuery();
        }

        internal static bool TableExists(string tableName)
        {
            const string sql = @"
SELECT COUNT(*)
FROM information_schema.tables
WHERE table_schema = DATABASE()
  AND table_name = @tableName;";
            return Count(sql, new MySqlParameter("@tableName", tableName)) > 0;
        }
    }

    internal static class StaffPortalUi
    {
        internal static UserControl BuildPage(string title, string subtitle, IEnumerable<Control> sections)
        {
            var host = new UserControl
            {
                Dock = DockStyle.Fill,
                BackColor = WildNestUI.Sand,
                AutoScroll = true
            };

            int width = 1100;
            var scroll = WildNestUI.ScrollWrapper();
            var flow = WildNestUI.FlowColumn(width);
            flow.Controls.Add(WildNestUI.PageHeader(title, subtitle, width));

            foreach (var section in sections)
            {
                section.Width = width;
                flow.Controls.Add(section);
            }

            scroll.Controls.Add(flow);
            flow.Location = new Point(0, 0);
            host.Controls.Add(scroll);

            host.Resize += (s, e) =>
            {
                int newWidth = Math.Max(host.ClientSize.Width - 48, 720);
                flow.Width = newWidth;
                foreach (Control c in flow.Controls)
                    c.Width = newWidth;
            };

            return host;
        }

        internal static Panel StatsRow(params (string Value, string Label, Color Color)[] stats)
        {
            int width = 1100;
            var row = new Panel
            {
                Height = 84,
                BackColor = Color.Transparent,
                Margin = new Padding(0, 0, 0, 12)
            };

            void Layout()
            {
                row.Controls.Clear();
                if (stats.Length == 0)
                    return;

                int cardWidth = Math.Max((row.Width - ((stats.Length - 1) * 8)) / stats.Length, 150);
                for (int i = 0; i < stats.Length; i++)
                {
                    var stat = stats[i];
                    var card = WildNestUI.StatCard(stat.Value, stat.Label, stat.Color, cardWidth);
                    card.Location = new Point(i * (cardWidth + 8), 0);
                    row.Controls.Add(card);
                }
            }

            row.Width = width;
            row.Resize += (s, e) => Layout();
            Layout();
            return row;
        }

        internal static Panel GridCard(string title, DataTable table, string emptyMessage = "No records found for this view.")
        {
            int width = 1100;
            int height = table.Rows.Count == 0 ? 180 : Math.Min(460, 120 + (table.Rows.Count * 28));
            var card = WildNestUI.CardWithHeader(width, height, title, 42);

            if (table.Rows.Count == 0)
            {
                card.Controls.Add(new Label
                {
                    Text = emptyMessage,
                    Font = WildNestUI.FontBody(10f),
                    ForeColor = WildNestUI.Muted,
                    AutoSize = true,
                    Location = new Point(18, 74),
                    BackColor = Color.Transparent
                });
                return card;
            }

            var grid = CreateGrid(table);
            grid.Location = new Point(14, 54);
            grid.Size = new Size(card.Width - 28, card.Height - 68);
            card.Controls.Add(grid);
            card.Resize += (s, e) => grid.Size = new Size(card.Width - 28, card.Height - 68);
            return card;
        }

        internal static Panel MessageCard(string title, string message, bool alert = false)
        {
            var card = WildNestUI.CardWithHeader(1100, 150, title, 42);
            card.Controls.Add(new Label
            {
                Text = message,
                Font = WildNestUI.FontBody(10f),
                ForeColor = alert ? WildNestUI.Red : WildNestUI.TextDark,
                Location = new Point(18, 62),
                Size = new Size(card.Width - 36, 70),
                BackColor = Color.Transparent
            });
            return card;
        }

        internal static Panel ActionCard(string title, Action<Panel> builder, int height = 180)
        {
            var card = WildNestUI.CardWithHeader(1100, height, title, 42);
            builder(card);
            return card;
        }

        internal static DataGridView CreateGrid(DataTable table)
        {
            var grid = new DataGridView
            {
                DataSource = table,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
                ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None,
                EnableHeadersVisualStyles = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                RowHeadersVisible = false
            };

            grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(248, 248, 248);
            grid.ColumnHeadersDefaultCellStyle.ForeColor = WildNestUI.Muted;
            grid.ColumnHeadersDefaultCellStyle.Font = WildNestUI.FontLabel(8f);
            grid.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.FromArgb(248, 248, 248);
            grid.ColumnHeadersHeight = 36;

            grid.DefaultCellStyle.BackColor = Color.White;
            grid.DefaultCellStyle.ForeColor = WildNestUI.TextDark;
            grid.DefaultCellStyle.Font = WildNestUI.FontBody(9f);
            grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(236, 242, 236);
            grid.DefaultCellStyle.SelectionForeColor = WildNestUI.TextDark;
            grid.GridColor = Color.FromArgb(238, 238, 238);
            grid.RowTemplate.Height = 30;

            foreach (DataGridViewColumn column in grid.Columns)
            {
                if (column.Name.Contains("Amount", StringComparison.OrdinalIgnoreCase) ||
                    column.Name.Contains("Total", StringComparison.OrdinalIgnoreCase) ||
                    column.Name.Contains("Revenue", StringComparison.OrdinalIgnoreCase))
                {
                    column.DefaultCellStyle.Format = "N2";
                }
            }

            return grid;
        }

        internal static string Peso(decimal amount) => $"PHP {amount:N2}";

        internal static string SafeString(object? value, string fallback = "N/A")
        {
            if (value == null || value == DBNull.Value)
                return fallback;
            var text = Convert.ToString(value)?.Trim();
            return string.IsNullOrEmpty(text) ? fallback : text;
        }
    }
}
