using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

// ════════════════════════════════════════════════════════════════════
//  UcStaffChat  —  Premium Internal Staff ↔ Administrator chat
//  v2.0  |  WildNest Zoo Resort
//
//  USAGE (non-admin roles):
//    new UcStaffChat("Reception", "Maria Santos")
//    new UcStaffChat("TourGuide", "Ana Cruz")
//    new UcStaffChat("ZooKeeper", "Jose Reyes")
//
//  USAGE (Administrator):
//    new UcStaffChat("Administrator", "Admin User")
//
//  IMPROVEMENTS in v2:
//   ✓ Modern messenger-style message bubbles (right/left aligned)
//   ✓ Admin conversation list with last message + time preview
//   ✓ Unread count badges on conversation list
//   ✓ In-app toast notifications for new messages
//   ✓ Quick-reply chips (Received, On my way, Please wait, Need assistance)
//   ✓ Polished input area with rounded send button
//   ✓ Smart auto-scroll (only when near bottom)
//   ✓ Proper timer disposal on Dispose
//   ✓ Date separator bubbles (Today, Yesterday, date)
//   ✓ Broadcast gold-amber style
//   ✓ Typing placeholder animation
// ════════════════════════════════════════════════════════════════════

namespace Project
{
    public class UcStaffChat : UserControl
    {
        // ── Palette ───────────────────────────────────────────────────
        static readonly Color C_Forest      = Color.FromArgb(7, 26, 14);
        static readonly Color C_ForestMid   = Color.FromArgb(13, 40, 24);
        static readonly Color C_ForestLight = Color.FromArgb(27, 67, 50);
        static readonly Color C_Gold        = Color.FromArgb(212, 160, 23);
        static readonly Color C_GoldLight   = Color.FromArgb(254, 243, 226);
        static readonly Color C_Cream       = Color.FromArgb(248, 244, 239);
        static readonly Color C_Sand        = Color.FromArgb(240, 237, 232);
        static readonly Color C_SandDark    = Color.FromArgb(228, 224, 218);
        static readonly Color C_White       = Color.White;
        static readonly Color C_Border      = Color.FromArgb(221, 221, 221);
        static readonly Color C_Text        = Color.FromArgb(26, 26, 26);
        static readonly Color C_Muted       = Color.FromArgb(140, 134, 126);
        static readonly Color C_SentBubble  = Color.FromArgb(7, 26, 14);
        static readonly Color C_RecvBubble  = Color.White;
        static readonly Color C_BroadcastBg = Color.FromArgb(254, 243, 226);
        static readonly Color C_BroadcastFg = Color.FromArgb(100, 56, 6);
        static readonly Color C_ActiveConvo = Color.FromArgb(236, 249, 242);
        static readonly Color C_ToastBg     = Color.FromArgb(30, 32, 30);
        static readonly Color C_Unread      = Color.FromArgb(220, 50, 50);

        const string CONN =
            "server=localhost;user=root;database=wildnest_db;" +
            "password=Natsudragneel_525;Allow User Variables=True;";

        // ── State ─────────────────────────────────────────────────────
        readonly string _myRole;
        readonly string _myName;
        readonly bool   _isAdmin;

        string _selectedRole  = "";
        string _selectedLabel = "";
        int    _lastMessageId = 0;
        bool   _isNearBottom  = true;

        System.Windows.Forms.Timer _pollTimer   = null!;
        System.Windows.Forms.Timer _toastTimer  = null!;

        // Track last seen message per role for toast logic
        readonly Dictionary<string, int> _lastSeenPerRole = new();

        // ── UI refs ───────────────────────────────────────────────────
        Panel          _pnlLeft       = null!;
        FlowLayoutPanel _flowConvos   = null!;
        FlowLayoutPanel _flowMsgs     = null!;
        Panel          _pnlMsgArea    = null!;
        Panel          _pnlEmpty      = null!;
        Panel          _pnlChatHeader = null!;
        Label          _lblChatWith   = null!;
        Label          _lblChatSub    = null!;
        TextBox        _txtInput      = null!;
        Button         _btnSend       = null!;
        Panel          _pnlInput      = null!;
        Panel          _pnlToast      = null!;
        Label          _lblToastMsg   = null!;

        // Convo data for admin list
        readonly Dictionary<string, (string LastMsg, DateTime LastTime, int Unread)> _convoData = new();

        // ─────────────────────────────────────────────────────────────
        public UcStaffChat(string myRole, string myName)
        {
            _myRole  = myRole;
            _myName  = myName;
            _isAdmin = myRole == "Administrator";

            DoubleBuffered = true;
            BackColor      = C_Sand;
            Dock           = DockStyle.Fill;

            HandleCreated += (s, e) =>
            {
                EnsureTable();
                BuildUi();
                if (!_isAdmin)
                {
                    _selectedRole  = "Administrator";
                    _selectedLabel = "Administrator";
                    ShowChatArea(true);
                    LoadAllMessages();
                }
                StartPolling();
            };
        }

        // ═════════════════════════════════════════════════════════════
        //  ENSURE TABLE
        // ═════════════════════════════════════════════════════════════
        void EnsureTable()
        {
            try
            {
                using var conn = new MySqlConnection(CONN);
                conn.Open();
                new MySqlCommand(@"
                    CREATE TABLE IF NOT EXISTS tbl_StaffMessages (
                        MessageID    INT AUTO_INCREMENT PRIMARY KEY,
                        SenderRole   VARCHAR(50)  NOT NULL,
                        SenderName   VARCHAR(100) NOT NULL,
                        ReceiverRole VARCHAR(50)  NOT NULL,
                        Message      TEXT         NOT NULL,
                        SentAt       DATETIME     DEFAULT NOW(),
                        IsRead       BOOLEAN      DEFAULT FALSE
                    );", conn).ExecuteNonQuery();
            }
            catch { }
        }

        // ═════════════════════════════════════════════════════════════
        //  BUILD UI
        // ═════════════════════════════════════════════════════════════
        void BuildUi()
        {
            // ── Global header ─────────────────────────────────────────
            var header = new Panel { Dock = DockStyle.Top, Height = 60, BackColor = C_Forest };
            header.Paint += (s, e) =>
            {
                var g = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using var br = new LinearGradientBrush(
                    new Point(0, 0), new Point(0, header.Height), C_Forest, C_ForestMid);
                g.FillRectangle(br, header.ClientRectangle);
                using var pen = new Pen(Color.FromArgb(50, C_Gold), 1f);
                g.DrawLine(pen, 0, header.Height - 1, header.Width, header.Height - 1);
            };

            // Left gold accent bar
            header.Controls.Add(new Panel
            {
                Size      = new Size(3, 28),
                BackColor = C_Gold,
                Location  = new Point(16, 16)
            });

            header.Controls.Add(new Label
            {
                Text      = "Staff Messaging",
                Font      = new Font("Georgia", 13f, FontStyle.Bold),
                ForeColor = C_Cream,
                AutoSize  = true,
                Location  = new Point(26, 14),
                BackColor = Color.Transparent
            });
            header.Controls.Add(new Label
            {
                Text = _isAdmin
                    ? "Internal · Administrator view  ·  All staff channels"
                    : $"Internal · {_myRole}  →  Administrator",
                Font      = new Font("Segoe UI", 8f),
                ForeColor = Color.FromArgb(130, C_Cream),
                AutoSize  = true,
                Location  = new Point(27, 38),
                BackColor = Color.Transparent
            });

            // Toast panel (initially hidden, anchored top-right)
            _pnlToast = BuildToastPanel();
            header.Controls.Add(_pnlToast);

            Controls.Add(header);

            if (_isAdmin)
                BuildAdminLayout();
            else
                BuildStaffLayout();
        }

        // ── TOAST PANEL ───────────────────────────────────────────────
        Panel BuildToastPanel()
        {
            var toast = new Panel
            {
                Size      = new Size(280, 44),
                BackColor = C_ToastBg,
                Visible   = false,
                Cursor    = Cursors.Hand
            };
            toast.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var path = RoundPath(new Rectangle(0, 0, toast.Width - 1, toast.Height - 1), 8);
                using var b    = new SolidBrush(C_ToastBg);
                e.Graphics.FillPath(b, path);
                using var pen = new Pen(Color.FromArgb(60, C_Gold), 1f);
                e.Graphics.DrawPath(pen, path);
            };
            toast.Controls.Add(new Label
            {
                Text      = "💬",
                Font      = new Font("Segoe UI Emoji", 14f),
                AutoSize  = true,
                Location  = new Point(10, 10),
                BackColor = Color.Transparent
            });
            _lblToastMsg = new Label
            {
                Text      = "",
                Font      = new Font("Segoe UI", 9f),
                ForeColor = C_Cream,
                AutoSize  = false,
                Size      = new Size(220, 40),
                Location  = new Point(42, 2),
                BackColor = Color.Transparent,
                TextAlign = ContentAlignment.MiddleLeft
            };
            toast.Controls.Add(_lblToastMsg);

            _toastTimer = new System.Windows.Forms.Timer { Interval = 3500 };
            _toastTimer.Tick += (s, e) =>
            {
                _toastTimer.Stop();
                toast.Visible = false;
            };
            return toast;
        }

        void ShowToast(string text)
        {
            if (!IsHandleCreated) return;
            void Show()
            {
                _lblToastMsg.Text = text;
                // Position top-right of header
                var header = Controls[0] as Panel;
                if (header != null)
                    _pnlToast.Location = new Point(header.Width - 296, 8);
                _pnlToast.Visible = true;
                _pnlToast.BringToFront();
                _toastTimer.Stop();
                _toastTimer.Start();
            }
            if (InvokeRequired) Invoke((Action)Show);
            else Show();
        }

        // ── ADMIN LAYOUT ──────────────────────────────────────────────
        void BuildAdminLayout()
        {
            // Left conversation list panel
            _pnlLeft = new Panel
            {
                Dock      = DockStyle.Left,
                Width     = 248,
                BackColor = C_White
            };
            _pnlLeft.Paint += (s, e) =>
            {
                using var pen = new Pen(C_Border, 1f);
                e.Graphics.DrawLine(pen, _pnlLeft.Width - 1, 0, _pnlLeft.Width - 1, _pnlLeft.Height);
            };

            // List header
            var listHeader = new Panel
            {
                Size      = new Size(248, 48),
                Location  = new Point(0, 0),
                BackColor = C_Sand
            };
            listHeader.Paint += (s, e) =>
            {
                using var pen = new Pen(C_Border, 1f);
                e.Graphics.DrawLine(pen, 0, listHeader.Height - 1, listHeader.Width, listHeader.Height - 1);
            };
            listHeader.Controls.Add(new Label
            {
                Text      = "CHANNELS",
                Font      = new Font("Segoe UI", 7.5f, FontStyle.Bold),
                ForeColor = C_Muted,
                Location  = new Point(16, 16),
                AutoSize  = true,
                BackColor = Color.Transparent
            });
            _pnlLeft.Controls.Add(listHeader);

            _flowConvos = new FlowLayoutPanel
            {
                Location      = new Point(0, 48),
                Size          = new Size(248, _pnlLeft.Height - 48),
                FlowDirection = FlowDirection.TopDown,
                WrapContents  = false,
                AutoScroll    = true,
                BackColor     = C_White,
                Padding       = new Padding(0)
            };
            _pnlLeft.Controls.Add(_flowConvos);
            _pnlLeft.Resize += (s, e) =>
                _flowConvos.Size = new Size(248, _pnlLeft.Height - 48);

            Controls.Add(_pnlLeft);
            BuildRightPanel();
            LoadAdminConversationList();
        }

        // ── STAFF LAYOUT ──────────────────────────────────────────────
        void BuildStaffLayout()
        {
            BuildRightPanel();
        }

        // ── RIGHT PANEL ───────────────────────────────────────────────
        void BuildRightPanel()
        {
            var pnlRight = new Panel { Dock = DockStyle.Fill, BackColor = C_Sand };

            // ── Empty state ───────────────────────────────────────────
            _pnlEmpty = new Panel { Dock = DockStyle.Fill, BackColor = C_Sand };
            var emptyFlow = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.TopDown,
                AutoSize      = true,
                BackColor     = Color.Transparent,
                Anchor        = AnchorStyles.None
            };
            emptyFlow.Controls.Add(new Label
            {
                Text      = "💬",
                Font      = new Font("Segoe UI Emoji", 42f),
                AutoSize  = true,
                BackColor = Color.Transparent,
                ForeColor = Color.FromArgb(180, C_Muted),
                TextAlign = ContentAlignment.MiddleCenter
            });
            emptyFlow.Controls.Add(new Label
            {
                Text      = "Select a channel to start messaging",
                Font      = new Font("Segoe UI", 10.5f),
                ForeColor = C_Muted,
                AutoSize  = true,
                BackColor = Color.Transparent,
                TextAlign = ContentAlignment.MiddleCenter,
                Margin    = new Padding(0, 8, 0, 0)
            });
            _pnlEmpty.Controls.Add(emptyFlow);
            _pnlEmpty.Resize += (s, e) =>
            {
                emptyFlow.Location = new Point(
                    (_pnlEmpty.Width  - emptyFlow.Width)  / 2,
                    (_pnlEmpty.Height - emptyFlow.Height) / 2 - 40);
            };
            pnlRight.Controls.Add(_pnlEmpty);

            // ── Chat header ───────────────────────────────────────────
            _pnlChatHeader = new Panel
            {
                Dock      = DockStyle.Top,
                Height    = 56,
                BackColor = C_White,
                Visible   = false
            };
            _pnlChatHeader.Paint += (s, e) =>
            {
                using var pen = new Pen(C_Border, 1f);
                e.Graphics.DrawLine(pen, 0, _pnlChatHeader.Height - 1,
                    _pnlChatHeader.Width, _pnlChatHeader.Height - 1);
            };
            // Avatar circle
            var avatar = new Panel
            {
                Size      = new Size(36, 36),
                Location  = new Point(14, 10),
                BackColor = Color.Transparent
            };
            avatar.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var b = new SolidBrush(Color.FromArgb(22, C_Gold));
                e.Graphics.FillEllipse(b, 0, 0, 35, 35);
                using var pen = new Pen(C_Gold, 1.5f);
                e.Graphics.DrawEllipse(pen, 0, 0, 35, 35);
                using var sf = new StringFormat
                {
                    Alignment     = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center
                };
                using var font = new Font("Segoe UI", 13f);
                e.Graphics.DrawString("💬", font, new SolidBrush(C_Forest),
                    new RectangleF(0, 0, 36, 36), sf);
            };
            _pnlChatHeader.Controls.Add(avatar);

            _lblChatWith = new Label
            {
                Text      = "",
                Font      = new Font("Segoe UI", 10.5f, FontStyle.Bold),
                ForeColor = C_Text,
                AutoSize  = true,
                Location  = new Point(58, 10),
                BackColor = Color.Transparent
            };
            _lblChatSub = new Label
            {
                Text      = "Internal staff channel",
                Font      = new Font("Segoe UI", 8f),
                ForeColor = C_Muted,
                AutoSize  = true,
                Location  = new Point(59, 32),
                BackColor = Color.Transparent
            };
            _pnlChatHeader.Controls.Add(_lblChatWith);
            _pnlChatHeader.Controls.Add(_lblChatSub);
            pnlRight.Controls.Add(_pnlChatHeader);

            // ── Message area ──────────────────────────────────────────
            _pnlMsgArea = new Panel
            {
                Dock      = DockStyle.Fill,
                BackColor = C_Sand,
                Visible   = false
            };

            _flowMsgs = new FlowLayoutPanel
            {
                Dock          = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents  = false,
                AutoScroll    = true,
                BackColor     = C_Sand,
                Padding       = new Padding(12, 12, 12, 12)
            };
            // Track scroll position for smart auto-scroll
            _flowMsgs.Scroll += (s, e) =>
            {
                int scrollBottom = _flowMsgs.VerticalScroll.Value +
                                   _flowMsgs.ClientSize.Height;
                int contentH = _flowMsgs.VerticalScroll.Maximum -
                               _flowMsgs.VerticalScroll.LargeChange;
                _isNearBottom = (contentH - scrollBottom) < 80;
            };
            _pnlMsgArea.Controls.Add(_flowMsgs);
            pnlRight.Controls.Add(_pnlMsgArea);

            // ── Input area ────────────────────────────────────────────
            _pnlInput = BuildInputPanel();
            _pnlInput.Visible = false;
            pnlRight.Controls.Add(_pnlInput);

            Controls.Add(pnlRight);
        }

        // ── INPUT PANEL ───────────────────────────────────────────────
        Panel BuildInputPanel()
        {
            int panelH = _isAdmin ? 128 : 96;
            var pnl = new Panel
            {
                Dock      = DockStyle.Bottom,
                Height    = panelH,
                BackColor = C_White
            };
            pnl.Paint += (s, e) =>
            {
                using var pen = new Pen(C_Border, 1f);
                e.Graphics.DrawLine(pen, 0, 0, pnl.Width, 0);
            };

            // Quick reply chips
            var chipFlow = new FlowLayoutPanel
            {
                Location      = new Point(12, 8),
                Size          = new Size(pnl.Width - 24, 28),
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents  = false,
                AutoScroll    = false,
                BackColor     = Color.Transparent,
                Anchor        = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            string[] chips = { "✅ Received", "🚶 On my way", "⏳ Please wait", "🆘 Need assistance" };
            foreach (var chip in chips)
            {
                var c = chip; // capture
                var btn = new Button
                {
                    Text      = c,
                    Font      = new Font("Segoe UI", 7.5f),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = C_Sand,
                    ForeColor = Color.FromArgb(70, 65, 60),
                    Cursor    = Cursors.Hand,
                    Height    = 24,
                    AutoSize  = true,
                    Margin    = new Padding(0, 0, 5, 0),
                    Padding   = new Padding(8, 0, 8, 0)
                };
                btn.FlatAppearance.BorderColor = C_Border;
                btn.FlatAppearance.BorderSize  = 1;
                btn.MouseEnter += (s, e) => btn.BackColor = C_SandDark;
                btn.MouseLeave += (s, e) => btn.BackColor = C_Sand;
                btn.Click      += (s, e) => { _txtInput.Text = c.Substring(c.IndexOf(' ') + 1); SendMessage(); };
                chipFlow.Controls.Add(btn);
            }
            pnl.Controls.Add(chipFlow);

            int inputTop = 40;

            // Input wrapper (rounded box)
            var inputWrap = new Panel
            {
                Location  = new Point(12, inputTop),
                Size      = new Size(pnl.Width - 76, 38),
                BackColor = Color.FromArgb(245, 243, 240),
                Anchor    = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            inputWrap.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var path = RoundPath(new Rectangle(0, 0, inputWrap.Width - 1, inputWrap.Height - 1), 10);
                using var b   = new SolidBrush(Color.FromArgb(245, 243, 240));
                e.Graphics.FillPath(b, path);
                using var pen = new Pen(C_Border, 1f);
                e.Graphics.DrawPath(pen, path);
            };

            _txtInput = new TextBox
            {
                Multiline       = false,
                Font            = new Font("Segoe UI", 10f),
                BorderStyle     = BorderStyle.None,
                BackColor       = Color.FromArgb(245, 243, 240),
                ForeColor       = C_Text,
                Location        = new Point(12, 9),
                Size            = new Size(inputWrap.Width - 24, 22),
                PlaceholderText = "Type a message…",
                Anchor          = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            _txtInput.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter && !e.Shift)
                { e.SuppressKeyPress = true; SendMessage(); }
            };
            inputWrap.Controls.Add(_txtInput);
            inputWrap.Resize += (s, e) => _txtInput.Width = inputWrap.Width - 24;
            pnl.Controls.Add(inputWrap);

            // Send button (rounded, forest+gold)
            _btnSend = new Button
            {
                Text      = "➤",
                Size      = new Size(48, 38),
                FlatStyle = FlatStyle.Flat,
                BackColor = C_Forest,
                ForeColor = C_Gold,
                Font      = new Font("Segoe UI", 12f, FontStyle.Bold),
                Cursor    = Cursors.Hand,
                Anchor    = AnchorStyles.Right | AnchorStyles.Top,
                Location  = new Point(pnl.Width - 62, inputTop)
            };
            _btnSend.FlatAppearance.BorderSize = 0;
            _btnSend.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var path = RoundPath(new Rectangle(0, 0, _btnSend.Width - 1, _btnSend.Height - 1), 10);
                using var b   = new SolidBrush(C_Forest);
                e.Graphics.FillPath(b, path);
                using var sf = new StringFormat
                    { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                using var font = new Font("Segoe UI", 12f, FontStyle.Bold);
                e.Graphics.DrawString("➤", font, new SolidBrush(C_Gold),
                    new RectangleF(0, 0, _btnSend.Width, _btnSend.Height), sf);
            };
            _btnSend.Click += (s, e) => SendMessage();
            pnl.Controls.Add(_btnSend);

            // Admin broadcast button
            if (_isAdmin)
            {
                var btnBroadcast = new Button
                {
                    Text      = "📢  Broadcast to All Staff",
                    Size      = new Size(200, 26),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = C_GoldLight,
                    ForeColor = C_BroadcastFg,
                    Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                    Cursor    = Cursors.Hand,
                    Location  = new Point(12, inputTop + 46),
                    Anchor    = AnchorStyles.Left | AnchorStyles.Bottom
                };
                btnBroadcast.FlatAppearance.BorderColor = C_Gold;
                btnBroadcast.FlatAppearance.BorderSize  = 1;
                btnBroadcast.MouseEnter += (s, e) =>
                    btnBroadcast.BackColor = Color.FromArgb(252, 237, 190);
                btnBroadcast.MouseLeave += (s, e) =>
                    btnBroadcast.BackColor = C_GoldLight;
                btnBroadcast.Click      += (s, e) => SendBroadcast();
                pnl.Controls.Add(btnBroadcast);
            }

            pnl.Resize += (s, e) =>
            {
                chipFlow.Width    = pnl.Width - 24;
                inputWrap.Width   = pnl.Width - 76;
                _btnSend.Location = new Point(pnl.Width - 62, inputTop);
            };

            return pnl;
        }

        // ═════════════════════════════════════════════════════════════
        //  SHOW / HIDE CHAT AREA
        // ═════════════════════════════════════════════════════════════
        void ShowChatArea(bool show)
        {
            _pnlEmpty.Visible      = !show;
            _pnlChatHeader.Visible = show;
            _pnlMsgArea.Visible    = show;
            _pnlInput.Visible      = show;
        }

        // ═════════════════════════════════════════════════════════════
        //  ADMIN: CONVERSATION LIST
        // ═════════════════════════════════════════════════════════════
        void LoadAdminConversationList()
        {
            Task.Run(() =>
            {
                var roles = new[]
                {
                    ("Reception", "🖥", "Front Desk"),
                    ("TourGuide", "🦁", "Tour Guide"),
                    ("ZooKeeper", "🐾", "Zoo Keeper"),
                };

                // Load unread counts + last message per role
                var data = new Dictionary<string, (int Unread, string LastMsg, DateTime LastTime)>();
                try
                {
                    using var conn = new MySqlConnection(CONN);
                    conn.Open();

                    // Unread (messages TO admin not yet read)
                    using (var cmd = new MySqlCommand(
                        "SELECT SenderRole, COUNT(*) AS Cnt FROM tbl_StaffMessages " +
                        "WHERE ReceiverRole='Administrator' AND IsRead=0 " +
                        "GROUP BY SenderRole;", conn))
                    using (var r = cmd.ExecuteReader())
                        while (r.Read())
                        {
                            string rol = r["SenderRole"].ToString()!;
                            if (!data.ContainsKey(rol))
                                data[rol] = (Convert.ToInt32(r["Cnt"]), "", DateTime.MinValue);
                            else
                                data[rol] = (Convert.ToInt32(r["Cnt"]), data[rol].LastMsg, data[rol].LastTime);
                        }

                    // Last message per role
                    foreach (var (role, _, _) in roles)
                    {
                        using var cmd2 = new MySqlCommand(@"
                            SELECT Message, SentAt FROM tbl_StaffMessages
                            WHERE (SenderRole=@r AND ReceiverRole='Administrator')
                               OR (SenderRole='Administrator' AND (ReceiverRole=@r OR ReceiverRole='All'))
                            ORDER BY SentAt DESC LIMIT 1;", conn);
                        cmd2.Parameters.AddWithValue("@r", role);
                        using var r2 = cmd2.ExecuteReader();
                        if (r2.Read())
                        {
                            string msg  = r2["Message"].ToString()!;
                            var    time = Convert.ToDateTime(r2["SentAt"]);
                            int    unrd = data.ContainsKey(role) ? data[role].Unread : 0;
                            data[role]  = (unrd, msg.Length > 38 ? msg[..38] + "…" : msg, time);
                        }
                    }
                }
                catch { }

                // Update _convoData
                foreach (var kvp in data)
                    _convoData[kvp.Key] = (kvp.Value.LastMsg, kvp.Value.LastTime, kvp.Value.Unread);

                if (InvokeRequired)
                    Invoke(() => RebuildConvoList(roles, data));
                else
                    RebuildConvoList(roles, data);
            });
        }

        void RebuildConvoList(
            (string Role, string Icon, string Label)[] roles,
            Dictionary<string, (int Unread, string LastMsg, DateTime LastTime)> data)
        {
            _flowConvos.SuspendLayout();
            _flowConvos.Controls.Clear();
            foreach (var (role, icon, label) in roles)
            {
                bool hasData = data.ContainsKey(role);
                int  unread  = hasData ? data[role].Unread : 0;
                string last  = hasData ? data[role].LastMsg : "No messages yet";
                DateTime lt  = hasData ? data[role].LastTime : DateTime.MinValue;
                _flowConvos.Controls.Add(BuildConvoCard(role, icon, label, unread, last, lt));
            }
            _flowConvos.ResumeLayout();
        }

        Panel BuildConvoCard(string role, string icon, string label,
                             int unread, string lastMsg, DateTime lastTime)
        {
            bool isActive = _selectedRole == role;

            var card = new Panel
            {
                Size      = new Size(248, 72),
                BackColor = isActive ? C_ActiveConvo : C_White,
                Cursor    = Cursors.Hand,
                Margin    = new Padding(0)
            };

            card.Paint += (s, e) =>
            {
                bool active = _selectedRole == role;
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var bgBrush = new SolidBrush(active ? C_ActiveConvo : C_White);
                e.Graphics.FillRectangle(bgBrush, card.ClientRectangle);
                if (active)
                {
                    using var accentBrush = new SolidBrush(C_Forest);
                    e.Graphics.FillRectangle(accentBrush, 0, 0, 3, card.Height);
                }
                using var borderPen = new Pen(Color.FromArgb(235, 232, 228), 1f);
                e.Graphics.DrawLine(borderPen, 12, card.Height - 1, card.Width, card.Height - 1);
            };

            // Avatar circle
            var ava = new Panel { Size = new Size(40, 40), Location = new Point(14, 16), BackColor = Color.Transparent };
            ava.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var b = new SolidBrush(Color.FromArgb(14, C_Forest));
                e.Graphics.FillEllipse(b, 0, 0, 39, 39);
                using var pen = new Pen(Color.FromArgb(40, C_Forest), 1f);
                e.Graphics.DrawEllipse(pen, 0, 0, 39, 39);
                using var sf = new StringFormat
                    { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                using var font = new Font("Segoe UI Emoji", 16f);
                e.Graphics.DrawString(icon, font, new SolidBrush(C_Forest),
                    new RectangleF(0, 0, 40, 40), sf);
            };
            card.Controls.Add(ava);

            // Name label
            card.Controls.Add(new Label
            {
                Text      = label,
                Font      = new Font("Segoe UI", 9.5f, unread > 0 ? FontStyle.Bold : FontStyle.Regular),
                ForeColor = C_Text,
                AutoSize  = true,
                Location  = new Point(62, 13),
                BackColor = Color.Transparent
            });

            // Last message preview
            card.Controls.Add(new Label
            {
                Text      = lastMsg.Length > 0 ? lastMsg : "No messages yet",
                Font      = new Font("Segoe UI", 8f, unread > 0 ? FontStyle.Bold : FontStyle.Regular),
                ForeColor = unread > 0 ? C_Text : C_Muted,
                AutoSize  = false,
                Size      = new Size(152, 18),
                Location  = new Point(62, 38),
                BackColor = Color.Transparent
            });

            // Time label
            if (lastTime != DateTime.MinValue)
            {
                string timeStr = lastTime.Date == DateTime.Today
                    ? lastTime.ToString("h:mm tt")
                    : lastTime.ToString("MMM d");
                card.Controls.Add(new Label
                {
                    Text      = timeStr,
                    Font      = new Font("Segoe UI", 7f),
                    ForeColor = C_Muted,
                    AutoSize  = true,
                    Location  = new Point(195, 14),
                    BackColor = Color.Transparent
                });
            }

            // Unread badge
            if (unread > 0)
            {
                var badge = new Label
                {
                    Text      = unread > 9 ? "9+" : unread.ToString(),
                    Font      = new Font("Segoe UI", 7.5f, FontStyle.Bold),
                    ForeColor = C_White,
                    BackColor = C_Unread,
                    Size      = new Size(22, 22),
                    Location  = new Point(216, 38),
                    TextAlign = ContentAlignment.MiddleCenter
                };
                badge.Paint += (s, e) =>
                {
                    e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    using var b = new SolidBrush(C_Unread);
                    e.Graphics.FillEllipse(b, 0, 0, badge.Width - 1, badge.Height - 1);
                    using var sf = new StringFormat
                        { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                    using var font = new Font("Segoe UI", 7.5f, FontStyle.Bold);
                    e.Graphics.DrawString(badge.Text, font, Brushes.White,
                        new RectangleF(0, 0, badge.Width, badge.Height), sf);
                };
                card.Controls.Add(badge);
            }

            // Hover effect
            card.MouseEnter += (s, e) => { if (_selectedRole != role) card.BackColor = Color.FromArgb(248, 246, 243); };
            card.MouseLeave += (s, e) => { if (_selectedRole != role) card.BackColor = C_White; card.Invalidate(); };

            EventHandler select = (s, e) =>
            {
                _selectedRole  = role;
                _selectedLabel = label;
                _lastMessageId = 0;
                _isNearBottom  = true;
                _lblChatWith.Text = label;
                _lblChatSub.Text  = $"{role}  ·  Internal channel";
                ShowChatArea(true);
                LoadAllMessages();
                if (_flowConvos != null)
                    foreach (Control c in _flowConvos.Controls)
                    { c.BackColor = C_White; c.Invalidate(); }
                card.BackColor = C_ActiveConvo;
                card.Invalidate();
            };
            card.Click += select;
            foreach (Control c in card.Controls) c.Click += select;
            return card;
        }

        // ═════════════════════════════════════════════════════════════
        //  LOAD ALL MESSAGES
        // ═════════════════════════════════════════════════════════════
        void LoadAllMessages()
        {
            if (string.IsNullOrEmpty(_selectedRole)) return;

            Task.Run(() =>
            {
                var msgs = FetchMessages(fromId: 0, markRead: true);
                if (msgs.Count > 0)
                    _lastMessageId = msgs[^1].Id;

                if (InvokeRequired) Invoke(() => RebuildMessages(msgs));
                else RebuildMessages(msgs);
            });
        }

        List<MsgRow> FetchMessages(int fromId, bool markRead)
        {
            var msgs = new List<MsgRow>();
            try
            {
                using var conn = new MySqlConnection(CONN);
                conn.Open();

                string sql;
                MySqlCommand cmd;

                if (_isAdmin)
                {
                    sql = @"SELECT MessageID, SenderRole, SenderName, Message, SentAt,
                                   (ReceiverRole='All') AS IsBroadcast
                            FROM tbl_StaffMessages
                            WHERE ((SenderRole=@role AND ReceiverRole='Administrator')
                               OR (SenderRole='Administrator'
                                   AND (ReceiverRole=@role OR ReceiverRole='All')))
                              AND MessageID > @lastId
                            ORDER BY SentAt ASC;";
                    cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@role", _selectedRole);

                    if (markRead)
                    {
                        using var mark = new MySqlCommand(
                            "UPDATE tbl_StaffMessages SET IsRead=1 " +
                            "WHERE SenderRole=@role AND ReceiverRole='Administrator' AND IsRead=0;", conn);
                        mark.Parameters.AddWithValue("@role", _selectedRole);
                        mark.ExecuteNonQuery();
                    }
                }
                else
                {
                    sql = @"SELECT MessageID, SenderRole, SenderName, Message, SentAt,
                                   (ReceiverRole='All') AS IsBroadcast
                            FROM tbl_StaffMessages
                            WHERE ((SenderRole=@myRole AND ReceiverRole='Administrator')
                               OR (SenderRole='Administrator'
                                   AND (ReceiverRole=@myRole OR ReceiverRole='All')))
                              AND MessageID > @lastId
                            ORDER BY SentAt ASC;";
                    cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@myRole", _myRole);

                    if (markRead)
                    {
                        using var mark = new MySqlCommand(
                            "UPDATE tbl_StaffMessages SET IsRead=1 " +
                            "WHERE SenderRole='Administrator' AND (ReceiverRole=@myRole OR ReceiverRole='All') AND IsRead=0;", conn);
                        mark.Parameters.AddWithValue("@myRole", _myRole);
                        mark.ExecuteNonQuery();
                    }
                }
                cmd.Parameters.AddWithValue("@lastId", fromId);

                using var r = cmd.ExecuteReader();
                while (r.Read())
                    msgs.Add(new MsgRow(
                        Convert.ToInt32(r["MessageID"]),
                        r["SenderRole"].ToString()!,
                        r["SenderName"].ToString()!,
                        r["Message"].ToString()!,
                        Convert.ToDateTime(r["SentAt"]),
                        Convert.ToBoolean(r["IsBroadcast"])
                    ));
            }
            catch { }
            return msgs;
        }

        void RebuildMessages(List<MsgRow> msgs)
        {
            _flowMsgs.SuspendLayout();
            _flowMsgs.Controls.Clear();

            DateTime? prevDate = null;
            foreach (var m in msgs)
            {
                // Date separator
                if (prevDate == null || m.SentAt.Date != prevDate.Value.Date)
                {
                    _flowMsgs.Controls.Add(BuildDateSeparator(m.SentAt));
                    prevDate = m.SentAt.Date;
                }
                _flowMsgs.Controls.Add(BuildBubble(m));
            }

            _flowMsgs.ResumeLayout();
            if (_isNearBottom) ScrollToBottom();
        }

        // ═════════════════════════════════════════════════════════════
        //  POLLING
        // ═════════════════════════════════════════════════════════════
        void StartPolling()
        {
            _pollTimer = new System.Windows.Forms.Timer { Interval = 3000 };
            _pollTimer.Tick += (s, e) => PollCycle();
            _pollTimer.Start();
        }

        void PollCycle()
        {
            Task.Run(() =>
            {
                // Admin: refresh conversation list for badge updates
                if (_isAdmin) LoadAdminConversationList();

                // Poll new messages for open conversation
                if (string.IsNullOrEmpty(_selectedRole)) return;

                var newMsgs = FetchMessages(fromId: _lastMessageId, markRead: false);
                if (newMsgs.Count == 0) return;

                // Update last ID
                _lastMessageId = newMsgs[^1].Id;

                // Mark read since we're viewing it
                MarkCurrentRead();

                // Toast for received messages (not sent by me)
                foreach (var m in newMsgs)
                {
                    if (m.SenderRole != _myRole)
                    {
                        string who = m.IsBroadcast
                            ? "📢 Admin Broadcast"
                            : $"New message from {m.SenderName}";
                        ShowToast(who);
                        break;
                    }
                }

                if (InvokeRequired)
                    Invoke(() => AppendNewMessages(newMsgs));
                else
                    AppendNewMessages(newMsgs);
            });
        }

        void AppendNewMessages(List<MsgRow> msgs)
        {
            _flowMsgs.SuspendLayout();
            foreach (var m in msgs)
                _flowMsgs.Controls.Add(BuildBubble(m));
            _flowMsgs.ResumeLayout();
            if (_isNearBottom) ScrollToBottom();
        }

        void MarkCurrentRead()
        {
            try
            {
                using var conn = new MySqlConnection(CONN);
                conn.Open();
                string sql;
                MySqlCommand cmd;
                if (_isAdmin)
                {
                    sql = "UPDATE tbl_StaffMessages SET IsRead=1 WHERE SenderRole=@r AND ReceiverRole='Administrator' AND IsRead=0;";
                    cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@r", _selectedRole);
                }
                else
                {
                    sql = "UPDATE tbl_StaffMessages SET IsRead=1 WHERE SenderRole='Administrator' AND (ReceiverRole=@r OR ReceiverRole='All') AND IsRead=0;";
                    cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@r", _myRole);
                }
                cmd.ExecuteNonQuery();
            }
            catch { }
        }

        // ═════════════════════════════════════════════════════════════
        //  SEND MESSAGE
        // ═════════════════════════════════════════════════════════════
        void SendMessage()
        {
            string msg = _txtInput.Text.Trim();
            if (string.IsNullOrEmpty(msg)) return;
            if (!_isAdmin && string.IsNullOrEmpty(_selectedRole)) return;

            string receiver = _isAdmin ? _selectedRole : "Administrator";
            _txtInput.Clear();
            _txtInput.Focus();

            Task.Run(() =>
            {
                try
                {
                    using var conn = new MySqlConnection(CONN);
                    conn.Open();
                    var cmd = new MySqlCommand(
                        "INSERT INTO tbl_StaffMessages " +
                        "(SenderRole, SenderName, ReceiverRole, Message, SentAt, IsRead) " +
                        "VALUES (@sRole, @sName, @rRole, @msg, NOW(), 0);", conn);
                    cmd.Parameters.AddWithValue("@sRole", _myRole);
                    cmd.Parameters.AddWithValue("@sName", _myName);
                    cmd.Parameters.AddWithValue("@rRole", receiver);
                    cmd.Parameters.AddWithValue("@msg",   msg);
                    cmd.ExecuteNonQuery();

                    // Get inserted ID
                    long newId = 0;
                    using (var idCmd = new MySqlCommand("SELECT LAST_INSERT_ID();", conn))
                        newId = Convert.ToInt64(idCmd.ExecuteScalar());
                    _lastMessageId = (int)newId;

                    var row = new MsgRow((int)newId, _myRole, _myName, msg, DateTime.Now, false);

                    if (InvokeRequired) Invoke(() => AppendBubble(row));
                    else AppendBubble(row);
                }
                catch (Exception ex)
                {
                    if (InvokeRequired)
                        Invoke(() => MessageBox.Show("Send failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning));
                }
            });
        }

        void AppendBubble(MsgRow m)
        {
            _flowMsgs.Controls.Add(BuildBubble(m));
            _isNearBottom = true;
            ScrollToBottom();
        }

        // ═════════════════════════════════════════════════════════════
        //  BROADCAST
        // ═════════════════════════════════════════════════════════════
        void SendBroadcast()
        {
            string msg = _txtInput.Text.Trim();

            if (string.IsNullOrEmpty(msg))
            {
                using var dlg = new Form
                {
                    Text            = "Broadcast Message",
                    Size            = new Size(420, 200),
                    StartPosition   = FormStartPosition.CenterParent,
                    FormBorderStyle = FormBorderStyle.FixedDialog,
                    MaximizeBox     = false,
                    MinimizeBox     = false,
                    BackColor       = C_Forest
                };
                var tb = new TextBox
                {
                    Multiline       = true,
                    Size            = new Size(360, 64),
                    Location        = new Point(20, 20),
                    Font            = new Font("Segoe UI", 10f),
                    PlaceholderText = "Type broadcast message…",
                    BorderStyle     = BorderStyle.FixedSingle
                };
                var btn = new Button
                {
                    Text      = "📢  Send Broadcast to All Staff",
                    Size      = new Size(360, 40),
                    Location  = new Point(20, 100),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = C_Gold,
                    ForeColor = C_Forest,
                    Font      = new Font("Segoe UI", 10f, FontStyle.Bold),
                    Cursor    = Cursors.Hand
                };
                btn.FlatAppearance.BorderSize = 0;
                btn.Click += (s, e) => { msg = tb.Text.Trim(); dlg.Close(); };
                dlg.Controls.AddRange(new Control[] { tb, btn });
                dlg.ShowDialog();
                if (string.IsNullOrEmpty(msg)) return;
            }

            _txtInput.Clear();

            Task.Run(() =>
            {
                try
                {
                    using var conn = new MySqlConnection(CONN);
                    conn.Open();
                    var cmd = new MySqlCommand(
                        "INSERT INTO tbl_StaffMessages " +
                        "(SenderRole, SenderName, ReceiverRole, Message, SentAt, IsRead) " +
                        "VALUES ('Administrator', @sName, 'All', @msg, NOW(), 0);", conn);
                    cmd.Parameters.AddWithValue("@sName", _myName);
                    cmd.Parameters.AddWithValue("@msg",   msg);
                    cmd.ExecuteNonQuery();

                    long newId = 0;
                    using (var idCmd = new MySqlCommand("SELECT LAST_INSERT_ID();", conn))
                        newId = Convert.ToInt64(idCmd.ExecuteScalar());
                    _lastMessageId = (int)newId;

                    var row = new MsgRow((int)newId, "Administrator", _myName, msg, DateTime.Now, true);
                    if (InvokeRequired) Invoke(() => AppendBubble(row));
                    else AppendBubble(row);
                }
                catch (Exception ex)
                {
                    if (InvokeRequired)
                        Invoke(() => MessageBox.Show("Broadcast failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning));
                }
            });
        }

        // ═════════════════════════════════════════════════════════════
        //  BUBBLE BUILDER
        // ═════════════════════════════════════════════════════════════
        Panel BuildBubble(MsgRow m)
        {
            bool isMine      = m.SenderRole == _myRole;
            bool isBroadcast = m.IsBroadcast;

            int availW   = Math.Max((_flowMsgs.ClientSize.Width > 0 ? _flowMsgs.ClientSize.Width : 560) - 32, 200);
            int maxBubW  = (int)(availW * 0.72);

            using var tmpFont = new Font("Segoe UI", 10f);
            SizeF measured = TextRenderer.MeasureText(m.Message, tmpFont,
                new Size(maxBubW - 32, int.MaxValue),
                TextFormatFlags.WordBreak | TextFormatFlags.NoPadding);

            int bubW = Math.Min((int)measured.Width + 42, maxBubW);
            int bubH = (int)measured.Height + 28;

            Color bubBg  = isBroadcast ? C_BroadcastBg
                         : isMine      ? C_SentBubble
                                       : C_RecvBubble;
            Color bubFg  = isBroadcast ? C_BroadcastFg
                         : isMine      ? C_Cream
                                       : C_Text;

            int wrapH    = bubH + ((!isMine || isBroadcast) ? 42 : 20);
            var wrap     = new Panel
            {
                Size      = new Size(availW, wrapH),
                BackColor = Color.Transparent,
                Margin    = new Padding(0, 2, 0, 3)
            };

            // Sender name (above received bubbles)
            if (!isMine || isBroadcast)
            {
                string dispName = isBroadcast ? "📢  Admin Broadcast" : m.SenderName;
                Color  nameCol  = isBroadcast ? Color.FromArgb(160, 100, 8) : C_Muted;
                wrap.Controls.Add(new Label
                {
                    Text      = dispName,
                    Font      = new Font("Segoe UI", 7.5f, FontStyle.Bold),
                    ForeColor = nameCol,
                    AutoSize  = true,
                    Location  = new Point(14, 2),
                    BackColor = Color.Transparent
                });
            }

            int bubTop = (!isMine || isBroadcast) ? 20 : 4;
            int bubX   = (isMine && !isBroadcast) ? availW - bubW - 4 : 8;

            // Bubble panel (custom painted rounded rect)
            var bubble = new Panel
            {
                Size      = new Size(bubW, bubH),
                Location  = new Point(bubX, bubTop),
                BackColor = Color.Transparent
            };

            string  bubMsg    = m.Message;
            Color   capBubBg  = bubBg;
            Color   capBubFg  = bubFg;
            bool    capIsMine = isMine;
            bool    capIsBcast = isBroadcast;
            int     capBubW   = bubW;
            int     capBubH   = bubH;

            bubble.Paint += (s, e) =>
            {
                var g = e.Graphics;
                g.SmoothingMode     = SmoothingMode.AntiAlias;
                g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

                using var path = RoundPath(
                    new Rectangle(0, 0, capBubW - 1, capBubH - 1), 14);
                using var bgBr = new SolidBrush(capBubBg);
                g.FillPath(bgBr, path);

                if (capIsBcast)
                {
                    using var borderPen = new Pen(Color.FromArgb(212, 160, 23), 1.2f);
                    g.DrawPath(borderPen, path);
                }
                else if (!capIsMine)
                {
                    using var borderPen = new Pen(C_Border, 0.8f);
                    g.DrawPath(borderPen, path);
                }

                using var fgBr = new SolidBrush(capBubFg);
                using var msgFont = new Font("Segoe UI", 10f);
                g.DrawString(bubMsg, msgFont, fgBr,
                    new RectangleF(14, 12, capBubW - 28, capBubH - 18));
            };
            wrap.Controls.Add(bubble);

            // Timestamp
            string timeStr = m.SentAt.ToString("h:mm tt");
            var    lblTime = new Label
            {
                Text      = timeStr,
                Font      = new Font("Segoe UI", 7f),
                ForeColor = C_Muted,
                AutoSize  = true,
                BackColor = Color.Transparent,
                Location  = (isMine && !isBroadcast)
                    ? new Point(availW - bubW - 4, bubTop + bubH + 2)
                    : new Point(12, bubTop + bubH + 2)
            };
            wrap.Controls.Add(lblTime);

            return wrap;
        }

        // ── Date separator ────────────────────────────────────────────
        Panel BuildDateSeparator(DateTime date)
        {
            string txt = date.Date == DateTime.Today   ? "Today"
                       : date.Date == DateTime.Today.AddDays(-1) ? "Yesterday"
                       : date.ToString("MMMM d, yyyy");

            int availW = Math.Max((_flowMsgs.ClientSize.Width > 0 ? _flowMsgs.ClientSize.Width : 560) - 32, 200);
            var pnl = new Panel
            {
                Size      = new Size(availW, 30),
                BackColor = Color.Transparent,
                Margin    = new Padding(0, 6, 0, 6)
            };
            pnl.Paint += (s, e) =>
            {
                var g = e.Graphics;
                int mid = pnl.Height / 2;
                using var pen  = new Pen(Color.FromArgb(200, C_Border), 1f);
                g.DrawLine(pen, 0, mid, pnl.Width, mid);

                using var font = new Font("Segoe UI", 8f, FontStyle.Bold);
                SizeF sz = g.MeasureString(txt, font);
                int   lx = (pnl.Width - (int)sz.Width - 16) / 2;
                using var bgBr = new SolidBrush(C_Sand);
                g.FillRectangle(bgBr, lx - 2, 0, (int)sz.Width + 20, pnl.Height);
                using var fgBr = new SolidBrush(C_Muted);
                g.DrawString(txt, font, fgBr, lx + 8, (pnl.Height - (int)sz.Height) / 2);
            };
            return pnl;
        }

        // ═════════════════════════════════════════════════════════════
        //  SCROLL
        // ═════════════════════════════════════════════════════════════
        void ScrollToBottom()
        {
            if (_flowMsgs.Controls.Count > 0)
            {
                var last = _flowMsgs.Controls[_flowMsgs.Controls.Count - 1];
                _flowMsgs.ScrollControlIntoView(last);
            }
        }

        // ═════════════════════════════════════════════════════════════
        //  HELPERS
        // ═════════════════════════════════════════════════════════════
        static GraphicsPath RoundPath(Rectangle r, int radius)
        {
            int d    = radius * 2;
            var path = new GraphicsPath();
            path.AddArc(r.X,         r.Y,          d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y,          d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d,   0, 90);
            path.AddArc(r.X,         r.Bottom - d, d, d,  90, 90);
            path.CloseFigure();
            return path;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _pollTimer?.Stop();
                _pollTimer?.Dispose();
                _toastTimer?.Stop();
                _toastTimer?.Dispose();
            }
            base.Dispose(disposing);
        }

        // ── Data record ───────────────────────────────────────────────
        record MsgRow(int Id, string SenderRole, string SenderName,
                      string Message, DateTime SentAt, bool IsBroadcast);
    }
}
