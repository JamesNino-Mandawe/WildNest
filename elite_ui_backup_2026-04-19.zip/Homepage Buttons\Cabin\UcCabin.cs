﻿using System;
using System.Linq;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class UcCabin : UserControl
    {
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

        // ═══════════════════════════════════════════════
        //  CABIN DATA
        // ═══════════════════════════════════════════════
        private class CabinInfo
        {
            public string Name, Type, Zone, Desc, Icon, Price, Status, Cap, View, MinStay, Cancel;
            public Color BgTop, BgBot;
            public string[] Amenities, Tags;
        }

        private readonly CabinInfo[] _cabins = new CabinInfo[]
        {
            new CabinInfo {
                Name="Safari Lodge Suite", Type="Lodge", Zone="Predator Ridge",
                Icon="🏰", Price="₱9,500", Status="Available", Cap="4", View="Savanna", MinStay="2 nights", Cancel="Free cancellation",
                Desc="The pinnacle of safari luxury. A premium lodge suite with private pool, personal butler, panoramic savanna deck and sunrise breakfast service.",
                BgTop=Color.FromArgb(60,40,8), BgBot=Color.FromArgb(38,25,5),
                Amenities=new[]{"🏊 Private Pool","🧑‍🍳 Butler","🌅 Panoramic","🛏 Suite","🍽️ Breakfast","🚗 Transfer"},
                Tags=new[]{"Premium","Private pool","Butler"}
            },
            new CabinInfo {
                Name="Lakeside Lodge", Type="Lodge", Zone="Aquatic Zone",
                Icon="🏠", Price="₱6,500", Status="Available", Cap="3", View="Lakefront", MinStay="2 nights", Cancel="Free cancellation",
                Desc="Elevated on stilts above the glassy lake, this lodge offers 180-degree water views, kayak access, and a fire pit dock perfect for sunset evenings.",
                BgTop=Color.FromArgb(8,35,65), BgBot=Color.FromArgb(5,20,45),
                Amenities=new[]{"🚣 Kayaks","🔥 Fire Pit","🌊 Lake View","🐟 Fishing","🛶 Dock","🌅 Sunrise"},
                Tags=new[]{"Lake view","Kayaks","Fire pit"}
            },
            new CabinInfo {
                Name="Forest Cabin A", Type="Forest Cabin", Zone="Jungle Canopy",
                Icon="🌲", Price="₱4,200", Status="Available", Cap="4", View="Forest", MinStay="2 nights", Cancel="Free cancellation",
                Desc="A secluded timber cabin tucked beneath the jungle canopy. Warm interiors, stone fireplace, wraparound porch with hammocks, and a private forest trail.",
                BgTop=Color.FromArgb(12,40,15), BgBot=Color.FromArgb(6,22,8),
                Amenities=new[]{"🔥 Fireplace","🛁 Rain Shower","🍳 Kitchenette","🌙 Star Deck","🪵 Timber Deck","👨‍👩‍👧 Family"},
                Tags=new[]{"Forest view","Family","Cozy"}
            },
            new CabinInfo {
                Name="Forest Cabin B", Type="Forest Cabin", Zone="Conservation Hub",
                Icon="🌳", Price="₱3,800", Status="Available", Cap="3", View="Forest", MinStay="1 night", Cancel="Free cancellation",
                Desc="A cosy forest retreat nestled in the conservation hub. Surrounded by ancient hardwoods with a private deck overlooking the tree line at dawn.",
                BgTop=Color.FromArgb(18,45,18), BgBot=Color.FromArgb(8,28,8),
                Amenities=new[]{"🌿 Eco Shower","🔥 Fire Pit","☕ Barista Kit","🦋 Nature Trail","🌙 Star Deck","🛏 Queen Bed"},
                Tags=new[]{"Forest view","Romantic","Eco-friendly"}
            },
            new CabinInfo {
                Name="Safari Tent Alpha", Type="Glamping Tent", Zone="Golden Savanna",
                Icon="⛺", Price="₱5,200", Status="Available", Cap="2", View="Savanna", MinStay="1 night", Cancel="Free cancellation",
                Desc="Luxury canvas tent overlooking the open savanna. King bed, en-suite bath and a private veranda where zebras graze at dawn.",
                BgTop=Color.FromArgb(72,50,8), BgBot=Color.FromArgb(45,30,5),
                Amenities=new[]{"🛏 King Bed","🚿 En-Suite","🌅 Savanna View","🦓 Safari","🍷 Mini Bar","🌙 Star Gazing"},
                Tags=new[]{"Savanna view","Luxury","Couple"}
            },
            new CabinInfo {
                Name="Savanna Tent", Type="Glamping Tent", Zone="Golden Savanna",
                Icon="🏕️", Price="₱5,000", Status="Available", Cap="2", View="Savanna", MinStay="1 night", Cancel="Free cancellation",
                Desc="A romantic glamping retreat in the heart of the savanna. Fall asleep to the sounds of wildlife with plush bedding and open-sky bathing.",
                BgTop=Color.FromArgb(80,56,10), BgBot=Color.FromArgb(50,34,6),
                Amenities=new[]{"🛏 King Bed","🛁 Outdoor Bath","🌅 Sunset View","🦁 Wildlife","🕯️ Candlelit","🌿 Organic"},
                Tags=new[]{"Savanna view","Glamping","Couple"}
            },
            new CabinInfo {
                Name="Treetop Treehouse", Type="Treehouse", Zone="Nocturnal Trail",
                Icon="🌴", Price="₱4,800", Status="Limited", Cap="2", View="Forest", MinStay="1 night", Cancel="Free cancellation",
                Desc="Perched high on the nocturnal trail, this treehouse offers a rare look at the sanctuary after dark. Fall asleep to the sounds of the night forest.",
                BgTop=Color.FromArgb(10,30,50), BgBot=Color.FromArgb(5,15,35),
                Amenities=new[]{"🌙 Night View","🐦 Bird Watch","🚣 Kayak","✨ Starlit","🛏 Queen Bed","🌿 Nature"},
                Tags=new[]{"Night trail","Unique","Treehouse"}
            },
            new CabinInfo {
                Name="Canopy Treehouse", Type="Treehouse", Zone="Jungle Canopy",
                Icon="🌳", Price="₱3,500", Status="Available", Cap="2", View="Forest", MinStay="1 night", Cancel="Free cancellation",
                Desc="Perched 12 metres above the jungle floor, Canopy Treehouse offers an immersive treetop escape with an open-air sleeping deck and sweeping forest views.",
                BgTop=Color.FromArgb(18,52,18), BgBot=Color.FromArgb(8,28,8),
                Amenities=new[]{"🌿 Eco Shower","🔥 Fire Pit","☕ Barista Kit","🦋 Nature Trail","🌙 Star Deck","🛏 Queen Bed"},
                Tags=new[]{"Forest view","Romantic","Eco-friendly"}
            },
            new CabinInfo {
                Name="Eco Bungalow", Type="Eco Bungalow", Zone="Conservation Hub",
                Icon="🌿", Price="₱2,500", Status="Available", Cap="2", View="Forest", MinStay="1 night", Cancel="Free cancellation",
                Desc="A zero-waste sanctuary powered entirely by solar. Budget-friendly without compromising on comfort — recycled timber, organic linen, and a permaculture garden.",
                BgTop=Color.FromArgb(10,45,25), BgBot=Color.FromArgb(5,28,14),
                Amenities=new[]{"☀️ Solar Power","♻️ Zero Waste","🌱 Garden","🌿 Organic","💧 Rainwater","🏡 Eco Design"},
                Tags=new[]{"Eco-friendly","Solar","Budget-friendly"}
            },
        };

        private readonly CabinInfo _signature = new CabinInfo
        {
            Name = "The Sanctuary Villa",
            Type = "Premium Villa",
            Zone = "Aquatic Zone",
            Icon = "🏯",
            Price = "₱11,000",
            Status = "Available",
            Cap = "6",
            View = "Panoramic",
            MinStay = "3 nights",
            Cancel = "Free cancellation",
            Desc = "WildNest's crown jewel — an exclusive three-bedroom villa with a full infinity pool and sweeping panoramic views of the entire savanna. Private walled garden, full kitchen, and a dedicated villa host for the duration of your stay.",
            BgTop = Color.FromArgb(10, 10, 45),
            BgBot = Color.FromArgb(5, 5, 30),
            Amenities = new[] { "🏊 Infinity Pool", "🛏 3 Bedrooms", "🧑‍🍳 Villa Host", "👥 6 Guests", "🌿 Private Garden", "🚗 Buggy Transfer" },
            Tags = new[] { "Premium", "Infinity Pool", "Villa Host" }
        };

        private string _activeFilter = "All";
        private readonly Panel[] _cabinPanels = new Panel[9];

        private static readonly Color C_BG = Color.FromArgb(240, 237, 232);
        private static readonly Color C_DARK = Color.FromArgb(7, 26, 14);
        private static readonly Color C_GOLD = Color.FromArgb(212, 160, 23);
        private static readonly Color C_GREEN = Color.FromArgb(27, 67, 50);
        private static readonly Color C_CREAM = Color.FromArgb(248, 244, 239);

        // Luxury dark palette (same as UcExperience)
        private static readonly Color C_GOLD_LIGHT = Color.FromArgb(245, 200, 80);
        private static readonly Color C_CARD_BG = Color.FromArgb(12, 30, 18);
        private static readonly Color C_CARD_MID = Color.FromArgb(18, 44, 26);

        private string _breadcrumb = "Viewing: All Cabins  —  10 Accommodations";

        // ═══════════════════════════════════════════════
        //  CONSTRUCTOR
        // ═══════════════════════════════════════════════
        public UcCabin()
        {
            InitializeComponent();
            this.AutoScroll = false;
            this.AutoScrollMinSize = Size.Empty;
            this.Dock = DockStyle.Fill;
            this.BackColor = C_BG;
            this.DoubleBuffered = true;
            BuildUI();
            SetupNewUI();
        }

        // ═══════════════════════════════════════════════
        //  BuildUI
        // ═══════════════════════════════════════════════
        private void BuildUI()
        {
            pnlHero.Paint += PaintHeroBackground;

            lblLocation.Font = new Font("Segoe UI", 9f);
            lblLocation.ForeColor = C_GOLD;
            lblLocation.BackColor = Color.Transparent;

            lblHeroTitle.Font = new Font("Georgia", 40f, FontStyle.Bold);
            lblHeroTitle.ForeColor = C_CREAM;
            lblHeroTitle.BackColor = Color.Transparent;
            lblHeroTitle.Text = "";
            lblHeroTitle.AutoSize = false;
            lblHeroTitle.Size = new Size(760, 76);
            lblHeroTitle.Paint -= PaintCabinHeroTitle;
            lblHeroTitle.Paint += PaintCabinHeroTitle;

            lblHeroSub.Font = new Font("Segoe UI", 11f);
            lblHeroSub.ForeColor = Color.FromArgb(160, 248, 244, 239);
            lblHeroSub.BackColor = Color.Transparent;

            Action layoutHero = () =>
            {
                int cx = pnlHero.Width / 2;
                lblLocation.Location = new Point(cx - lblLocation.PreferredWidth / 2, 120);
                lblHeroTitle.Location = new Point(cx - lblHeroTitle.Width / 2, 156);
                lblHeroSub.Location = new Point(cx - lblHeroSub.PreferredWidth / 2, 270);
                pnlChecker.Location = new Point(cx - pnlChecker.Width / 2, 330);
            };
            pnlHero.HandleCreated += (s, e) => layoutHero();
            pnlHero.Resize += (s, e) => layoutHero();

            pnlChecker.BackColor = Color.Transparent;
            pnlChecker.Paint += (s, pe) =>
            {
                pe.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                Rectangle rect = pnlChecker.ClientRectangle;
                rect.Inflate(-1, -1);
                int r = 20;
                GraphicsPath path = new GraphicsPath();
                path.AddArc(rect.X, rect.Y, r, r, 180, 90);
                path.AddArc(rect.Right - r, rect.Y, r, r, 270, 90);
                path.AddArc(rect.Right - r, rect.Bottom - r, r, r, 0, 90);
                path.AddArc(rect.X, rect.Bottom - r, r, r, 90, 90);
                path.CloseFigure();
                using (var fill = new SolidBrush(Color.FromArgb(25, 52, 32)))
                    pe.Graphics.FillPath(fill, path);
                using (var border = new Pen(C_GOLD, 1.5f))
                    pe.Graphics.DrawPath(border, path);
                int[] divX = { 205, 395, 550 };
                foreach (int x in divX)
                    pe.Graphics.DrawLine(new Pen(Color.FromArgb(60, 255, 255, 255), 1),
                        x, rect.Y + 15, x, rect.Bottom - 15);
            };

            lblCheckIn.Text = "CHECK-IN"; lblCheckIn.Font = new Font("Segoe UI", 8f, FontStyle.Bold);
            lblCheckIn.ForeColor = C_GOLD; lblCheckIn.BackColor = Color.Transparent;
            lblCheckIn.Location = new Point(30, 12);

            lblCheckOut.Text = "CHECK-OUT"; lblCheckOut.Font = new Font("Segoe UI", 8f, FontStyle.Bold);
            lblCheckOut.ForeColor = C_GOLD; lblCheckOut.BackColor = Color.Transparent;
            lblCheckOut.Location = new Point(218, 12);

            lblGuests.Text = "GUESTS"; lblGuests.Font = new Font("Segoe UI", 8f, FontStyle.Bold);
            lblGuests.ForeColor = C_GOLD; lblGuests.BackColor = Color.Transparent;
            lblGuests.Location = new Point(404, 12);

            dtpCheckIn.Location = new Point(30, 36);
            dtpCheckOut.Location = new Point(218, 36);
            cmbGuests.Location = new Point(404, 36);

            StyleInput(dtpCheckIn);
            StyleInput(dtpCheckOut);
            StyleInput(cmbGuests);

            btnCheckAvailability.Size = new Size(160, 44);
            btnCheckAvailability.Location = new Point(560, 23);
            btnCheckAvailability.FlatStyle = FlatStyle.Flat;
            btnCheckAvailability.BackColor = Color.Transparent;
            btnCheckAvailability.ForeColor = Color.Transparent;
            btnCheckAvailability.FlatAppearance.BorderSize = 0;
            btnCheckAvailability.Cursor = Cursors.Hand;
            btnCheckAvailability.Paint += (s, pe) =>
            {
                pe.Graphics.SmoothingMode = SmoothingMode.HighQuality;
                pe.Graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
                Rectangle rect = btnCheckAvailability.ClientRectangle;
                rect.Inflate(-1, -1);
                int rr = rect.Height;
                GraphicsPath path = new GraphicsPath();
                path.AddArc(rect.X, rect.Y, rr, rr, 90, 180);
                path.AddArc(rect.Right - rr, rect.Y, rr, rr, 270, 180);
                path.CloseFigure();
                using (var fill = new SolidBrush(C_GOLD))
                    pe.Graphics.FillPath(fill, path);
                TextRenderer.DrawText(pe.Graphics, "Check Availability",
                    new Font("Segoe UI", 10f, FontStyle.Bold),
                    btnCheckAvailability.ClientRectangle,
                    Color.FromArgb(20, 45, 28),
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };
        }

        private Panel _pnlGrid;
        private Panel _pnlFooter;

        private void SetupNewUI()
        {
            pnlBody.Dock = DockStyle.Top;
            pnlBody.Height = 900; // initial; updated dynamically
            pnlBody.BackColor = C_BG;

            pnlSideIcons.Dock = DockStyle.Left;
            pnlSideIcons.Width = 75;
            pnlSideIcons.BackColor = C_DARK;

            pnlMain.Dock = DockStyle.Top;
            pnlMain.BackColor = C_BG;
            pnlMain.AutoScroll = false;

            pnlSignature.Dock = DockStyle.None;
            pnlSignature.Height = 260;
            pnlSignature.BackColor = C_BG;
            pnlSignature.Padding = new Padding(0);

            picSignature.Dock = DockStyle.Fill;
            picSignature.BackColor = Color.Transparent;
            picSignature.Cursor = Cursors.Hand;
            picSignature.Paint += PaintSignature;
            picSignature.Click += (s, e) => ShowDetail(_signature);

            _pnlGrid = new Panel { BackColor = C_BG, Location = new Point(0, 268), AutoSize = false };

            _pnlFooter = new Panel { BackColor = C_DARK, Height = 52, Location = new Point(0, 600) };
            _pnlFooter.Paint += (s, pe) =>
            {
                var g = pe.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
                using (var pen = new Pen(Color.FromArgb(60, C_GOLD), 1f))
                    g.DrawLine(pen, 0, 0, _pnlFooter.Width, 0);
                using (var br = new SolidBrush(Color.FromArgb(80, C_GOLD)))
                    g.FillEllipse(br, 28, _pnlFooter.Height / 2 - 3, 6, 6);
                using (var br = new SolidBrush(Color.FromArgb(80, C_GOLD)))
                    g.FillEllipse(br, _pnlFooter.Width - 34, _pnlFooter.Height / 2 - 3, 6, 6);
                TextRenderer.DrawText(g, "✦  You've explored all our accommodations  ✦",
                    new Font("Georgia", 9.5f, FontStyle.Italic), _pnlFooter.ClientRectangle,
                    Color.FromArgb(120, C_GOLD), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };

            flpCabins.Visible = false;
            flpCabins.AutoScroll = false;
            flpCabins.Enabled = false;
            pnlMain.Controls.Add(_pnlGrid);
            pnlMain.Controls.Add(_pnlFooter);

            pnlMain.Resize += (s, e) => DoGridLayout(_activeFilter);

            pnlStatusBar.BackColor = C_DARK;
            pnlStatusBar.Controls.Clear();
            pnlStatusBar.Paint += PaintStatusBar;

            Panel[] panels = { pnlCabin1, pnlCabin2, pnlCabin3,
                                pnlCabin4, pnlCabin5, pnlCabin6,
                                pnlCabin7, pnlCabin8, pnlCabin9 };
            for (int i = 0; i < 9; i++)
            {
                _cabinPanels[i] = panels[i];
                flpCabins.Controls.Remove(panels[i]);
                _pnlGrid.Controls.Add(panels[i]);
                SetupCabinPanel(panels[i], _cabins[i]);
            }

            SetupFilterButtons();
            UpdateBreadcrumb("All", 9);
            pnlMain.HandleCreated += (s, e) => DoGridLayout("All");
        }

        private void DoGridLayout(string filter)
        {
            if (pnlMain.Width <= 0) return;
            const int pad = 14, gap = 12, cardH = 280;
            int totalW = pnlMain.Width - pad * 2;
            int cardW = (totalW - gap * 2) / 3;
            if (cardW < 180) cardW = 180;

            bool sigVisible = filter == "All" || filter == "Premium Villa";
            pnlSignature.Dock = DockStyle.None;
            pnlSignature.Location = new Point(0, 0);
            pnlSignature.Width = pnlMain.Width;
            pnlSignature.Height = 260;
            pnlSignature.Visible = sigVisible;

            int gridTop = sigVisible ? 268 : 0;
            _pnlGrid.Location = new Point(0, gridTop);
            _pnlGrid.Width = pnlMain.Width;

            int visIdx = 0;
            for (int i = 0; i < 9; i++)
            {
                bool show = filter == "All" || _cabins[i].Type == filter;
                _cabinPanels[i].Visible = show;
                if (show)
                {
                    int col = visIdx % 3, row = visIdx / 3;
                    _cabinPanels[i].Size = new Size(cardW, cardH);
                    _cabinPanels[i].Location = new Point(pad + col * (cardW + gap), pad + row * (cardH + gap));
                    visIdx++;
                }
            }

            int rows = (visIdx + 2) / 3;
            int gridH = pad * 2 + rows * (cardH + gap) - gap + 20;
            _pnlGrid.Height = gridH;

            int footerY = gridTop + gridH + 6;
            _pnlFooter.Location = new Point(0, footerY);
            _pnlFooter.Width = pnlMain.Width;
            _pnlFooter.Height = 52;
            int contentH = _pnlFooter.Location.Y + _pnlFooter.Height;
            pnlBody.Height = contentH + 56;   // extra bottom room so the final cards/footer never clip
            pnlSideIcons.Height = pnlBody.Height;
            this.Height = pnlBody.Bottom + 24;
            this.MinimumSize = new Size(0, this.Height);

        }

        // ═══════════════════════════════════════════════
        //  STATUS BAR
        // ═══════════════════════════════════════════════
        private void PaintStatusBar(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            var p = (Panel)sender;

            using (var pen = new Pen(Color.FromArgb(100, C_GOLD), 1.5f))
                g.DrawLine(pen, 0, 0, p.Width, 0);
            using (var br = new SolidBrush(C_GOLD))
                g.FillEllipse(br, 18, p.Height / 2 - 4, 7, 7);

            string[] parts = _breadcrumb.Split(new[] { "  —  " }, StringSplitOptions.None);
            int startX = 36;
            if (parts.Length == 2)
            {
                var f1 = new Font("Segoe UI", 10f);
                var f2 = new Font("Georgia", 11f, FontStyle.Italic);
                var sep = "  —  ";
                var sz1 = TextRenderer.MeasureText(g, parts[0] + sep, f1);
                TextRenderer.DrawText(g, parts[0] + sep, f1,
                    new Rectangle(startX, 0, sz1.Width + 10, p.Height),
                    Color.FromArgb(170, C_CREAM), TextFormatFlags.VerticalCenter | TextFormatFlags.Left);
                TextRenderer.DrawText(g, parts[1], f2,
                    new Rectangle(startX + sz1.Width, 0, 360, p.Height),
                    C_GOLD, TextFormatFlags.VerticalCenter | TextFormatFlags.Left);
            }

            string[] chips = { "⭐ 4.9 Rating", "✅ 8 Available" };
            int rx = p.Width - 16;
            foreach (var chip in chips)
            {
                var cf = new Font("Segoe UI", 8.5f);
                var csz = TextRenderer.MeasureText(g, chip, cf);
                rx -= csz.Width + 20;
                var cr = new Rectangle(rx, p.Height / 2 - 11, csz.Width + 16, 22);
                using (var path = RoundRect(cr, 11))
                using (var br = new SolidBrush(Color.FromArgb(38, C_GOLD)))
                    g.FillPath(br, path);
                TextRenderer.DrawText(g, chip, cf, cr, C_GOLD,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                rx -= 8;
            }

            using (var pen = new Pen(Color.FromArgb(35, C_GOLD), 1f))
                g.DrawLine(pen, 0, p.Height - 1, p.Width, p.Height - 1);
        }

        private void UpdateBreadcrumb(string filter, int count)
        {
            string label = filter == "All" ? "All Cabins" : filter + "s";
            int total = filter == "All" ? count + 1 : count;
            _breadcrumb = $"Viewing: {label}  —  {total} Accommodation{(total != 1 ? "s" : "")}";
            pnlStatusBar.Invalidate();
        }

        // ═══════════════════════════════════════════════
        //  FILTER BUTTONS
        // ═══════════════════════════════════════════════
        private void SetupFilterButtons()
        {
            var filters = new (Button btn, string emoji, string label, string filter)[]
            {
                (btnFilterAll,       "🏕️", "All",    "All"),
                (btnFilterTreehouse, "🌳", "Trees",  "Treehouse"),
                (btnFilterForest,    "🌲", "Forest", "Forest Cabin"),
                (btnFilterGlamping,  "⛺", "Glamp",  "Glamping Tent"),
                (btnFilterLodge,     "🏠", "Lodge",  "Lodge"),
                (btnFilterEco,       "🌿", "Eco",    "Eco Bungalow"),
                (btnFilterVilla,     "🏰", "Villa",  "Premium Villa"),
            };

            int y = 16;
            foreach (var (btn, emoji, label, filter) in filters)
            {
                btn.Location = new Point(5, y);
                btn.Size = new Size(65, 68);
                btn.FlatStyle = FlatStyle.Flat;
                btn.FlatAppearance.BorderSize = 0;
                btn.BackColor = Color.Transparent;
                btn.Cursor = Cursors.Hand;
                btn.Text = "";

                string capFilter = filter;
                string capEmoji = emoji;
                string capLabel = label;
                Button capBtn = btn;

                capBtn.Paint += (s, pe) =>
                    PaintFilterBtn(pe, capBtn, capEmoji, capLabel, capFilter == _activeFilter);

                capBtn.Click += (s, e) =>
                {
                    ApplyFilter(capFilter);
                    foreach (var (b, _, _, _) in filters) b.Invalidate();
                };
                capBtn.MouseEnter += (s, e) => capBtn.Invalidate();
                capBtn.MouseLeave += (s, e) => capBtn.Invalidate();

                y += 75;
            }
        }

        private void PaintFilterBtn(PaintEventArgs e, Button btn, string emoji, string label, bool active)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            var r = btn.ClientRectangle;

            if (active)
            {
                using (var path = RoundRect(new Rectangle(r.X + 2, r.Y + 2, r.Width - 4, r.Height - 4), 10))
                using (var br = new LinearGradientBrush(r, Color.FromArgb(55, C_GOLD), Color.FromArgb(18, C_GOLD), 90f))
                    g.FillPath(br, path);
                using (var path = RoundRect(new Rectangle(r.X + 2, r.Y + 2, r.Width - 4, r.Height - 4), 10))
                using (var pen = new Pen(Color.FromArgb(170, C_GOLD), 1.5f))
                    g.DrawPath(pen, path);
                using (var br = new SolidBrush(C_GOLD))
                    g.FillRectangle(br, r.X, r.Y + 14, 3, r.Height - 28);
            }
            else if (r.Contains(btn.PointToClient(Cursor.Position)))
            {
                using (var path = RoundRect(new Rectangle(r.X + 3, r.Y + 3, r.Width - 6, r.Height - 6), 10))
                using (var br = new SolidBrush(Color.FromArgb(22, 255, 255, 255)))
                    g.FillPath(br, path);
            }

            TextRenderer.DrawText(g, emoji, new Font("Segoe UI Emoji", 20f),
                new Rectangle(r.X, r.Y + 6, r.Width, 34),
                active ? C_GOLD : Color.FromArgb(150, C_CREAM), TextFormatFlags.HorizontalCenter);

            TextRenderer.DrawText(g, label,
                new Font("Segoe UI", 7f, active ? FontStyle.Bold : FontStyle.Regular),
                new Rectangle(r.X, r.Y + 42, r.Width, 18),
                active ? C_GOLD : Color.FromArgb(100, C_CREAM), TextFormatFlags.HorizontalCenter);
        }

        private void ApplyFilter(string filter)
        {
            _activeFilter = filter;
            int count = filter == "All" ? 9 : _cabins.Count(c => c.Type == filter);
            UpdateBreadcrumb(filter, count);
            DoGridLayout(filter);
        }

        // ═══════════════════════════════════════════════
        //  CABIN CARD — LUXURY DARK REDESIGN
        // ═══════════════════════════════════════════════
        private void SetupCabinPanel(Panel pnl, CabinInfo cabin)
        {
            pnl.Controls.Clear();
            pnl.Size = new Size(320, 280);
            pnl.Margin = new Padding(0);
            pnl.BackColor = Color.Transparent;
            pnl.Cursor = Cursors.Hand;

            var pic = new PictureBox { Dock = DockStyle.Fill, BackColor = Color.Transparent, Cursor = Cursors.Hand };
            pic.Paint += (s, e) => PaintCabinCard(e, pnl, cabin);
            pic.Click += (s, e) => ShowDetail(cabin);
            pic.MouseEnter += (s, e) => pnl.Invalidate(true);
            pic.MouseLeave += (s, e) => pnl.Invalidate(true);
            pnl.Controls.Add(pic);
        }

        private void PaintCabinCard(PaintEventArgs e, Panel pnl, CabinInfo cabin)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;

            bool hovered = pnl.RectangleToScreen(pnl.ClientRectangle).Contains(Cursor.Position);

            // ── layered drop shadow
            for (int sh = 6; sh >= 1; sh--)
            {
                int alpha = hovered ? (sh * 22) : (sh * 12);
                var sr = new Rectangle(4 + sh, 4 + sh, pnl.Width - 8, pnl.Height - 8);
                using (var path = RoundRect(sr, 16))
                using (var br = new SolidBrush(Color.FromArgb(alpha, 0, 0, 0)))
                    g.FillPath(br, path);
            }

            var r = new Rectangle(3, 3, pnl.Width - 7, pnl.Height - 7);

            // ── dark luxury card body
            using (var path = RoundRect(r, 16))
            using (var br = new LinearGradientBrush(r, C_CARD_BG, C_CARD_MID, 135f))
                g.FillPath(br, path);

            // ── gold border
            int borderAlpha = hovered ? 180 : 80;
            using (var path = RoundRect(r, 16))
            using (var pen = new Pen(Color.FromArgb(borderAlpha, C_GOLD), hovered ? 1.8f : 1.2f))
                g.DrawPath(pen, path);

            // ── image hero section
            int imgH = 130;
            var imgRect = new Rectangle(r.X, r.Y, r.Width, imgH);

            using (var imgPath = RoundRectTop(imgRect, 16))
            using (var br = new LinearGradientBrush(imgRect, cabin.BgTop, cabin.BgBot, 145f))
                g.FillPath(br, imgPath);

            // gold shimmer at top of image
            using (var shimmer = new LinearGradientBrush(
                new Rectangle(imgRect.X, imgRect.Y, imgRect.Width, 2),
                Color.Transparent, Color.FromArgb(100, C_GOLD_LIGHT), 0f))
            using (var pen = new Pen(shimmer, 1.5f))
                g.DrawLine(pen, imgRect.X, imgRect.Y + 1, imgRect.Right, imgRect.Y + 1);

            // ── icon
            TextRenderer.DrawText(g, cabin.Icon, new Font("Segoe UI Emoji", 44f),
                new Rectangle(imgRect.X, imgRect.Y, imgRect.Width, imgH),
                Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

            // gradient fade image into card body
            var fadeRect = new Rectangle(imgRect.X, imgRect.Bottom - 40, imgRect.Width, 40);
            using (var fade = new LinearGradientBrush(fadeRect, Color.Transparent, C_CARD_BG, 90f))
                g.FillRectangle(fade, fadeRect);

            // ── STATUS badge
            Color bdgBg = cabin.Status == "Available" ? Color.FromArgb(200, 14, 80, 52)
                        : cabin.Status == "Limited" ? Color.FromArgb(200, 120, 60, 0)
                                                       : Color.FromArgb(200, 120, 20, 20);
            Color bdgFg = cabin.Status == "Available" ? Color.FromArgb(168, 240, 216)
                        : cabin.Status == "Limited" ? Color.FromArgb(255, 210, 110)
                                                       : Color.FromArgb(255, 160, 160);
            var bdgRect = new Rectangle(imgRect.X + 10, imgRect.Y + 10, 82, 22);
            using (var path = RoundRect(bdgRect, 11))
            using (var br = new SolidBrush(bdgBg)) g.FillPath(br, path);
            using (var path = RoundRect(bdgRect, 11))
            using (var pen = new Pen(Color.FromArgb(60, bdgFg), 1f)) g.DrawPath(pen, path);
            TextRenderer.DrawText(g, "● " + cabin.Status, new Font("Segoe UI", 7.5f, FontStyle.Bold),
                bdgRect, bdgFg, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

            // ── Rating badge top-right
            var ratRect = new Rectangle(r.Right - 62, imgRect.Y + 10, 54, 22);
            using (var path = RoundRect(ratRect, 11))
            using (var br = new SolidBrush(Color.FromArgb(160, 0, 0, 0))) g.FillPath(br, path);
            using (var path = RoundRect(ratRect, 11))
            using (var pen = new Pen(Color.FromArgb(50, C_GOLD), 1f)) g.DrawPath(pen, path);
            TextRenderer.DrawText(g, "★ 4.9", new Font("Segoe UI", 7.5f, FontStyle.Bold),
                ratRect, C_GOLD, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

            // ── Zone label inside image bottom
            TextRenderer.DrawText(g, cabin.Zone.ToUpper(), new Font("Segoe UI", 6.5f, FontStyle.Bold),
                new Rectangle(imgRect.X + 10, imgRect.Bottom - 20, imgRect.Width - 20, 18),
                Color.FromArgb(160, C_GOLD), TextFormatFlags.Left);

            // ── BODY section
            int by = r.Y + imgH + 10;
            int bx = r.X + 14;
            int bw = r.Width - 28;

            // type label
            TextRenderer.DrawText(g, cabin.Type.ToUpper(),
                new Font("Segoe UI", 7.5f, FontStyle.Bold),
                new Rectangle(bx, by, bw, 16),
                C_GOLD,
                TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
            by += 19;

            // cabin name
            TextRenderer.DrawText(g, cabin.Name, new Font("Georgia", 13f, FontStyle.Bold),
                new Rectangle(bx, by, bw, 24),
                C_CREAM,
                TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
            by += 26;

            // guests · view
            string infoLine = $"Guests: {cabin.Cap}  ·  {cabin.View} View  ·  {cabin.Zone}";
            TextRenderer.DrawText(g, infoLine, new Font("Segoe UI", 7.5f),
                new Rectangle(bx, by, bw, 16),
                Color.FromArgb(130, C_CREAM),
                TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
            by += 18;

            // thin gold divider
            using (var pen = new Pen(Color.FromArgb(50, C_GOLD), 1f))
                g.DrawLine(pen, bx, by, r.Right - 14, by);
            by += 9;

            var bRect = new Rectangle(r.Right - 112, by, 100, 30);
            int priceW = Math.Max(92, bRect.X - bx - 8);

            // price
            TextRenderer.DrawText(g, cabin.Price, new Font("Georgia", 14f, FontStyle.Bold),
                new Rectangle(bx, by, priceW, 24),
                C_GOLD_LIGHT,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
            TextRenderer.DrawText(g, "/night", new Font("Segoe UI", 7f),
                new Rectangle(bx, by + 18, priceW, 14),
                Color.FromArgb(90, C_CREAM),
                TextFormatFlags.Left);

            // Book Now button
            using (var path = RoundRect(bRect, 15))
            using (var br = new LinearGradientBrush(bRect, C_GOLD, Color.FromArgb(190, 140, 10), 90f))
                g.FillPath(br, path);
            // inner highlight
            var bInner = new Rectangle(bRect.X + 2, bRect.Y + 1, bRect.Width - 4, bRect.Height / 2);
            using (var path = RoundRectTop(bInner, 13))
            using (var br = new SolidBrush(Color.FromArgb(40, 255, 255, 200)))
                g.FillPath(br, path);
            TextRenderer.DrawText(g, "Book Now", new Font("Segoe UI", 8.5f, FontStyle.Bold),
                bRect, Color.FromArgb(15, 35, 12),
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }

        private void PaintCabinHeroTitle(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

            using var font = new Font("Georgia", 46f, FontStyle.Bold);
            using var creamBrush = new SolidBrush(C_CREAM);
            using var goldBrush = new SolidBrush(C_GOLD);

            string left = "Cabins &";
            string right = "Stays";

            SizeF leftSize = g.MeasureString(left, font, 1000, StringFormat.GenericTypographic);
            SizeF rightSize = g.MeasureString(right, font, 1000, StringFormat.GenericTypographic);
            float total = leftSize.Width + rightSize.Width;
            float x = (lblHeroTitle.Width - total) / 2f;
            float y = (lblHeroTitle.Height - leftSize.Height) / 2f - 2f;

            g.DrawString(left, font, creamBrush, x, y, StringFormat.GenericTypographic);
            g.DrawString(right, font, goldBrush, x + leftSize.Width + 16f, y, StringFormat.GenericTypographic);
        }

        // ═══════════════════════════════════════════════
        //  SIGNATURE PAINT — LUXURY DARK REDESIGN
        // ═══════════════════════════════════════════════
        private void PaintSignature(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            var pic = (PictureBox)sender;

            var r = new Rectangle(6, 6, pic.Width - 12, pic.Height - 12);

            // shadow
            for (int sh = 5; sh >= 1; sh--)
            {
                var sr = new Rectangle(r.X + sh, r.Y + sh, r.Width, r.Height);
                using (var path = RoundRect(sr, 18))
                using (var br = new SolidBrush(Color.FromArgb(sh * 14, 0, 0, 0)))
                    g.FillPath(br, path);
            }

            // card background
            using (var path = RoundRect(r, 18))
            using (var br = new LinearGradientBrush(r, Color.FromArgb(10, 10, 45), Color.FromArgb(5, 5, 28), 140f))
                g.FillPath(br, path);

            // gold border
            using (var path = RoundRect(r, 18))
            using (var pen = new Pen(Color.FromArgb(110, C_GOLD), 1.4f))
                g.DrawPath(pen, path);

            // ── LEFT image panel (40% width)
            int leftW = (int)(r.Width * 0.40f);
            var leftRect = new Rectangle(r.X, r.Y, leftW, r.Height);

            using (var lPath = RoundRectLeft(leftRect, 18))
            using (var br = new LinearGradientBrush(leftRect,
                Color.FromArgb(20, 20, 80), Color.FromArgb(40, 50, 120), 135f))
                g.FillPath(br, lPath);

            // vertical gold divider
            using (var pen = new Pen(Color.FromArgb(70, C_GOLD), 1f))
                g.DrawLine(pen, leftRect.Right, r.Y + 20, leftRect.Right, r.Bottom - 20);

            // glow behind icon
            var gc = new PointF(leftRect.X + leftW / 2f, leftRect.Y + leftRect.Height / 2f);
            using (var glowBr = new PathGradientBrush(new[] {
                new PointF(gc.X - 90, gc.Y), new PointF(gc.X, gc.Y - 90),
                new PointF(gc.X + 90, gc.Y), new PointF(gc.X, gc.Y + 90) }))
            {
                glowBr.CenterColor = Color.FromArgb(55, C_GOLD);
                glowBr.SurroundColors = new[] { Color.Transparent, Color.Transparent, Color.Transparent, Color.Transparent };
                g.FillEllipse(glowBr, gc.X - 90, gc.Y - 90, 180, 180);
            }

            // icon
            TextRenderer.DrawText(g, _signature.Icon, new Font("Segoe UI Emoji", 54f),
                leftRect, Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

            // Available badge
            var av = new Rectangle(leftRect.X + 12, leftRect.Y + 12, 88, 22);
            using (var path = RoundRect(av, 11))
            using (var br = new SolidBrush(Color.FromArgb(200, 14, 80, 52))) g.FillPath(br, path);
            using (var path = RoundRect(av, 11))
            using (var pen = new Pen(Color.FromArgb(60, Color.FromArgb(168, 240, 216)), 1f)) g.DrawPath(pen, path);
            TextRenderer.DrawText(g, "● Available", new Font("Segoe UI", 7.5f, FontStyle.Bold),
                av, Color.FromArgb(168, 240, 216), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

            // Star badge
            var st = new Rectangle(leftRect.Right - 58, leftRect.Y + 12, 50, 22);
            using (var path = RoundRect(st, 11))
            using (var br = new SolidBrush(Color.FromArgb(60, C_GOLD))) g.FillPath(br, path);
            using (var path = RoundRect(st, 11))
            using (var pen = new Pen(Color.FromArgb(120, C_GOLD), 1f)) g.DrawPath(pen, path);
            TextRenderer.DrawText(g, "★ 5.0", new Font("Segoe UI", 7.5f, FontStyle.Bold),
                st, C_GOLD, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

            // ── RIGHT info panel
            int rx = r.X + leftW + 22;
            int infoW = r.Right - rx - 18;
            int iy = r.Y + 18;

            // Type · Zone
            string catLine = $"{_signature.Type.ToUpper()}  ·  {_signature.Zone.ToUpper()}";
            TextRenderer.DrawText(g, catLine, new Font("Segoe UI", 7.5f, FontStyle.Bold),
                new Rectangle(rx, iy, infoW, 18), C_GOLD,
                TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
            iy += 22;

            // Name
            TextRenderer.DrawText(g, _signature.Name, new Font("Georgia", 16f, FontStyle.Bold),
                new Rectangle(rx, iy, infoW, 32), C_CREAM,
                TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
            iy += 36;

            // gold accent line
            using (var pen = new Pen(C_GOLD, 1.5f)) g.DrawLine(pen, rx, iy, rx + 44, iy);
            iy += 10;

            // description
            TextRenderer.DrawText(g, _signature.Desc, new Font("Segoe UI", 8f),
                new Rectangle(rx, iy, infoW, 52), Color.FromArgb(145, C_CREAM),
                TextFormatFlags.Left | TextFormatFlags.WordBreak | TextFormatFlags.EndEllipsis);
            iy += 58;

            // Amenity chips — never overflow right edge
            int px = rx;
            int chipRowMax = rx + infoW;
            foreach (var am in _signature.Amenities)
            {
                var af = new Font("Segoe UI", 7.5f);
                var asz = TextRenderer.MeasureText(g, am, af);
                var pr = new Rectangle(px, iy, asz.Width + 14, 22);
                if (px + pr.Width > chipRowMax) break;
                using (var path = RoundRect(pr, 11))
                {
                    using (var br = new SolidBrush(Color.FromArgb(30, 255, 255, 255))) g.FillPath(br, path);
                    using (var pen = new Pen(Color.FromArgb(45, C_GOLD), 1f)) g.DrawPath(pen, path);
                }
                TextRenderer.DrawText(g, am, af, pr, Color.FromArgb(170, C_CREAM),
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                px += pr.Width + 5;
            }
            iy += 30;

            // Price
            TextRenderer.DrawText(g, _signature.Price, new Font("Georgia", 16f, FontStyle.Bold),
                new Rectangle(rx, iy, 140, 30), C_GOLD_LIGHT,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
            TextRenderer.DrawText(g, "/night", new Font("Segoe UI", 7.5f),
                new Rectangle(rx, iy + 20, 70, 14), Color.FromArgb(90, C_CREAM), TextFormatFlags.Left);

            // Buttons anchored to safe right edge
            int btnRight = r.Right - 18;
            var bookR = new Rectangle(btnRight - 112, iy + 1, 108, 30);
            using (var path = RoundRect(bookR, 15))
            using (var br = new LinearGradientBrush(bookR, C_GOLD, Color.FromArgb(190, 140, 10), 90f))
                g.FillPath(br, path);
            var bookInner = new Rectangle(bookR.X + 2, bookR.Y + 1, bookR.Width - 4, bookR.Height / 2);
            using (var path = RoundRectTop(bookInner, 13))
            using (var br = new SolidBrush(Color.FromArgb(40, 255, 255, 200)))
                g.FillPath(br, path);
            TextRenderer.DrawText(g, "Book Now  →", new Font("Segoe UI", 8.5f, FontStyle.Bold),
                bookR, Color.FromArgb(15, 35, 12),
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

            var detR = new Rectangle(bookR.X - 90, iy + 1, 84, 30);
            using (var path = RoundRect(detR, 15))
            using (var br = new SolidBrush(Color.FromArgb(30, 255, 255, 255))) g.FillPath(br, path);
            using (var path = RoundRect(detR, 15))
            using (var pen = new Pen(Color.FromArgb(70, C_GOLD), 1f)) g.DrawPath(pen, path);
            TextRenderer.DrawText(g, "Details", new Font("Segoe UI", 8.5f),
                detR, Color.FromArgb(175, C_CREAM),
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }

        // ═══════════════════════════════════════════════
        //  DETAIL MODAL
        // ═══════════════════════════════════════════════
        private void ShowDetail(CabinInfo cabin)
        {
            Form parentForm = this.FindForm();
            Control host = parentForm ?? (Control)this;

            int mw = Math.Min(680, host.Width - 60);
            int mh = Math.Min(570, host.Height - 60);

            var modal = new Panel
            {
                Size = new Size(mw, mh),
                BackColor = Color.FromArgb(10, 28, 16),
                Location = new Point((host.Width - mw) / 2, (host.Height - mh) / 2)
            };
            using (var path = RoundRect(new Rectangle(0, 0, mw, mh), 18))
                modal.Region = new Region(path);

            host.Controls.Add(modal);
            modal.BringToFront();

            // gold border
            modal.Paint += (s, pe) =>
            {
                pe.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using (var path = RoundRect(new Rectangle(0, 0, mw - 1, mh - 1), 18))
                using (var pen = new Pen(Color.FromArgb(180, C_GOLD), 2f))
                    pe.Graphics.DrawPath(pen, path);
                using (var path = RoundRect(new Rectangle(3, 3, mw - 7, mh - 7), 16))
                using (var pen = new Pen(Color.FromArgb(40, C_GOLD), 1f))
                    pe.Graphics.DrawPath(pen, path);
            };

            void onResize(object s, EventArgs e) =>
                modal.Location = new Point((host.Width - mw) / 2, (host.Height - mh) / 2);
            host.Resize += onResize;
            modal.Disposed += (s, e) => host.Resize -= onResize;

            // ── hero
            var hero = new Panel { Dock = DockStyle.Top, Height = 160 };
            hero.Paint += (s, pe) =>
            {
                var g = pe.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                var hr = hero.ClientRectangle;
                using (var path = RoundRectTop(new Rectangle(0, 0, hr.Width, hr.Height), 18))
                using (var br = new LinearGradientBrush(hr, cabin.BgTop, cabin.BgBot, 130f))
                    g.FillPath(br, path);
                // gold shimmer top
                using (var shimmer = new LinearGradientBrush(new Rectangle(0, 0, hr.Width, 2),
                    Color.Transparent, Color.FromArgb(140, C_GOLD_LIGHT), 0f))
                using (var pen = new Pen(shimmer, 2f))
                    g.DrawLine(pen, 20, 1, hr.Width - 20, 1);
                TextRenderer.DrawText(g, cabin.Icon, new Font("Segoe UI Emoji", 56f), hr, Color.White,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                // fade bottom
                var fadeR = new Rectangle(0, hr.Height - 60, hr.Width, 60);
                using (var fade = new LinearGradientBrush(fadeR, Color.Transparent, Color.FromArgb(10, 28, 16), 90f))
                    g.FillRectangle(fade, fadeR);
                // status badge
                var bdg = new Rectangle(14, 14, 90, 24);
                using (var path = RoundRect(bdg, 12))
                using (var br = new SolidBrush(Color.FromArgb(200, 14, 80, 52))) g.FillPath(br, path);
                TextRenderer.DrawText(g, "● " + cabin.Status, new Font("Segoe UI", 8f, FontStyle.Bold),
                    bdg, Color.FromArgb(168, 240, 216),
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };
            modal.Controls.Add(hero);

            // close button
            var btnX = new Button
            {
                Text = "✕",
                Size = new Size(34, 34),
                Location = new Point(mw - 46, 12),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(120, 0, 0, 0),
                ForeColor = Color.FromArgb(200, C_GOLD),
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnX.FlatAppearance.BorderSize = 1;
            btnX.FlatAppearance.BorderColor = Color.FromArgb(80, C_GOLD);
            btnX.Click += (s, e) => modal.Dispose();
            modal.Controls.Add(btnX);
            btnX.BringToFront();

            // ── bottom strip
            var strip = new Panel { Dock = DockStyle.Bottom, Height = 66, BackColor = Color.FromArgb(8, 22, 13) };
            strip.Paint += (s, pe) =>
            {
                pe.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using (var pen = new Pen(Color.FromArgb(80, C_GOLD), 1f))
                    pe.Graphics.DrawLine(pen, 20, 0, strip.Width - 20, 0);
                TextRenderer.DrawText(pe.Graphics, cabin.Price, new Font("Georgia", 17f, FontStyle.Bold),
                    new Rectangle(24, 8, 160, 36), C_GOLD_LIGHT,
                    TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
                TextRenderer.DrawText(pe.Graphics, "/night  ·  " + cabin.Cancel, new Font("Segoe UI", 8f),
                    new Rectangle(24, 46, 340, 18), Color.FromArgb(100, C_CREAM), TextFormatFlags.Left);
            };
            modal.Controls.Add(strip);

            var btnBook = new Button
            {
                Text = "Book Now  →",
                Size = new Size(138, 40),
                FlatStyle = FlatStyle.Flat,
                BackColor = C_GOLD,
                ForeColor = Color.FromArgb(12, 35, 14),
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnBook.FlatAppearance.BorderSize = 0;
            btnBook.Click += (s, e) =>
            {
                modal.Dispose();
                Form mainForm = this.FindForm();
                if (mainForm == null) return;
                Panel pnlMain = mainForm.Controls.Find("pnlMain", true).FirstOrDefault() as Panel;
                if (pnlMain == null) return;
                pnlMain.Controls.Clear();
                BookNow bookNow = new BookNow { Dock = DockStyle.Fill };
                pnlMain.Controls.Add(bookNow);
                bookNow.BringToFront();
                bookNow.OpenCabinStay();
            };
            strip.Controls.Add(btnBook);
            btnBook.Location = new Point(mw - 158, 13);
            strip.Resize += (s, e) => btnBook.Location = new Point(strip.Width - 158, 13);

            // ── scrollable body
            var body = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                Padding = new Padding(28, 18, 28, 18),
                BackColor = Color.FromArgb(10, 28, 16)
            };
            modal.Controls.Add(body);

            int by = 0;
            int bodyW = mw - 56;

            // Type · Zone
            body.Controls.Add(new Label
            {
                Text = cabin.Type.ToUpper() + "  ·  " + cabin.Zone.ToUpper(),
                Font = new Font("Segoe UI", 8f, FontStyle.Bold),
                ForeColor = C_GOLD,
                BackColor = Color.Transparent,
                Location = new Point(0, by),
                Size = new Size(bodyW, 18),
                AutoSize = false
            });
            by += 22;

            // Name
            body.Controls.Add(new Label
            {
                Text = cabin.Name,
                Font = new Font("Georgia", 20f, FontStyle.Bold),
                ForeColor = C_CREAM,
                BackColor = Color.Transparent,
                Location = new Point(0, by),
                Size = new Size(bodyW, 38),
                AutoSize = false
            });
            by += 42;

            // gold divider
            body.Controls.Add(new Panel { Height = 2, Width = 50, BackColor = C_GOLD, Location = new Point(0, by) });
            by += 14;

            // Description — auto-height
            var descLabel = new Label
            {
                Text = cabin.Desc,
                Font = new Font("Segoe UI", 9f),
                ForeColor = Color.FromArgb(165, C_CREAM),
                BackColor = Color.Transparent,
                Location = new Point(0, by),
                Size = new Size(bodyW, 0),
                AutoSize = false
            };
            using (var g2 = body.CreateGraphics())
            {
                SizeF sz = g2.MeasureString(cabin.Desc, descLabel.Font, bodyW);
                descLabel.Height = (int)sz.Height + 8;
            }
            body.Controls.Add(descLabel);
            by += descLabel.Height + 8;

            // Info chips (2 columns)
            int cellW = (bodyW - 12) / 2;
            string[] iLabels = { "Capacity", "View", "Check-in / out", "Min. Stay" };
            string[] iVals = { $"Up to {cabin.Cap} guests", $"{cabin.View} view", "2:00 PM / 12:00 PM", cabin.MinStay };
            for (int i = 0; i < 4; i++)
            {
                int col = i % 2, row = i / 2;
                var chip = new Panel
                {
                    Location = new Point(col * (cellW + 12), by + row * 52),
                    Size = new Size(cellW, 46),
                    BackColor = Color.FromArgb(18, 44, 26)
                };
                chip.Paint += (s, pe) =>
                {
                    pe.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    using (var path = RoundRect(new Rectangle(0, 0, chip.Width - 1, chip.Height - 1), 8))
                    using (var pen = new Pen(Color.FromArgb(55, C_GOLD), 1f))
                        pe.Graphics.DrawPath(pen, path);
                };
                chip.Controls.Add(new Label { Text = iLabels[i], Font = new Font("Segoe UI", 7.5f), ForeColor = Color.FromArgb(120, C_GOLD), AutoSize = false, Size = new Size(cellW - 16, 16), BackColor = Color.Transparent, Location = new Point(10, 5) });
                chip.Controls.Add(new Label { Text = iVals[i], Font = new Font("Segoe UI", 9f, FontStyle.Bold), ForeColor = C_CREAM, AutoSize = false, Size = new Size(cellW - 16, 20), BackColor = Color.Transparent, Location = new Point(10, 23) });
                body.Controls.Add(chip);
            }
            by += 110;

            // Amenities header
            body.Controls.Add(new Label
            {
                Text = "AMENITIES",
                Font = new Font("Segoe UI", 8f, FontStyle.Bold),
                ForeColor = Color.FromArgb(140, C_GOLD),
                AutoSize = false,
                Size = new Size(bodyW, 18),
                BackColor = Color.Transparent,
                Location = new Point(0, by)
            });
            by += 24;

            // Amenity chips (3 columns)
            int aChipW = (bodyW - 8) / 3, aChipH = 68;
            for (int ai = 0; ai < cabin.Amenities.Length; ai++)
            {
                string[] pts = cabin.Amenities[ai].Split(new[] { ' ' }, 2);
                string icon = pts[0], iname = pts.Length > 1 ? pts[1] : "";
                int acol = ai % 3, arow = ai / 3;
                var chip = new Panel
                {
                    Location = new Point(acol * (aChipW + 4), by + arow * (aChipH + 6)),
                    Size = new Size(aChipW, aChipH),
                    BackColor = Color.FromArgb(16, 40, 22)
                };
                chip.Paint += (s, pe) =>
                {
                    pe.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    using (var path = RoundRect(new Rectangle(0, 0, chip.Width - 1, chip.Height - 1), 10))
                    {
                        using (var br = new SolidBrush(Color.FromArgb(16, 40, 22))) pe.Graphics.FillPath(br, path);
                        using (var pen = new Pen(Color.FromArgb(55, C_GOLD), 1f)) pe.Graphics.DrawPath(pen, path);
                    }
                };
                chip.Controls.Add(new Label { Text = icon, Font = new Font("Segoe UI Emoji", 18f), AutoSize = false, Size = new Size(aChipW, 34), BackColor = Color.Transparent, Location = new Point(0, 4), TextAlign = ContentAlignment.MiddleCenter });
                chip.Controls.Add(new Label { Text = iname, Font = new Font("Segoe UI", 7.5f), ForeColor = Color.FromArgb(160, C_CREAM), AutoSize = false, Size = new Size(aChipW - 6, 24), BackColor = Color.Transparent, Location = new Point(3, 40), TextAlign = ContentAlignment.MiddleCenter });
                body.Controls.Add(chip);
            }
        }

        // ═══════════════════════════════════════════════
        //  StyleInput
        // ═══════════════════════════════════════════════
        private void StyleInput(Control ctrl)
        {
            ctrl.Font = new Font("Segoe UI", 10);

            if (ctrl is DateTimePicker dtp)
            {
                dtp.Format = DateTimePickerFormat.Custom; dtp.CustomFormat = "dd/MM/yyyy";
                dtp.Size = new Size(165, 34); dtp.Visible = false;
                Panel fi = new Panel { Size = dtp.Size, BackColor = Color.FromArgb(30, 55, 35), Cursor = Cursors.Hand };
                fi.Paint += (s, pe) =>
                {
                    pe.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    Rectangle r = fi.ClientRectangle; r.Inflate(-1, -1); int rad = 8;
                    GraphicsPath p = new GraphicsPath();
                    p.AddArc(r.X, r.Y, rad, rad, 180, 90); p.AddArc(r.Right - rad, r.Y, rad, rad, 270, 90);
                    p.AddArc(r.Right - rad, r.Bottom - rad, rad, rad, 0, 90); p.AddArc(r.X, r.Bottom - rad, rad, rad, 90, 90);
                    p.CloseFigure();
                    using (var f = new SolidBrush(Color.FromArgb(30, 55, 35))) pe.Graphics.FillPath(f, p);
                    using (var b = new Pen(Color.FromArgb(70, 220, 215, 200), 1.2f)) pe.Graphics.DrawPath(b, p);
                    TextRenderer.DrawText(pe.Graphics, dtp.Value.ToString("dd/MM/yyyy"), new Font("Segoe UI", 10),
                        new Rectangle(r.X + 10, r.Y, r.Width - 40, r.Height), Color.FromArgb(220, 215, 205),
                        TextFormatFlags.VerticalCenter | TextFormatFlags.Left);
                    Rectangle ir = new Rectangle(r.Right - 30, r.Y + 1, 29, r.Height - 2);
                    using (var ib = new SolidBrush(Color.FromArgb(18, 40, 22))) pe.Graphics.FillRectangle(ib, ir);
                    int ix2 = ir.Left + (ir.Width / 2) - 7, iy2 = ir.Top + (ir.Height / 2) - 7;
                    Rectangle cb = new Rectangle(ix2, iy2, 14, 14);
                    using (var cp = new Pen(Color.FromArgb(180, 200, 180), 1.2f))
                    {
                        pe.Graphics.DrawRectangle(cp, cb);
                        pe.Graphics.DrawLine(cp, cb.X, cb.Y + 4, cb.Right, cb.Y + 4);
                        pe.Graphics.DrawLine(cp, cb.X + 4, cb.Y - 2, cb.X + 4, cb.Y + 2);
                        pe.Graphics.DrawLine(cp, cb.Right - 4, cb.Y - 2, cb.Right - 4, cb.Y + 2);
                        for (int row = 0; row < 2; row++) for (int col = 0; col < 3; col++)
                                pe.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(160, 180, 160)), cb.X + 2 + (col * 4), cb.Y + 7 + (row * 4), 2, 2);
                    }
                };
                fi.Click += (s, ce) => { dtp.Location = fi.Location; dtp.Visible = true; dtp.Focus(); SendMessage(dtp.Handle, 0x408, IntPtr.Zero, IntPtr.Zero); };
                dtp.Leave += (s, le) => { dtp.Visible = false; fi.Invalidate(); };
                dtp.ValueChanged += (s, ve) => { fi.Invalidate(); };
                dtp.Parent.Controls.Add(fi); fi.Location = dtp.Location; fi.BringToFront(); dtp.Tag = fi;
            }

            if (ctrl is ComboBox cmb)
            {
                cmb.Visible = false; cmb.BackColor = Color.FromArgb(30, 55, 35);
                cmb.ForeColor = Color.FromArgb(220, 215, 205); cmb.FlatStyle = FlatStyle.Flat;
                cmb.DrawMode = DrawMode.OwnerDrawFixed;
                cmb.DrawItem += (s, e) => {
                    if (e.Index < 0) return;
                    bool sel = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
                    e.Graphics.FillRectangle(new SolidBrush(sel ? Color.FromArgb(50, 80, 50) : Color.FromArgb(30, 55, 35)), e.Bounds);
                    TextRenderer.DrawText(e.Graphics, cmb.Items[e.Index].ToString(), new Font("Segoe UI", 10), e.Bounds, Color.FromArgb(220, 215, 205), TextFormatFlags.VerticalCenter | TextFormatFlags.Left);
                };
                Panel fc = new Panel { Size = new Size(130, 34), BackColor = Color.FromArgb(30, 55, 35), Cursor = Cursors.Hand };
                fc.Paint += (s, pe) => {
                    pe.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    Rectangle r = fc.ClientRectangle; r.Inflate(-1, -1); int rad = 8;
                    GraphicsPath p = new GraphicsPath();
                    p.AddArc(r.X, r.Y, rad, rad, 180, 90); p.AddArc(r.Right - rad, r.Y, rad, rad, 270, 90);
                    p.AddArc(r.Right - rad, r.Bottom - rad, rad, rad, 0, 90); p.AddArc(r.X, r.Bottom - rad, rad, rad, 90, 90);
                    p.CloseFigure();
                    using (var f = new SolidBrush(Color.FromArgb(30, 55, 35))) pe.Graphics.FillPath(f, p);
                    using (var b = new Pen(Color.FromArgb(70, 220, 215, 200), 1.2f)) pe.Graphics.DrawPath(b, p);
                    string sv = cmb.SelectedIndex >= 0 ? cmb.Items[cmb.SelectedIndex].ToString() : "";
                    TextRenderer.DrawText(pe.Graphics, sv, new Font("Segoe UI", 10), new Rectangle(r.X + 10, r.Y, r.Width - 35, r.Height), Color.FromArgb(220, 215, 205), TextFormatFlags.VerticalCenter | TextFormatFlags.Left);
                    Rectangle ar = new Rectangle(r.Right - 28, r.Y + 1, 27, r.Height - 2);
                    using (var ab = new SolidBrush(Color.FromArgb(18, 40, 22))) pe.Graphics.FillRectangle(ab, ar);
                    int ax = ar.Left + (ar.Width / 2), ay = ar.Top + (ar.Height / 2) - 2;
                    using (var ab = new SolidBrush(Color.FromArgb(180, 200, 180))) pe.Graphics.FillPolygon(ab, new[] { new Point(ax - 5, ay), new Point(ax + 5, ay), new Point(ax, ay + 6) });
                };
                fc.Click += (s, ce) => { cmb.Location = fc.Location; cmb.Size = fc.Size; cmb.Visible = true; cmb.Focus(); cmb.DroppedDown = true; };
                cmb.Leave += (s, le) => { cmb.Visible = false; fc.Invalidate(); };
                cmb.SelectedIndexChanged += (s, ve) => { cmb.Visible = false; fc.Invalidate(); };
                cmb.Parent.Controls.Add(fc); fc.Location = cmb.Location; fc.BringToFront(); cmb.Tag = fc;
            }
        }

        // ═══════════════════════════════════════════════
        //  HELPERS
        // ═══════════════════════════════════════════════
        private static GraphicsPath RoundRect(Rectangle r, int radius)
        {
            int d = radius * 2; var p = new GraphicsPath();
            p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90); p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure(); return p;
        }
        private static GraphicsPath RoundRectTop(Rectangle r, int radius)
        {
            int d = radius * 2; var p = new GraphicsPath();
            p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddLine(r.Right, r.Bottom, r.X, r.Bottom); p.CloseFigure(); return p;
        }
        private static GraphicsPath RoundRectLeft(Rectangle r, int radius)
        {
            int d = radius * 2; var p = new GraphicsPath();
            p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddLine(r.Right, r.Y, r.Right, r.Bottom);
            p.AddLine(r.Right, r.Bottom, r.X + d / 2, r.Bottom); p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure(); return p;
        }

        private void PaintHeroBackground(object sender, PaintEventArgs pe)
        {
            Panel pnl = (Panel)sender; Graphics g = pe.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            try { g.DrawImage(Properties.Resources.bg, 0, 0, pnl.Width, pnl.Height); } catch { }
            using (var g1 = new SolidBrush(Color.FromArgb(130, 0, 60, 20))) g.FillRectangle(g1, 0, 0, pnl.Width, pnl.Height);
            using (var g2 = new SolidBrush(Color.FromArgb(100, 5, 18, 10))) g.FillRectangle(g2, 0, 0, pnl.Width, pnl.Height);
            using (var bf = new LinearGradientBrush(new Point(0, pnl.Height / 2), new Point(0, pnl.Height),
                Color.FromArgb(0, 5, 18, 10), Color.FromArgb(210, 5, 18, 10)))
                g.FillRectangle(bf, 0, pnl.Height / 2, pnl.Width, pnl.Height / 2);
        }
    }
}
