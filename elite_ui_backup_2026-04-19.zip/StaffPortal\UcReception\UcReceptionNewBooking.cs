using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Project.UcReception
{
    public partial class UcReceptionNewBooking : UserControl
    {
        public UcReceptionNewBooking()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            int todayBookings = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_reservations WHERE DATE(CreatedAt) = CURDATE();");
            int guestProfiles = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_guests;");
            int openCabins = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_cabins WHERE Status = 'Available';");
            int experiences = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_experiences;");

            var recentBookings = StaffPortalDb.GetTable(@"
SELECT r.ReservationID AS `Reservation Ref`,
       CONCAT(g.FirstName, ' ', g.LastName) AS `Guest`,
       r.BookingType AS `Booking Type`,
       r.Status,
       r.TotalAmount AS `Total Amount`,
       DATE_FORMAT(r.CreatedAt, '%Y-%m-%d %H:%i') AS `Created`
FROM tbl_reservations r
LEFT JOIN tbl_guests g ON g.GuestID = r.GuestID
ORDER BY r.CreatedAt DESC
LIMIT 10;");

            var launchCard = StaffPortalUi.ActionCard("Front Desk Booking Actions", panel =>
            {
                var intro = new Label
                {
                    Text = "This page opens the same working Book Now flow used by the main guest side, so reception still writes to the same reservation, guest, payment, and booking-experience tables.",
                    Font = WildNestUI.FontBody(10f),
                    ForeColor = WildNestUI.TextDark,
                    BackColor = Color.Transparent,
                    Location = new Point(18, 60),
                    Size = new Size(panel.Width - 36, 42)
                };

                var btnOpen = WildNestUI.BtnPrimary("Open WildNest Booking Flow", 220, 32);
                btnOpen.Location = new Point(18, 112);
                btnOpen.Click += (s, e) => OpenBookingWorkspace();

                panel.Controls.Add(intro);
                panel.Controls.Add(btnOpen);
            }, 168);

            var page = StaffPortalUi.BuildPage(
                "New Booking",
                "Reception handoff into the existing Book Now logic used across cabins, day visit, experiences, and full stay + experience.",
                new List<Control>
                {
                    StaffPortalUi.StatsRow(
                        (todayBookings.ToString(), "Bookings Created Today", WildNestUI.Green),
                        (guestProfiles.ToString(), "Guest Profiles", WildNestUI.Blue),
                        (openCabins.ToString(), "Available Cabins", WildNestUI.Amber),
                        (experiences.ToString(), "Experience Packages", WildNestUI.Green)),
                    launchCard,
                    StaffPortalUi.GridCard("Recently Created Bookings", recentBookings)
                });

            Controls.Add(page);
        }

        private void OpenBookingWorkspace()
        {
            using var host = new Form
            {
                Text = "WildNest Front Desk Booking",
                StartPosition = FormStartPosition.CenterScreen,
                WindowState = FormWindowState.Maximized,
                BackColor = WildNestUI.Sand
            };

            var booking = new global::Project.BookNow { Dock = DockStyle.Fill };
            host.Controls.Add(booking);
            host.ShowDialog();
        }
    }
}
