﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Project.UcReception
{
    /// <summary>
    /// Reception-side chat panel.
    /// Shows all guest conversations on the left, messages on the right.
    /// Polls DB every 3 seconds for new messages.
    ///
    /// HOW TO ADD TO RECEPTION DASHBOARD:
    ///   In UcReceptionDashboard.cs WireNavButtons(), add:
    ///     btnNavChat.Click += (s, e) => Navigate(btnNavChat, new UcReceptionChat());
    ///
    ///   In Designer, add btnNavChat button to pnlReceptionSidebar.
    ///   Or use the AddChatNavButton() helper below — call it from StyleSidebar().
    /// </summary>
    public class UcReceptionChat : UserControl
    {
        // ── Palette ──────────────────────────────────────────────────
        static readonly Color C_Forest = Color.FromArgb(7, 26, 14);
        static readonly Color C_ForestMid = Color.FromArgb(13, 40, 24);
        static readonly Color C_Gold = Color.FromArgb(212, 160, 23);
        static readonly Color C_Cream = Color.FromArgb(248, 244, 239);
        static readonly Color C_Sand = Color.FromArgb(240, 237, 232);
        static readonly Color C_White = Color.White;
        static readonly Color C_Border = Color.FromArgb(221, 221, 221);
        static readonly Color C_Text = Color.FromArgb(26, 26, 26);
        static readonly Color C_Muted = Color.FromArgb(110, 105, 100);
        static readonly Color C_GuestBubble = Color.FromArgb(232, 245, 238);
        static readonly Color C_ReceptionBubble = Color.FromArgb(7, 26, 14);

        const string CONN = "server=localhost;user=root;database=wildnest_db;" +
                            "password=Natsudragneel_525;Allow User Variables=True;";

        // ── State ────────────────────────────────────────────────────
        string _selectedReservationId = "";
        string _selectedGuestName = "";
        int _lastChatId = 0;
        System.Windows.Forms.Timer _pollTimer = null!;

        // ── UI ───────────────────────────────────────────────────────
        Panel _pnlLeft = null!;  // conversation list
        Panel _pnlRight = null!;  // message area
        FlowLayoutPanel _flowConvos = null!;  // scrollable convo list
        Panel _pnlMsgArea = null!;  // messages container
        FlowLayoutPanel _flowMsgs = null!;  // message bubbles
        TextBox _txtReply = null!;
        Button _btnSend = null!;
        Label _lblGuestName = null!;
        Label _lblBadge = null!;  // unread badge
        Panel _pnlEmpty = null!;  // "select a conversation"

        public UcReceptionChat()
        {
            DoubleBuffered = true;
            BackColor = C_Sand;
            Dock = DockStyle.Fill;
            HandleCreated += (s, e) => BuildUi();
        }

        // ═══════════════════════════════════════════════════════════
        //  BUILD UI
        // ═══════════════════════════════════════════════════════════
        void BuildUi()
        {
            // Header bar
            var header = new Panel { Dock = DockStyle.Top, Height = 56, BackColor = C_White };
            header.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var pen = new Pen(C_Border, 1);
                e.Graphics.DrawLine(pen, 0, header.Height - 1, header.Width, header.Height - 1);
            };
            header.Controls.Add(new Label
            {
                Text = "💬  Guest Chat",
                Font = new Font("Georgia", 14f, FontStyle.Bold),
                ForeColor = C_Forest,
                AutoSize = true,
                Location = new Point(20, 16),
                BackColor = Color.Transparent
            });
            _lblBadge = new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 8f, FontStyle.Bold),
                ForeColor = C_White,
                BackColor = Color.FromArgb(220, 50, 50),
                Size = new Size(22, 22),
                Location = new Point(170, 17),
                TextAlign = ContentAlignment.MiddleCenter,
                Visible = false
            };
            _lblBadge.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var b = new SolidBrush(Color.FromArgb(220, 50, 50));
                e.Graphics.FillEllipse(b, 0, 0, _lblBadge.Width - 1, _lblBadge.Height - 1);
                var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                e.Graphics.DrawString(_lblBadge.Text, _lblBadge.Font, Brushes.White,
                    new RectangleF(0, 0, _lblBadge.Width, _lblBadge.Height), sf);
            };
            header.Controls.Add(_lblBadge);
            Controls.Add(header);

            // Left panel — conversation list
            _pnlLeft = new Panel
            {
                Dock = DockStyle.Left,
                Width = 260,
                BackColor = C_White
            };
            _pnlLeft.Paint += (s, e) =>
            {
                using var pen = new Pen(C_Border, 1);
                e.Graphics.DrawLine(pen, _pnlLeft.Width - 1, 0, _pnlLeft.Width - 1, _pnlLeft.Height);
            };

            var lblConvoHeader = new Label
            {
                Text = "CONVERSATIONS",
                Font = new Font("Segoe UI", 8f, FontStyle.Bold),
                ForeColor = C_Muted,
                AutoSize = false,
                Size = new Size(260, 36),
                Location = new Point(0, 0),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(16, 0, 0, 0),
                BackColor = C_Sand
            };
            _pnlLeft.Controls.Add(lblConvoHeader);

            _flowConvos = new FlowLayoutPanel
            {
                Location = new Point(0, 36),
                Size = new Size(260, _pnlLeft.Height - 36),
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true,
                BackColor = C_White,
                Padding = new Padding(0)
            };
            _pnlLeft.Controls.Add(_flowConvos);
            _pnlLeft.Resize += (s, e) => _flowConvos.Size = new Size(260, _pnlLeft.Height - 36);
            Controls.Add(_pnlLeft);

            // Right panel — messages
            _pnlRight = new Panel { Dock = DockStyle.Fill, BackColor = C_Sand };

            // Empty state
            _pnlEmpty = new Panel { Dock = DockStyle.Fill, BackColor = C_Sand };
            _pnlEmpty.Controls.Add(new Label
            {
                Text = "💬\n\nSelect a conversation\nto view messages",
                Font = new Font("Segoe UI", 11f),
                ForeColor = C_Muted,
                AutoSize = false,
                Size = new Size(300, 180),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent,
                Anchor = AnchorStyles.None
            });
            _pnlEmpty.Controls[0].Location = new Point(
                (_pnlRight.Width - 300) / 2, (_pnlRight.Height - 180) / 2);
            _pnlRight.Controls.Add(_pnlEmpty);

            // Guest name bar
            var pnlGuestBar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 52,
                BackColor = C_White,
                Visible = false
            };
            pnlGuestBar.Paint += (s, e) =>
            {
                using var pen = new Pen(C_Border, 1);
                e.Graphics.DrawLine(pen, 0, pnlGuestBar.Height - 1, pnlGuestBar.Width, pnlGuestBar.Height - 1);
            };
            _lblGuestName = new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = C_Text,
                AutoSize = true,
                Location = new Point(16, 14),
                BackColor = Color.Transparent
            };
            pnlGuestBar.Controls.Add(_lblGuestName);
            pnlGuestBar.Controls.Add(new Label
            {
                Text = "● Online",
                Font = new Font("Segoe UI", 8f),
                ForeColor = Color.FromArgb(34, 139, 34),
                AutoSize = true,
                Location = new Point(16, 34),
                BackColor = Color.Transparent
            });
            _pnlRight.Controls.Add(pnlGuestBar);

            // Reply bar
            var pnlReplyBar = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 64,
                BackColor = C_White,
                Visible = false
            };
            pnlReplyBar.Paint += (s, e) =>
            {
                using var pen = new Pen(C_Border, 1);
                e.Graphics.DrawLine(pen, 0, 0, pnlReplyBar.Width, 0);
            };
            _txtReply = new TextBox
            {
                Location = new Point(14, 14),
                Size = new Size(pnlReplyBar.Width - 110, 36),
                Font = new Font("Segoe UI", 10f),
                BorderStyle = BorderStyle.FixedSingle,
                PlaceholderText = "Type a reply...",
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            _txtReply.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter && !e.Shift) { SendMessage(); e.SuppressKeyPress = true; }
            };
            _btnSend = new Button
            {
                Text = "Send ➤",
                Location = new Point(pnlReplyBar.Width - 90, 14),
                Size = new Size(76, 36),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                BackColor = C_Forest,
                ForeColor = C_Gold,
                Cursor = Cursors.Hand,
                Anchor = AnchorStyles.Right | AnchorStyles.Top
            };
            _btnSend.FlatAppearance.BorderSize = 0;
            _btnSend.Click += (s, e) => SendMessage();
            pnlReplyBar.Controls.AddRange(new Control[] { _txtReply, _btnSend });
            pnlReplyBar.Resize += (s, e) =>
            {
                _txtReply.Width = pnlReplyBar.Width - 110;
                _btnSend.Left = pnlReplyBar.Width - 90;
            };
            _pnlRight.Controls.Add(pnlReplyBar);

            // Message scroll area
            _pnlMsgArea = new Panel { Dock = DockStyle.Fill, BackColor = C_Sand, AutoScroll = true };
            _flowMsgs = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true,
                Padding = new Padding(12, 10, 12, 10),
                BackColor = C_Sand
            };
            _pnlMsgArea.Controls.Add(_flowMsgs);
            _pnlRight.Controls.Add(_pnlMsgArea);

            Controls.Add(_pnlRight);

            // Store refs for show/hide
            Tag = new Control[] { pnlGuestBar, pnlReplyBar };

            // Load conversations
            LoadConversations();

            // Poll timer — every 3 seconds
            _pollTimer = new System.Windows.Forms.Timer { Interval = 3000 };
            _pollTimer.Tick += (s, e) => PollNewMessages();
            _pollTimer.Start();
        }

        // ═══════════════════════════════════════════════════════════
        //  LOAD CONVERSATIONS (left panel)
        // ═══════════════════════════════════════════════════════════
        void LoadConversations()
        {
            if (IsDisposed) return;
            try
            {
                var convos = new List<(string ReservationID, string GuestName, string LastMsg, DateTime LastAt, int Unread)>();
                using var conn = new MySqlConnection(CONN);
                conn.Open();
                string sql = @"
                    SELECT c.ReservationID,
                           c.GuestName,
                           (SELECT Message FROM tbl_Chat
                            WHERE ReservationID = c.ReservationID
                            ORDER BY SentAt DESC LIMIT 1) AS LastMsg,
                           MAX(c.SentAt) AS LastAt,
                           SUM(CASE WHEN c.SenderRole='guest' AND c.IsRead=0 THEN 1 ELSE 0 END) AS Unread
                    FROM tbl_Chat c
                    GROUP BY c.ReservationID, c.GuestName
                    ORDER BY MAX(c.SentAt) DESC;";
                using var cmd = new MySqlCommand(sql, conn);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                    convos.Add((
                        reader["ReservationID"].ToString()!,
                        reader["GuestName"].ToString()!,
                        reader["LastMsg"]?.ToString() ?? "",
                        Convert.ToDateTime(reader["LastAt"]),
                        Convert.ToInt32(reader["Unread"])
                    ));

                // Update unread badge
                int totalUnread = 0;
                convos.ForEach(c => totalUnread += c.Unread);
                _lblBadge.Text = totalUnread > 0 ? totalUnread.ToString() : "";
                _lblBadge.Visible = totalUnread > 0;

                // Rebuild convo list
                if (InvokeRequired) { Invoke(() => RebuildConvoList(convos)); return; }
                RebuildConvoList(convos);
            }
            catch { /* db not ready */ }
        }

        void RebuildConvoList(List<(string ReservationID, string GuestName, string LastMsg, DateTime LastAt, int Unread)> convos)
        {
            _flowConvos.SuspendLayout();
            _flowConvos.Controls.Clear();

            if (convos.Count == 0)
            {
                _flowConvos.Controls.Add(new Label
                {
                    Text = "No guest messages yet.",
                    Font = new Font("Segoe UI", 9f),
                    ForeColor = C_Muted,
                    AutoSize = false,
                    Size = new Size(240, 60),
                    TextAlign = ContentAlignment.MiddleCenter,
                    Padding = new Padding(10)
                });
            }

            foreach (var c in convos)
            {
                var card = new Panel
                {
                    Size = new Size(258, 68),
                    BackColor = c.ReservationID == _selectedReservationId
                                    ? Color.FromArgb(230, 245, 237) : C_White,
                    Cursor = Cursors.Hand,
                    Tag = c.ReservationID
                };
                card.Paint += (s, e) =>
                {
                    e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    var pnl = (Panel)s;
                    bool selected = pnl.Tag?.ToString() == _selectedReservationId;
                    if (selected)
                    {
                        using var b = new SolidBrush(Color.FromArgb(230, 245, 237));
                        e.Graphics.FillRectangle(b, 0, 0, pnl.Width, pnl.Height);
                        using var pen2 = new Pen(C_Gold, 2);
                        e.Graphics.DrawLine(pen2, 0, 0, 0, pnl.Height);
                    }
                    using var pen = new Pen(C_Border, 1);
                    e.Graphics.DrawLine(pen, 0, pnl.Height - 1, pnl.Width, pnl.Height - 1);
                };

                // Avatar circle
                var avatar = new Panel { Location = new Point(12, 14), Size = new Size(38, 38), BackColor = Color.Transparent };
                avatar.Paint += (s, e) =>
                {
                    e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    using var b = new SolidBrush(C_ForestMid);
                    e.Graphics.FillEllipse(b, 0, 0, 37, 37);
                    string initials = c.GuestName.Length >= 2 ? c.GuestName[..2].ToUpper() : c.GuestName.ToUpper();
                    var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                    e.Graphics.DrawString(initials, new Font("Segoe UI", 10f, FontStyle.Bold),
                        new SolidBrush(C_Gold), new RectangleF(0, 0, 38, 38), sf);
                };

                // Name + last message
                var lblName = new Label
                {
                    Text = c.GuestName,
                    Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                    ForeColor = C_Text,
                    Location = new Point(58, 10),
                    Size = new Size(170, 20),
                    BackColor = Color.Transparent
                };
                var lblId = new Label
                {
                    Text = c.ReservationID,
                    Font = new Font("Segoe UI", 7.5f),
                    ForeColor = C_Muted,
                    Location = new Point(58, 28),
                    Size = new Size(170, 16),
                    BackColor = Color.Transparent
                };
                string preview = c.LastMsg.Length > 32 ? c.LastMsg[..32] + "…" : c.LastMsg;
                var lblPreview = new Label
                {
                    Text = preview,
                    Font = new Font("Segoe UI", 8f),
                    ForeColor = C_Muted,
                    Location = new Point(58, 44),
                    Size = new Size(170, 16),
                    BackColor = Color.Transparent
                };

                // Unread dot
                if (c.Unread > 0)
                {
                    var dot = new Panel { Location = new Point(232, 24), Size = new Size(16, 16), BackColor = Color.Transparent };
                    dot.Paint += (s, e) =>
                    {
                        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                        using var b = new SolidBrush(Color.FromArgb(220, 50, 50));
                        e.Graphics.FillEllipse(b, 0, 0, 15, 15);
                    };
                    card.Controls.Add(dot);
                }

                card.Controls.AddRange(new Control[] { avatar, lblName, lblId, lblPreview });

                string rid = c.ReservationID, gname = c.GuestName;
                card.Click += (s, e) => SelectConversation(rid, gname);
                lblName.Click += (s, e) => SelectConversation(rid, gname);
                lblId.Click += (s, e) => SelectConversation(rid, gname);
                lblPreview.Click += (s, e) => SelectConversation(rid, gname);
                avatar.Click += (s, e) => SelectConversation(rid, gname);

                _flowConvos.Controls.Add(card);
            }
            _flowConvos.ResumeLayout();
        }

        // ═══════════════════════════════════════════════════════════
        //  SELECT CONVERSATION
        // ═══════════════════════════════════════════════════════════
        void SelectConversation(string reservationId, string guestName)
        {
            _selectedReservationId = reservationId;
            _selectedGuestName = guestName;
            _lastChatId = 0;

            _pnlEmpty.Visible = false;
            _lblGuestName.Text = $"{guestName}  ·  {reservationId}";

            // Show guest bar and reply bar
            if (Tag is Control[] bars)
                foreach (var b in bars) b.Visible = true;

            // Mark messages as read
            Task.Run(() =>
            {
                try
                {
                    using var conn = new MySqlConnection(CONN);
                    conn.Open();
                    var cmd = new MySqlCommand(
                        "UPDATE tbl_Chat SET IsRead=1 WHERE ReservationID=@rid AND SenderRole='guest';", conn);
                    cmd.Parameters.AddWithValue("@rid", reservationId);
                    cmd.ExecuteNonQuery();
                }
                catch { }
            });

            LoadMessages();
            LoadConversations(); // refresh unread counts
        }

        // ═══════════════════════════════════════════════════════════
        //  LOAD MESSAGES
        // ═══════════════════════════════════════════════════════════
        void LoadMessages()
        {
            if (string.IsNullOrEmpty(_selectedReservationId)) return;
            try
            {
                var msgs = new List<(int ChatID, string Role, string Message, DateTime SentAt)>();
                using var conn = new MySqlConnection(CONN);
                conn.Open();
                var cmd = new MySqlCommand(
                    "SELECT ChatID, SenderRole, Message, SentAt FROM tbl_Chat " +
                    "WHERE ReservationID=@rid ORDER BY SentAt ASC;", conn);
                cmd.Parameters.AddWithValue("@rid", _selectedReservationId);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    msgs.Add((
                        Convert.ToInt32(reader["ChatID"]),
                        reader["SenderRole"].ToString()!,
                        reader["Message"].ToString()!,
                        Convert.ToDateTime(reader["SentAt"])
                    ));
                    _lastChatId = Math.Max(_lastChatId, Convert.ToInt32(reader["ChatID"]));
                }

                if (InvokeRequired) { Invoke(() => RebuildMessages(msgs)); return; }
                RebuildMessages(msgs);
            }
            catch { }
        }

        void RebuildMessages(List<(int ChatID, string Role, string Message, DateTime SentAt)> msgs)
        {
            _flowMsgs.SuspendLayout();
            _flowMsgs.Controls.Clear();

            foreach (var m in msgs)
                _flowMsgs.Controls.Add(BuildBubble(m.Role, m.Message, m.SentAt));

            _flowMsgs.ResumeLayout();
            ScrollToBottom();
        }

        // ═══════════════════════════════════════════════════════════
        //  POLL NEW MESSAGES
        // ═══════════════════════════════════════════════════════════
        void PollNewMessages()
        {
            // Always refresh conversation list for unread counts
            Task.Run(() => LoadConversations());

            if (string.IsNullOrEmpty(_selectedReservationId)) return;
            try
            {
                var newMsgs = new List<(int ChatID, string Role, string Message, DateTime SentAt)>();
                using var conn = new MySqlConnection(CONN);
                conn.Open();
                var cmd = new MySqlCommand(
                    "SELECT ChatID, SenderRole, Message, SentAt FROM tbl_Chat " +
                    "WHERE ReservationID=@rid AND ChatID > @lastId ORDER BY SentAt ASC;", conn);
                cmd.Parameters.AddWithValue("@rid", _selectedReservationId);
                cmd.Parameters.AddWithValue("@lastId", _lastChatId);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    newMsgs.Add((
                        Convert.ToInt32(reader["ChatID"]),
                        reader["SenderRole"].ToString()!,
                        reader["Message"].ToString()!,
                        Convert.ToDateTime(reader["SentAt"])
                    ));
                    _lastChatId = Math.Max(_lastChatId, Convert.ToInt32(reader["ChatID"]));
                }

                if (newMsgs.Count == 0) return;

                // Mark as read since reception is viewing
                var markCmd = new MySqlCommand(
                    "UPDATE tbl_Chat SET IsRead=1 WHERE ReservationID=@rid AND SenderRole='guest';", conn);
                markCmd.Parameters.AddWithValue("@rid", _selectedReservationId);
                markCmd.ExecuteNonQuery();

                if (InvokeRequired)
                    Invoke(() => { foreach (var m in newMsgs) AppendBubble(m.Role, m.Message, m.SentAt); });
                else
                    foreach (var m in newMsgs) AppendBubble(m.Role, m.Message, m.SentAt);
            }
            catch { }
        }

        // ═══════════════════════════════════════════════════════════
        //  SEND MESSAGE
        // ═══════════════════════════════════════════════════════════
        void SendMessage()
        {
            string msg = _txtReply.Text.Trim();
            if (string.IsNullOrEmpty(msg) || string.IsNullOrEmpty(_selectedReservationId)) return;
            _txtReply.Clear();

            Task.Run(() =>
            {
                try
                {
                    using var conn = new MySqlConnection(CONN);
                    conn.Open();
                    var cmd = new MySqlCommand(
                        "INSERT INTO tbl_Chat (ReservationID, GuestName, SenderRole, Message, SentAt, IsRead) " +
                        "VALUES (@rid, @gname, 'reception', @msg, NOW(), 1);", conn);
                    cmd.Parameters.AddWithValue("@rid", _selectedReservationId);
                    cmd.Parameters.AddWithValue("@gname", _selectedGuestName);
                    cmd.Parameters.AddWithValue("@msg", msg);
                    cmd.ExecuteNonQuery();

                    if (InvokeRequired)
                        Invoke(() => AppendBubble("reception", msg, DateTime.Now));
                    else
                        AppendBubble("reception", msg, DateTime.Now);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Send failed: " + ex.Message);
                }
            });
        }

        // ═══════════════════════════════════════════════════════════
        //  BUBBLE BUILDER
        // ═══════════════════════════════════════════════════════════
        Panel BuildBubble(string role, string message, DateTime sentAt)
        {
            bool isReception = role == "reception";
            int maxW = Math.Max(_flowMsgs.Width - 80, 200);

            using var tmpFont = new Font("Segoe UI", 10f);
            SizeF textSize = TextRenderer.MeasureText(message, tmpFont,
                new Size(maxW, int.MaxValue), TextFormatFlags.WordBreak);

            int bubW = Math.Min((int)textSize.Width + 28, maxW);
            int bubH = (int)textSize.Height + 20;

            var wrap = new Panel
            {
                Size = new Size(_flowMsgs.Width - 30, bubH + 24),
                BackColor = Color.Transparent,
                Margin = new Padding(0, 2, 0, 2)
            };

            var bubble = new Panel
            {
                Size = new Size(bubW, bubH),
                BackColor = isReception ? C_ReceptionBubble : C_GuestBubble,
                Location = isReception
                    ? new Point(wrap.Width - bubW - 10, 4)
                    : new Point(10, 4)
            };
            bubble.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var path = RoundedRect(new Rectangle(0, 0, bubble.Width - 1, bubble.Height - 1), 12);
                using var b = new SolidBrush(bubble.BackColor);
                e.Graphics.FillPath(b, path);
                using var textBrush = new SolidBrush(isReception ? C_Cream : C_Text);
                e.Graphics.DrawString(message, new Font("Segoe UI", 10f), textBrush,
                    new RectangleF(12, 8, bubW - 24, bubH - 12));
            };

            var lblTime = new Label
            {
                Text = sentAt.ToString("hh:mm tt"),
                Font = new Font("Segoe UI", 7f),
                ForeColor = C_Muted,
                AutoSize = true,
                BackColor = Color.Transparent,
                Location = isReception
                    ? new Point(wrap.Width - bubW - 10, bubH + 6)
                    : new Point(10, bubH + 6)
            };

            wrap.Controls.AddRange(new Control[] { bubble, lblTime });
            return wrap;
        }

        void AppendBubble(string role, string message, DateTime sentAt)
        {
            _flowMsgs.Controls.Add(BuildBubble(role, message, sentAt));
            ScrollToBottom();
        }

        void ScrollToBottom()
        {
            _flowMsgs.ScrollControlIntoView(
                _flowMsgs.Controls.Count > 0
                    ? _flowMsgs.Controls[_flowMsgs.Controls.Count - 1]
                    : _flowMsgs);
        }

        static GraphicsPath RoundedRect(Rectangle r, int radius)
        {
            var path = new GraphicsPath();
            path.AddArc(r.X, r.Y, radius * 2, radius * 2, 180, 90);
            path.AddArc(r.Right - radius * 2, r.Y, radius * 2, radius * 2, 270, 90);
            path.AddArc(r.Right - radius * 2, r.Bottom - radius * 2, radius * 2, radius * 2, 0, 90);
            path.AddArc(r.X, r.Bottom - radius * 2, radius * 2, radius * 2, 90, 90);
            path.CloseFigure();
            return path;
        }

        protected override void Dispose(bool disposing)
        {
            _pollTimer?.Stop();
            _pollTimer?.Dispose();
            base.Dispose(disposing);
        }
    }
}