using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcZooKeeper
{
    public class UcZookeeperDefaultContent : UserControl
    {
        public UcZookeeperDefaultContent()
        {
            Dock = DockStyle.Fill;
            BackColor = WildNestUI.Sand;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            int zooKeepers = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_users WHERE Role LIKE '%Zoo%';");
            int experiences = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_experiences;");
            int todayDemand = StaffPortalDb.Count(@"
SELECT COALESCE(SUM(be.Quantity),0)
FROM tbl_bookingexperiences be
JOIN tbl_reservations r ON r.ReservationID = be.ReservationID
WHERE COALESCE(r.VisitDate, r.CheckInDate) = CURDATE();");
            int flaggedTables = (StaffPortalDb.TableExists("tbl_animals") ? 1 : 0)
                              + (StaffPortalDb.TableExists("tbl_feeding") ? 1 : 0)
                              + (StaffPortalDb.TableExists("tbl_healthrecords") ? 1 : 0);

            var demand = StaffPortalDb.GetTable(@"
SELECT e.ExperienceName AS `Experience`,
       e.DurationMinutes AS `Duration (mins)`,
       COALESCE(SUM(be.Quantity),0) AS `Booked Slots`,
       COALESCE(SUM(be.TotalCost),0) AS `Revenue`
FROM tbl_experiences e
LEFT JOIN tbl_bookingexperiences be ON be.ExperienceID = e.ExperienceID
GROUP BY e.ExperienceName, e.DurationMinutes
ORDER BY `Booked Slots` DESC, e.ExperienceName;");

            Controls.Add(StaffPortalUi.BuildPage(
                "Wildlife Operations",
                "ZooKeeper dashboard using the current live schema. Animal-specific registry tables are not present yet.",
                new List<Control>
                {
                    StaffPortalUi.MessageCard(
                        "Schema Gap for Animal Operations",
                        "Your current SQL does not include animal registry, feeding, health record, or enclosure tables yet. This role is therefore using wildlife experience demand and staffing context as the closest operational data until those tables are added.",
                        alert: true),
                    StaffPortalUi.StatsRow(
                        (zooKeepers.ToString(), "ZooKeeper Accounts", WildNestUI.Blue),
                        (experiences.ToString(), "Wildlife Experiences", WildNestUI.Green),
                        (todayDemand.ToString(), "Guest Slots Today", WildNestUI.Amber),
                        (flaggedTables.ToString(), "Animal Tables Present", WildNestUI.Red)),
                    StaffPortalUi.GridCard("Wildlife Demand Snapshot", demand)
                }));
        }
    }
}
