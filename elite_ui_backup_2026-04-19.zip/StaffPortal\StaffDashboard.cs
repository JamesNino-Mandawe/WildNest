﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Project.UcAdministrator;
using Project.UcReception;
using Project.UcZooKeeper;
using Project.UcTourGuide;

namespace Project
{
    public partial class StaffDashboard : Form
    {
        private string _role;
        private string _displayName;

        private static readonly Color Gold = Color.FromArgb(212, 160, 23);
        private static readonly Color DarkGreen = Color.FromArgb(7, 26, 14);
        private static readonly Color DimWhite = Color.FromArgb(60, 248, 244, 239);

        public StaffDashboard(string role, string displayName)
        {
            InitializeComponent();
            _role = role;
            _displayName = displayName;
            this.Load += StaffDashboard_Load;
        }

        private void StaffDashboard_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;

            pnlTopBar.BackColor = Color.FromArgb(7, 26, 14);
            pnlSidebar.BackColor = Color.FromArgb(7, 26, 14);
            pnlContent.BackColor = Color.FromArgb(240, 237, 232);

            pnlTopBar.Paint += (s, e) =>
            {
                using var pen = new Pen(Color.FromArgb(38, 212, 160, 23), 2);
                e.Graphics.DrawLine(pen, 0, pnlTopBar.Height - 1, pnlTopBar.Width, pnlTopBar.Height - 1);
            };

            pnlSidebar.Visible = false;
            pnlSidebar.Width = 0;
            pnlContent.Dock = DockStyle.Fill;

            LockRoleTabs();
            LoadRoleDashboard();
        }

        private void LockRoleTabs()
        {
            btnRoleAdmin.Tag = "Administrator";
            btnRoleFD.Tag = "Reception";
            btnRoleZK.Tag = "ZooKeeper";
            btnRoleTG.Tag = "TourGuide";

            foreach (Control c in pnlTopBar.Controls)
            {
                if (!(c is Button btn)) continue;
                btn.FlatStyle = FlatStyle.Flat;
                btn.FlatAppearance.BorderSize = 0;

                if (btn.Tag?.ToString() == _role)
                {
                    btn.ForeColor = Gold;
                    btn.Font = new Font("Georgia", 10.2f, FontStyle.Bold);
                    btn.Cursor = Cursors.Default;
                    btn.Enabled = true;
                }
                else
                {
                    btn.ForeColor = DimWhite;
                    btn.Enabled = false;
                    btn.Cursor = Cursors.No;
                }
            }
        }

        private void LoadRoleDashboard()
        {
            pnlContent.Controls.Clear();
            pnlSidebar.Controls.Clear();

            UserControl uc = null;

            switch (_role)
            {
                case "Administrator":
                    var a = new UcAdminDashboard();
                    a.SetParentDashboard(this);
                    a.SetDisplayName(_displayName);
                    uc = a;
                    break;

                case "Reception":
                    var r = new UcReceptionDashboard();
                    r.SetParentDashboard(this);
                    r.SetDisplayName(_displayName);
                    uc = r;
                    break;

                case "TourGuide":
                    var t = new UcTourGuideDashboard();
                    t.SetParentDashboard(this);
                    t.SetDisplayName(_displayName);
                    uc = t;
                    break;

                case "ZooKeeper":
                    var z = new UcZookeeperDashboard();
                    z.SetParentDashboard(this);
                    z.SetDisplayName(_displayName);
                    uc = z;
                    break;
            }

            if (uc != null)
            {
                uc.Dock = DockStyle.Fill;
                pnlContent.Controls.Add(uc);
            }
        }

        public void SignOut()
        {
            foreach (Form f in Application.OpenForms)
            {
                if (f is StaffLogin login)
                {
                    login.Show();
                    break;
                }
            }
            this.Close();
        }
    }
}