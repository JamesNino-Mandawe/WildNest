using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcTourGuide
{
    public partial class UcTourGuideComplete : UserControl
    {
        public UcTourGuideComplete()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            var dueForCompletion = StaffPortalDb.GetTable(@"
SELECT r.ReservationID AS `Reservation Ref`,
       CONCAT(g.FirstName, ' ', g.LastName) AS `Guest`,
       GROUP_CONCAT(e.ExperienceName SEPARATOR ', ') AS `Experience Lineup`,
       SUM(be.Quantity) AS `Attendees`,
       COALESCE(DATE_FORMAT(r.VisitDate, '%Y-%m-%d'), DATE_FORMAT(r.CheckInDate, '%Y-%m-%d')) AS `Scheduled Date`,
       r.Status
FROM tbl_bookingexperiences be
JOIN tbl_reservations r ON r.ReservationID = be.ReservationID
JOIN tbl_guests g ON g.GuestID = r.GuestID
JOIN tbl_experiences e ON e.ExperienceID = be.ExperienceID
WHERE COALESCE(r.VisitDate, r.CheckInDate) <= CURDATE()
GROUP BY r.ReservationID, g.FirstName, g.LastName, r.VisitDate, r.CheckInDate, r.Status
ORDER BY `Scheduled Date` DESC;");

            Controls.Add(StaffPortalUi.BuildPage(
                "Mark Complete",
                "Completion review view. The current schema does not persist tour-completion state yet.",
                new List<Control>
                {
                    StaffPortalUi.MessageCard(
                        "Completion State Not Yet Stored in SQL",
                        "There is no dedicated completion or guide-assignment table in the current database, so this page lists experience bookings that a future completion workflow should track. Adding a tour schedule/completion table later would make this page fully transactional.",
                        alert: true),
                    StaffPortalUi.GridCard("Experience Bookings Requiring Completion Tracking", dueForCompletion)
                }));
        }
    }
}
