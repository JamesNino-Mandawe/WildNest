using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcAdministrator
{
    public partial class UcAdminEncounters : UserControl
    {
        public UcAdminEncounters()
        {
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            int experienceCount = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_experiences;");
            int bookedSlots = StaffPortalDb.Count("SELECT COALESCE(SUM(Quantity),0) FROM tbl_bookingexperiences;");
            decimal revenue = StaffPortalDb.Sum("SELECT COALESCE(SUM(TotalCost),0) FROM tbl_bookingexperiences;");
            int averageDuration = StaffPortalDb.Count("SELECT COALESCE(AVG(DurationMinutes),0) FROM tbl_experiences;");

            var encounters = StaffPortalDb.GetTable(@"
SELECT e.ExperienceID AS `Experience ID`,
       e.ExperienceName AS `Experience`,
       e.PricePerPerson AS `Price Per Person`,
       e.DurationMinutes AS `Duration (mins)`,
       COALESCE(SUM(be.Quantity), 0) AS `Booked Slots`,
       COALESCE(SUM(be.TotalCost), 0) AS `Revenue`
FROM tbl_experiences e
LEFT JOIN tbl_bookingexperiences be ON be.ExperienceID = e.ExperienceID
GROUP BY e.ExperienceID, e.ExperienceName, e.PricePerPerson, e.DurationMinutes
ORDER BY e.ExperienceName;");

            var page = StaffPortalUi.BuildPage(
                "Encounter Packages",
                "Experience catalogue and booking performance from tbl_experiences and tbl_bookingexperiences.",
                new List<Control>
                {
                    StaffPortalUi.StatsRow(
                        (experienceCount.ToString(), "Experience Packages", WildNestUI.Blue),
                        (bookedSlots.ToString(), "Booked Slots", WildNestUI.Green),
                        (StaffPortalUi.Peso(revenue), "Encounter Revenue", WildNestUI.Amber),
                        ($"{averageDuration} min", "Average Duration", WildNestUI.Green)),
                    StaffPortalUi.GridCard("Experience Performance", encounters)
                });

            Controls.Add(page);
        }
    }
}
