using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcZooKeeper
{
    public partial class UcZookeeperHealth : UserControl
    {
        public UcZookeeperHealth()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            Controls.Add(StaffPortalUi.BuildPage(
                "Health Records",
                "Health records depend on a dedicated animal/medical schema that is not in the current database yet.",
                new List<Control>
                {
                    StaffPortalUi.MessageCard(
                        "Health Records Table Required",
                        "Your current SQL dump does not include tables for animals, diagnoses, treatments, or health alerts. This user control is ready as the role endpoint, but it needs those tables before true medical record workflows can be wired.",
                        alert: true)
                }));
        }
    }
}
