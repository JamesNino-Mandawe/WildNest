using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcAdministrator
{
    public partial class UcAdminGuests : UserControl
    {
        public UcAdminGuests()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            int totalGuests = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_guests;");
            int newThisMonth = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_guests WHERE YEAR(CreatedAt)=YEAR(CURDATE()) AND MONTH(CreatedAt)=MONTH(CURDATE());");
            int foreignGuests = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_guests WHERE Nationality IS NOT NULL AND Nationality <> '' AND Nationality <> 'Filipino';");
            int repeatGuests = StaffPortalDb.Count(@"
SELECT COUNT(*) FROM (
    SELECT GuestID
    FROM tbl_reservations
    GROUP BY GuestID
    HAVING COUNT(*) > 1
) x;");

            var guests = StaffPortalDb.GetTable(@"
SELECT g.GuestID AS `Guest ID`,
       CONCAT(g.FirstName, ' ', g.LastName) AS `Guest Name`,
       g.Email,
       g.Phone AS `Contact No.`,
       g.Nationality,
       g.ValidIDType AS `Valid ID`,
       COUNT(r.ReservationID) AS `Reservation Count`,
       DATE_FORMAT(g.CreatedAt, '%Y-%m-%d') AS `Created`
FROM tbl_guests g
LEFT JOIN tbl_reservations r ON r.GuestID = g.GuestID
GROUP BY g.GuestID, g.FirstName, g.LastName, g.Email, g.Phone, g.Nationality, g.ValidIDType, g.CreatedAt
ORDER BY g.CreatedAt DESC;");

            var page = StaffPortalUi.BuildPage(
                "Guest Profiles",
                "Live guest directory from tbl_guests with booking activity summary.",
                new List<Control>
                {
                    StaffPortalUi.StatsRow(
                        (totalGuests.ToString(), "Total Guests", WildNestUI.Blue),
                        (newThisMonth.ToString(), "New This Month", WildNestUI.Green),
                        (foreignGuests.ToString(), "Foreign Nationals", WildNestUI.Amber),
                        (repeatGuests.ToString(), "Repeat Guests", WildNestUI.Green)),
                    StaffPortalUi.GridCard("Guest Directory", guests)
                });

            Controls.Add(page);
        }
    }
}
