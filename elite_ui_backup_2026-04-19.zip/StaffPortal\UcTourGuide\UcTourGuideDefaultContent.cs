using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcTourGuide
{
    public class UcTourGuideDefaultContent : UserControl
    {
        private readonly string _displayName;

        public UcTourGuideDefaultContent(string displayName = "")
        {
            _displayName = displayName;
            Dock = DockStyle.Fill;
            BackColor = WildNestUI.Sand;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            int todayTours = StaffPortalDb.Count(@"
SELECT COUNT(DISTINCT be.ReservationID)
FROM tbl_bookingexperiences be
JOIN tbl_reservations r ON r.ReservationID = be.ReservationID
WHERE COALESCE(r.VisitDate, r.CheckInDate) = CURDATE();");
            int todayGuests = StaffPortalDb.Count(@"
SELECT COALESCE(SUM(be.Quantity),0)
FROM tbl_bookingexperiences be
JOIN tbl_reservations r ON r.ReservationID = be.ReservationID
WHERE COALESCE(r.VisitDate, r.CheckInDate) = CURDATE();");
            int allExperienceBookings = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_bookingexperiences;");
            decimal revenue = StaffPortalDb.Sum("SELECT COALESCE(SUM(TotalCost),0) FROM tbl_bookingexperiences;");

            var manifest = StaffPortalDb.GetTable(@"
SELECT r.ReservationID AS `Reservation Ref`,
       CONCAT(g.FirstName, ' ', g.LastName) AS `Guest`,
       e.ExperienceName AS `Experience`,
       be.Quantity AS `Attendees`,
       COALESCE(DATE_FORMAT(r.VisitDate, '%Y-%m-%d'), DATE_FORMAT(r.CheckInDate, '%Y-%m-%d')) AS `Tour Date`,
       r.Status
FROM tbl_bookingexperiences be
JOIN tbl_reservations r ON r.ReservationID = be.ReservationID
JOIN tbl_guests g ON g.GuestID = r.GuestID
JOIN tbl_experiences e ON e.ExperienceID = be.ExperienceID
ORDER BY `Tour Date` DESC, `Guest`;");

            string displayName = string.IsNullOrWhiteSpace(_displayName) ? "Tour Guide" : _displayName;
            var sections = new List<Control>
            {
                StaffPortalUi.MessageCard(
                    "Guide Assignment Note",
                    "The current SQL schema does not yet store guide-assignment or completion tables, so this dashboard shows the live experience manifest derived from bookings and reservations.",
                    alert: true),
                StaffPortalUi.StatsRow(
                    (todayTours.ToString(), "Experience Bookings Today", WildNestUI.Green),
                    (todayGuests.ToString(), "Guests to Handle Today", WildNestUI.Blue),
                    (allExperienceBookings.ToString(), "All Experience Bookings", WildNestUI.Amber),
                    (StaffPortalUi.Peso(revenue), "Experience Revenue", WildNestUI.Green)),
                StaffPortalUi.GridCard("Live Tour Manifest", manifest)
            };

            Controls.Add(StaffPortalUi.BuildPage(
                "My Schedule",
                $"{displayName} — operational tour view derived from the current reservation schema.",
                sections));
        }
    }
}
