using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Project
{
    /// <summary>
    /// Shared WildNest UI helpers — colours, rounded rects, card/table/badge builders.
    /// All dashboard roles reuse these to stay visually consistent.
    /// </summary>
    public static class WildNestUI
    {
        // ── Brand palette (matches prototype) ────────────────────────────────
        public static readonly Color Forest   = Color.FromArgb(7,  26,  14);   // sidebar bg
        public static readonly Color ForestM  = Color.FromArgb(13, 40,  24);   // hover
        public static readonly Color Gold     = Color.FromArgb(212,160, 23);   // accent
        public static readonly Color Cream    = Color.FromArgb(248,244,239);   // text light
        public static readonly Color DimCream = Color.FromArgb(128,248,244,239);
        public static readonly Color Sand     = Color.FromArgb(240,237,232);   // content bg
        public static readonly Color White    = Color.White;
        public static readonly Color Border   = Color.FromArgb(221,221,221);
        public static readonly Color TextDark = Color.FromArgb(26, 26, 26);
        public static readonly Color Muted    = Color.FromArgb(110,105,100);
        public static readonly Color Green    = Color.FromArgb(22, 101, 52);   // badge-g
        public static readonly Color Amber    = Color.FromArgb(133, 79, 11);   // badge-a
        public static readonly Color Blue     = Color.FromArgb(24,  95, 165);  // badge-b
        public static readonly Color Red      = Color.FromArgb(185, 28,  28);  // badge-r
        public static readonly Color AlertBg  = Color.FromArgb(252,235,235);
        public static readonly Color AlertBdr = Color.FromArgb(240,149,149);
        public static readonly Color OkBg     = Color.FromArgb(225,245,238);
        public static readonly Color OkBdr    = Color.FromArgb(93, 202,165);

        // ── Fonts ─────────────────────────────────────────────────────────────
        public static Font FontTitle(float sz = 16f)  => new Font("Georgia",   sz,  FontStyle.Bold);
        public static Font FontSub(float sz = 9.5f)   => new Font("Segoe UI",  sz,  FontStyle.Regular);
        public static Font FontLabel(float sz = 7.5f) => new Font("Segoe UI",  sz,  FontStyle.Bold);
        public static Font FontBody(float sz = 9f)    => new Font("Segoe UI",  sz,  FontStyle.Regular);
        public static Font FontBold(float sz = 9f)    => new Font("Segoe UI",  sz,  FontStyle.Bold);

        // ── Rounded rectangle path ────────────────────────────────────────────
        public static GraphicsPath RoundRect(Rectangle r, int rad = 8)
        {
            var p = new GraphicsPath();
            p.AddArc(r.X,              r.Y,              rad*2, rad*2, 180, 90);
            p.AddArc(r.Right-rad*2,    r.Y,              rad*2, rad*2, 270, 90);
            p.AddArc(r.Right-rad*2,    r.Bottom-rad*2,   rad*2, rad*2,   0, 90);
            p.AddArc(r.X,              r.Bottom-rad*2,   rad*2, rad*2,  90, 90);
            p.CloseFigure();
            return p;
        }

        // ── Card panel (white, rounded, light border) ─────────────────────────
        public static Panel Card(int w, int h, int marginBottom = 12)
        {
            var c = new Panel
            {
                Size = new Size(w, h),
                BackColor = White,
                Margin = new Padding(0, 0, 0, marginBottom)
            };
            c.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var path = RoundRect(new Rectangle(0, 0, c.Width-1, c.Height-1), 8);
                e.Graphics.FillPath(new SolidBrush(White), path);
                e.Graphics.DrawPath(new Pen(Border, 0.5f), path);
            };
            return c;
        }

        // ── Card with internal header divider line ────────────────────────────
        public static Panel CardWithHeader(int w, int h, string title,
            int headerH = 38, int marginBottom = 12)
        {
            var card = Card(w, h, marginBottom);
            var lbl = new Label
            {
                Text      = title,
                Font      = FontBold(11f),
                ForeColor = TextDark,
                AutoSize  = true,
                Location  = new Point(14, (headerH - 18) / 2),
                BackColor = Color.Transparent
            };
            card.Controls.Add(lbl);

            // repaint adds the divider
            card.Paint += (s, e) =>
            {
                using var pen = new Pen(Color.FromArgb(238,238,238), 0.5f);
                e.Graphics.DrawLine(pen, 0, headerH, card.Width, headerH);
            };
            return card;
        }

        // ── KPI stat card ─────────────────────────────────────────────────────
        public static Panel StatCard(string number, string label, Color numColor, int w = 0)
        {
            var card = new Panel { BackColor = White, Size = new Size(w > 0 ? w : 160, 76) };
            card.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var path = RoundRect(new Rectangle(0, 0, card.Width-1, card.Height-1), 8);
                e.Graphics.FillPath(new SolidBrush(White), path);
                e.Graphics.DrawPath(new Pen(Border, 0.5f), path);
            };
            card.Controls.Add(new Label
            {
                Text      = number,
                Font      = FontTitle(20f),
                ForeColor = numColor,
                AutoSize  = true,
                Location  = new Point(12, 10),
                BackColor = Color.Transparent
            });
            card.Controls.Add(new Label
            {
                Text      = label,
                Font      = FontSub(8.5f),
                ForeColor = Muted,
                AutoSize  = true,
                Location  = new Point(12, 46),
                BackColor = Color.Transparent
            });
            return card;
        }

        // ── Alert / success banner ────────────────────────────────────────────
        public static Panel AlertBanner(string text, bool isAlert = true)
        {
            Color bg  = isAlert ? AlertBg  : OkBg;
            Color bdr = isAlert ? AlertBdr : OkBdr;
            Color fg  = isAlert ? Color.FromArgb(80,19,19) : Color.FromArgb(4,52,44);
            string icon = isAlert ? "⚠️" : "✅";

            var pnl = new Panel { BackColor = bg, Size = new Size(800, 36), Margin = new Padding(0,0,0,10) };
            pnl.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var path = RoundRect(new Rectangle(0,0,pnl.Width-1,pnl.Height-1), 6);
                e.Graphics.FillPath(new SolidBrush(bg), path);
                e.Graphics.DrawPath(new Pen(bdr, 1f), path);
            };
            pnl.Controls.Add(new Label
            {
                Text      = icon + "  " + text,
                Font      = FontBody(9f),
                ForeColor = fg,
                AutoSize  = true,
                Location  = new Point(10, 9),
                BackColor = Color.Transparent
            });
            return pnl;
        }

        // ── Page title + subtitle pair ────────────────────────────────────────
        public static Panel PageHeader(string title, string sub, int w)
        {
            var pnl = new Panel { Size = new Size(w, 52), BackColor = Color.Transparent, Margin = new Padding(0,0,0,12) };
            pnl.Controls.Add(new Label
            {
                Text      = title,
                Font      = FontTitle(16f),
                ForeColor = TextDark,
                AutoSize  = true,
                Location  = new Point(0, 0),
                BackColor = Color.Transparent
            });
            pnl.Controls.Add(new Label
            {
                Text      = sub,
                Font      = FontSub(9f),
                ForeColor = Muted,
                AutoSize  = true,
                Location  = new Point(1, 26),
                BackColor = Color.Transparent
            });
            return pnl;
        }

        // ── Section divider label ─────────────────────────────────────────────
        public static Label SectionDivider(string text, int y, int x = 0)
        {
            return new Label
            {
                Text      = text,
                Font      = FontBold(9.5f),
                ForeColor = Color.FromArgb(80,80,80),
                AutoSize  = true,
                Location  = new Point(x, y),
                BackColor = Color.Transparent
            };
        }

        // ── Badge label ───────────────────────────────────────────────────────
        public static Label Badge(string text, BadgeStyle style)
        {
            Color fg, bg;
            switch (style)
            {
                case BadgeStyle.Green:  fg = Color.FromArgb(8,80,65);   bg = Color.FromArgb(225,245,238); break;
                case BadgeStyle.Amber:  fg = Color.FromArgb(99,56,6);   bg = Color.FromArgb(250,238,218); break;
                case BadgeStyle.Blue:   fg = Color.FromArgb(12,68,124); bg = Color.FromArgb(230,241,251); break;
                case BadgeStyle.Red:    fg = Color.FromArgb(80,19,19);  bg = Color.FromArgb(252,235,235); break;
                case BadgeStyle.Gray:   fg = Color.FromArgb(68,68,65);  bg = Color.FromArgb(241,239,232); break;
                default: fg = TextDark; bg = Color.FromArgb(240,240,240); break;
            }
            var lbl = new Label
            {
                Text      = text,
                Font      = FontLabel(8f),
                ForeColor = fg,
                BackColor = bg,
                AutoSize  = false,
                Size      = new Size(TextRenderer.MeasureText(text, FontLabel(8f)).Width + 14, 18),
                TextAlign = ContentAlignment.MiddleCenter
            };
            lbl.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var path = RoundRect(new Rectangle(0,0,lbl.Width-1,lbl.Height-1), 9);
                e.Graphics.FillPath(new SolidBrush(bg), path);
                using var pen = new Pen(Color.FromArgb(30, fg), 0.8f);
                e.Graphics.DrawPath(pen, path);
                TextRenderer.DrawText(e.Graphics, text, FontLabel(8f), lbl.ClientRectangle, fg,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };
            return lbl;
        }

        // ── Primary button (forest bg, gold text) ─────────────────────────────
        public static Button BtnPrimary(string text, int w = 0, int h = 28)
        {
            var b = new Button
            {
                Text      = text,
                Font      = FontBold(9f),
                FlatStyle = FlatStyle.Flat,
                BackColor = Forest,
                ForeColor = Gold,
                Cursor    = Cursors.Hand,
                Size      = new Size(w > 0 ? w : 110, h)
            };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        // ── Outline button ────────────────────────────────────────────────────
        public static Button BtnOutline(string text, int w = 0, int h = 28)
        {
            var b = new Button
            {
                Text      = text,
                Font      = FontBody(9f),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.Transparent,
                ForeColor = TextDark,
                Cursor    = Cursors.Hand,
                Size      = new Size(w > 0 ? w : 80, h)
            };
            b.FlatAppearance.BorderColor = Border;
            b.FlatAppearance.BorderSize  = 1;
            return b;
        }

        // ── Small icon action button ──────────────────────────────────────────
        public static Button BtnAction(string text, ActionStyle style)
        {
            Color fg, bdr;
            switch (style)
            {
                case ActionStyle.Edit:   fg = Green; bdr = Green; break;
                case ActionStyle.Delete: fg = Red;   bdr = Red;   break;
                case ActionStyle.View:   fg = Blue;  bdr = Blue;  break;
                default: fg = TextDark; bdr = Border; break;
            }
            var b = new Button
            {
                Text      = text,
                Font      = FontBody(8f),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.Transparent,
                ForeColor = fg,
                Cursor    = Cursors.Hand,
                Size      = new Size(46, 22)
            };
            b.FlatAppearance.BorderColor = bdr;
            b.FlatAppearance.BorderSize  = 1;
            return b;
        }

        // ── Search bar TextBox ────────────────────────────────────────────────
        public static TextBox SearchBox(string placeholder, int w = 300)
        {
            return new TextBox
            {
                PlaceholderText = placeholder,
                Size            = new Size(w, 26),
                Font            = FontBody(9.5f),
                BorderStyle     = BorderStyle.FixedSingle
            };
        }

        // ── Table header row inside a card ────────────────────────────────────
        /// <summary>
        /// Adds column header labels to a parent panel at the given y offset.
        /// Returns y offset of first data row.
        /// </summary>
        public static int AddTableHeader(Panel parent, string[] cols, int[] widths, int yTop, int xLeft = 14)
        {
            int x = xLeft;
            for (int i = 0; i < cols.Length; i++)
            {
                parent.Controls.Add(new Label
                {
                    Text      = cols[i].ToUpper(),
                    Font      = FontLabel(7.5f),
                    ForeColor = Muted,
                    Location  = new Point(x, yTop + 5),
                    Size      = new Size(widths[i], 18),
                    BackColor = Color.FromArgb(248,248,248)
                });
                x += widths[i];
            }
            // header bottom line
            parent.Controls.Add(new Panel
            {
                Location  = new Point(0, yTop + 26),
                Size      = new Size(parent.Width, 1),
                BackColor = Color.FromArgb(238,238,238)
            });
            return yTop + 30;
        }

        // ── Row separator line ────────────────────────────────────────────────
        public static void AddRowSeparator(Panel parent, int y)
        {
            parent.Controls.Add(new Panel
            {
                Location  = new Point(0, y),
                Size      = new Size(parent.Width, 1),
                BackColor = Color.FromArgb(245,245,245)
            });
        }

        // ── Style a sidebar uniformly ─────────────────────────────────────────
        public static void StyleSidebar(Panel sidebar, Panel contentArea,
            Label lblTitle, Label lblRole, Label lblUser,
            Button[] navBtns, Button signOutBtn,
            ref Button activeBtn)
        {
            sidebar.BackColor = Forest;
            sidebar.Padding   = new Padding(0);

            sidebar.Paint += (s, e) =>
            {
                using var pen = new Pen(Color.FromArgb(28, 212, 160, 23), 1f);
                e.Graphics.DrawLine(pen, 14, 80, sidebar.Width - 14, 80);
                e.Graphics.DrawLine(pen, 14, sidebar.Height - 66,
                                    sidebar.Width - 14, sidebar.Height - 66);
            };

            // labels
            lblTitle.ForeColor = Cream;
            lblTitle.Font      = new Font("Georgia", 11f, FontStyle.Bold);
            lblTitle.BackColor = Color.Transparent;

            lblRole.ForeColor  = Gold;
            lblRole.Font       = FontSub(7.5f);
            lblRole.BackColor  = Color.Transparent;
            lblRole.AutoSize   = true;

            lblUser.ForeColor  = Color.FromArgb(90, 248, 244, 239);
            lblUser.Font       = FontSub(7.5f);
            lblUser.BackColor  = Color.Transparent;
            lblUser.AutoSize   = true;

            // nav buttons
            int yPos = 90;
            foreach (var btn in navBtns)
            {
                btn.FlatStyle = FlatStyle.Flat;
                btn.FlatAppearance.BorderSize = 0;
                btn.BackColor = Color.Transparent;
                btn.ForeColor = DimCream;
                btn.Font      = FontBody(9.5f);
                btn.TextAlign = ContentAlignment.MiddleLeft;
                btn.Padding   = new Padding(14, 0, 0, 0);
                btn.Cursor    = Cursors.Hand;
                btn.Size      = new Size(sidebar.Width - 28, 40);
                btn.Location  = new Point(14, yPos);

                var capturedBtn = btn;
                btn.MouseEnter += (s, e) =>
                {
                    if (!Equals(capturedBtn.Tag, "active"))
                        capturedBtn.BackColor = Color.FromArgb(15,212,160,23);
                };
                btn.MouseLeave += (s, e) =>
                {
                    if (!Equals(capturedBtn.Tag, "active"))
                        capturedBtn.BackColor = Color.Transparent;
                };
                btn.Paint += (s, pe) =>
                {
                    if (Equals(capturedBtn.Tag, "active"))
                    {
                        using var pen = new Pen(Gold, 2f);
                        pe.Graphics.DrawLine(pen, 0, 4, 0, capturedBtn.Height - 4);
                    }
                };

                yPos += 44;
            }

            // sign-out button
            signOutBtn.FlatStyle = FlatStyle.Flat;
            signOutBtn.FlatAppearance.BorderSize  = 1;
            signOutBtn.FlatAppearance.BorderColor = Color.FromArgb(40,226,75,74);
            signOutBtn.BackColor = Color.FromArgb(12,226,75,74);
            signOutBtn.ForeColor = Color.FromArgb(226,75,74);
            signOutBtn.Font      = FontBody(9f);
            signOutBtn.TextAlign = ContentAlignment.MiddleLeft;
            signOutBtn.Padding   = new Padding(14,0,0,0);
            signOutBtn.Cursor    = Cursors.Hand;
            signOutBtn.Size      = new Size(sidebar.Width - 28, 36);
            signOutBtn.Location  = new Point(14, sidebar.Height - 56);

            contentArea.BackColor = Sand;
        }

        // ── Activate a nav button ─────────────────────────────────────────────
        public static void SetActive(ref Button activeBtn, Button newBtn)
        {
            if (activeBtn != null)
            {
                activeBtn.Tag       = null;
                activeBtn.BackColor = Color.Transparent;
                activeBtn.ForeColor = DimCream;
                activeBtn.Invalidate();
            }
            activeBtn           = newBtn;
            activeBtn.Tag       = "active";
            activeBtn.BackColor = Color.FromArgb(30,212,160,23);
            activeBtn.ForeColor = Gold;
            activeBtn.Invalidate();
        }

        // ── Scrollable content wrapper ────────────────────────────────────────
        public static Panel ScrollWrapper()
        {
            return new Panel
            {
                Dock        = DockStyle.Fill,
                AutoScroll  = true,
                BackColor   = Sand,
                Padding     = new Padding(20)
            };
        }

        // ── FlowLayout column ─────────────────────────────────────────────────
        public static FlowLayoutPanel FlowColumn(int w)
        {
            return new FlowLayoutPanel
            {
                Width         = w,
                AutoSize      = true,
                FlowDirection = FlowDirection.TopDown,
                WrapContents  = false,
                BackColor     = Color.Transparent
            };
        }
    }

    public enum BadgeStyle  { Green, Amber, Blue, Red, Gray }
    public enum ActionStyle { Edit, Delete, View, Generic }
}
