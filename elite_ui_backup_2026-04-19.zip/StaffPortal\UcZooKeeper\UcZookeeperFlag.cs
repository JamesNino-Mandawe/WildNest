using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcZooKeeper
{
    public partial class UcZookeeperFlag : UserControl
    {
        public UcZookeeperFlag()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            Controls.Add(StaffPortalUi.BuildPage(
                "Flag Health Alert",
                "Prepared control endpoint for future health alerts.",
                new List<Control>
                {
                    StaffPortalUi.MessageCard(
                        "Health Alert Workflow Needs Animal Tables",
                        "To make this page transactional, the project needs tables for animals, health alerts, and encounter suspension rules. Right now the schema can support staff chat escalation, but not persistent animal alert tracking.",
                        alert: true)
                }));
        }
    }
}
