using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Project.UcAdministrator
{
    public class UcAdminDashboardContent : UserControl
    {
        public UcAdminDashboardContent()
        {
            Dock = DockStyle.Fill;
            BackColor = WildNestUI.Sand;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            int cabinsAvailable = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_cabins WHERE Status = 'Available';");
            int activeReservations = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_reservations WHERE Status IN ('Confirmed','Checked-In');");
            decimal collected = StaffPortalDb.Sum("SELECT COALESCE(SUM(Amount),0) FROM tbl_payments WHERE Status IN ('Paid','Completed','Settled');");
            int activeUsers = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_users WHERE IsActive = 1;");

            var reservations = StaffPortalDb.GetTable(@"
SELECT r.ReservationID AS `Reservation Ref`,
       CONCAT(g.FirstName, ' ', g.LastName) AS `Guest`,
       COALESCE(c.CabinName, 'No Cabin / Visit Booking') AS `Cabin`,
       COALESCE(DATE_FORMAT(r.CheckInDate, '%Y-%m-%d'), DATE_FORMAT(r.VisitDate, '%Y-%m-%d')) AS `Start`,
       DATE_FORMAT(r.CheckOutDate, '%Y-%m-%d') AS `End`,
       r.BookingType AS `Type`,
       r.Status,
       r.TotalAmount AS `Total Amount`
FROM tbl_reservations r
LEFT JOIN tbl_guests g ON g.GuestID = r.GuestID
LEFT JOIN tbl_cabins c ON c.CabinID = r.CabinID
ORDER BY r.CreatedAt DESC
LIMIT 12;");

            var sections = new List<Control>
            {
                WildNestUI.AlertBanner(
                    "Administrator dashboard is now reading directly from cabins, reservations, guests, payments, and users.",
                    isAlert: false),
                StaffPortalUi.StatsRow(
                    (cabinsAvailable.ToString(), "Cabins Available", WildNestUI.Green),
                    (activeReservations.ToString(), "Active Reservations", WildNestUI.Blue),
                    (StaffPortalUi.Peso(collected), "Collected Payments", WildNestUI.Amber),
                    (activeUsers.ToString(), "Active Staff Users", WildNestUI.Green)),
                StaffPortalUi.GridCard("Recent Reservation Activity", reservations, "No reservation records found yet.")
            };

            var page = StaffPortalUi.BuildPage(
                "Operations Dashboard",
                $"Live admin overview from wildnest_db — {DateTime.Now:MMMM d, yyyy}",
                sections);

            Controls.Add(page);
        }
    }
}
