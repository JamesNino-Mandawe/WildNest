using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcTourGuide
{
    public partial class UcTourGuideGroups : UserControl
    {
        public UcTourGuideGroups()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            int upcomingGroups = StaffPortalDb.Count(@"
SELECT COUNT(DISTINCT be.ReservationID)
FROM tbl_bookingexperiences be
JOIN tbl_reservations r ON r.ReservationID = be.ReservationID
WHERE COALESCE(r.VisitDate, r.CheckInDate) >= CURDATE();");
            int guestsUpcoming = StaffPortalDb.Count(@"
SELECT COALESCE(SUM(be.Quantity),0)
FROM tbl_bookingexperiences be
JOIN tbl_reservations r ON r.ReservationID = be.ReservationID
WHERE COALESCE(r.VisitDate, r.CheckInDate) >= CURDATE();");
            int packages = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_experiences;");
            int confirmed = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_reservations WHERE Status = 'Confirmed';");

            var groups = StaffPortalDb.GetTable(@"
SELECT r.ReservationID AS `Reservation Ref`,
       CONCAT(g.FirstName, ' ', g.LastName) AS `Lead Guest`,
       GROUP_CONCAT(e.ExperienceName SEPARATOR ', ') AS `Experience Lineup`,
       SUM(be.Quantity) AS `Attendees`,
       COALESCE(DATE_FORMAT(r.VisitDate, '%Y-%m-%d'), DATE_FORMAT(r.CheckInDate, '%Y-%m-%d')) AS `Scheduled Date`,
       r.Status
FROM tbl_bookingexperiences be
JOIN tbl_reservations r ON r.ReservationID = be.ReservationID
JOIN tbl_guests g ON g.GuestID = r.GuestID
JOIN tbl_experiences e ON e.ExperienceID = be.ExperienceID
GROUP BY r.ReservationID, g.FirstName, g.LastName, r.VisitDate, r.CheckInDate, r.Status
ORDER BY `Scheduled Date`, `Lead Guest`;");

            Controls.Add(StaffPortalUi.BuildPage(
                "My Tour Groups",
                "Grouped guest manifests built from experience bookings and reservations.",
                new List<Control>
                {
                    StaffPortalUi.StatsRow(
                        (upcomingGroups.ToString(), "Upcoming Groups", WildNestUI.Green),
                        (guestsUpcoming.ToString(), "Guests Upcoming", WildNestUI.Blue),
                        (packages.ToString(), "Active Packages", WildNestUI.Amber),
                        (confirmed.ToString(), "Confirmed Reservations", WildNestUI.Green)),
                    StaffPortalUi.GridCard("Grouped Experience Guests", groups)
                }));
        }
    }
}
