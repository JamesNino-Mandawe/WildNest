using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcZooKeeper
{
    public partial class UcZookeeperLog : UserControl
    {
        public UcZookeeperLog()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            var users = StaffPortalDb.GetTable(@"
SELECT FullName AS `Staff`,
       Role,
       ContactNo AS `Contact`,
       CASE WHEN IsActive = 1 THEN 'Active' ELSE 'Inactive' END AS `Status`
FROM tbl_users
WHERE Role LIKE '%Zoo%' OR Role LIKE '%Administrator%'
ORDER BY Role, FullName;");

            Controls.Add(StaffPortalUi.BuildPage(
                "Daily Log",
                "Current schema has no zookeeper log table yet, so this page tracks the relevant staff endpoints currently available.",
                new List<Control>
                {
                    StaffPortalUi.MessageCard(
                        "Daily Log Table Not Yet Present",
                        "Add a daily wildlife log table later if you want keepers to persist notes, observations, and incident records. Until then, this page documents the currently active zoo/admin staff endpoints.",
                        alert: true),
                    StaffPortalUi.GridCard("Available Wildlife Operations Staff", users)
                }));
        }
    }
}
