using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcAdministrator
{
    public partial class UcAdminBills : UserControl
    {
        public UcAdminBills()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            decimal collected = StaffPortalDb.Sum("SELECT COALESCE(SUM(Amount),0) FROM tbl_payments WHERE Status IN ('Paid','Completed','Settled');");
            int pendingPayments = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_payments WHERE Status IN ('Pending','Unpaid');");
            int paymentRecords = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_payments;");
            int unpaidReservations = StaffPortalDb.Count(@"
SELECT COUNT(*)
FROM tbl_reservations r
LEFT JOIN tbl_payments p ON p.ReservationID = r.ReservationID
WHERE p.PaymentID IS NULL OR p.Status IN ('Pending','Unpaid');");

            var payments = StaffPortalDb.GetTable(@"
SELECT p.PaymentID AS `Payment ID`,
       p.ReservationID AS `Reservation Ref`,
       CONCAT(g.FirstName, ' ', g.LastName) AS `Guest`,
       p.Amount,
       p.PaymentMethod AS `Payment Method`,
       p.Status,
       DATE_FORMAT(p.PaidAt, '%Y-%m-%d %H:%i') AS `Paid At`
FROM tbl_payments p
LEFT JOIN tbl_reservations r ON r.ReservationID = p.ReservationID
LEFT JOIN tbl_guests g ON g.GuestID = r.GuestID
ORDER BY p.PaidAt DESC, p.PaymentID DESC;");

            var page = StaffPortalUi.BuildPage(
                "Billing & Reports",
                "Payment tracking from tbl_payments tied to live reservation records.",
                new List<Control>
                {
                    StaffPortalUi.StatsRow(
                        (paymentRecords.ToString(), "Payment Records", WildNestUI.Blue),
                        (StaffPortalUi.Peso(collected), "Collected", WildNestUI.Green),
                        (pendingPayments.ToString(), "Pending / Unpaid", WildNestUI.Amber),
                        (unpaidReservations.ToString(), "Reservations Requiring Follow-up", WildNestUI.Red)),
                    StaffPortalUi.GridCard("Payment Ledger", payments, "No payment records found yet.")
                });

            Controls.Add(page);
        }
    }
}
