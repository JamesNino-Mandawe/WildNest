using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using MimeKit;
using MailKit.Net.Smtp;
using MailKit.Security;
using QRCoder;

namespace Project.Accomodations
{
    /// <summary>
    /// Sends booking confirmation emails with QR code attached.
    /// Uses MailKit + QRCoder NuGet packages.
    ///
    /// SMTP SETUP — Edit the constants below to match your email provider:
    ///   Gmail  : host=smtp.gmail.com, port=587, use an App Password (not your real password)
    ///            (Google Account → Security → 2FA → App Passwords)
    ///   Outlook: host=smtp.office365.com, port=587
    ///   Yahoo  : host=smtp.mail.yahoo.com, port=587
    /// </summary>
    public static class EmailService
    {
        // ── SMTP credentials — CHANGE THESE ──────────────────────────
        const string SMTP_HOST     = "smtp.gmail.com";
        const int    SMTP_PORT     = 587;
        const string SMTP_USER = "zoowildnest@gmail.com";
        const string SMTP_PASS = "vwdiyofzqrxetkoh";
        const string SENDER_NAME   = "WildNest Zoo Resort";
        // ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Generates a QR code bitmap encoding the booking ID.
        /// This is the SINGLE source of truth — same bitmap used on-screen and in email.
        /// </summary>
        public static Bitmap GenerateQrBitmap(string bookingId)
        {
            using var qrGenerator = new QRCodeGenerator();
            using var qrData      = qrGenerator.CreateQrCode(bookingId, QRCodeGenerator.ECCLevel.Q);
            using var qrCode      = new QRCode(qrData);
            return qrCode.GetGraphic(6, Color.Black, Color.White, true);
        }

        /// <summary>
        /// Sends booking confirmation email with QR PNG attached.
        /// Call this right after ConfirmBooking() succeeds.
        /// </summary>
        public static void SendConfirmation(
            string toEmail,
            string guestName,
            string bookingId,
            string bookingType,
            string dateInfo,
            decimal totalAmount,
            string paymentMethod,
            Bitmap qrBitmap)
        {
            try
            {
                // Convert bitmap to bytes
                byte[] qrBytes;
                using (var ms = new MemoryStream())
                {
                    qrBitmap.Save(ms, ImageFormat.Png);
                    qrBytes = ms.ToArray();
                }

                var message = new MimeMessage();
                message.From.Add(new MailboxAddress(SENDER_NAME, SMTP_USER));
                message.To.Add(new MailboxAddress(guestName, toEmail));
                message.Subject = $"WildNest Booking Confirmed — {bookingId}";

                // Build email body
                var builder = new BodyBuilder();

                builder.HtmlBody = $@"
<!DOCTYPE html>
<html>
<head><meta charset='utf-8'></head>
<body style='margin:0;padding:0;background:#f4f4f4;font-family:Segoe UI,Arial,sans-serif;'>
  <table width='100%' cellpadding='0' cellspacing='0' style='background:#f4f4f4;padding:30px 0;'>
    <tr><td align='center'>
      <table width='520' cellpadding='0' cellspacing='0' style='background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.1);'>

        <!-- Header -->
        <tr>
          <td style='background:#071a0e;padding:32px 40px;text-align:center;'>
            <div style='font-size:28px;font-weight:bold;color:#d4a017;letter-spacing:3px;'>🦁 WILDNEST</div>
            <div style='color:#8fb89a;font-size:13px;margin-top:6px;'>Zoo Resort &amp; Wildlife Experience · Carmen, Cebu</div>
          </td>
        </tr>

        <!-- Success badge -->
        <tr>
          <td style='background:#e8f5e9;padding:20px 40px;text-align:center;border-bottom:1px solid #c8e6c9;'>
            <div style='font-size:36px;'>✅</div>
            <div style='font-size:20px;font-weight:bold;color:#1b5e20;margin-top:8px;'>Booking Confirmed!</div>
            <div style='color:#388e3c;font-size:13px;margin-top:4px;'>Your reservation has been successfully processed.</div>
          </td>
        </tr>

        <!-- Booking details -->
        <tr>
          <td style='padding:30px 40px;'>
            <p style='color:#333;font-size:15px;'>Dear <strong>{guestName}</strong>,</p>
            <p style='color:#555;font-size:14px;line-height:1.6;'>
              Thank you for choosing WildNest! Your booking is confirmed. 
              Please find your Booking ID and QR Code below — you'll need these to access the Guest Portal.
            </p>

            <!-- Booking ID box -->
            <table width='100%' cellpadding='0' cellspacing='0' style='background:#071a0e;border-radius:10px;margin:20px 0;'>
              <tr>
                <td style='padding:18px 24px;'>
                  <div style='color:rgba(248,244,239,0.5);font-size:11px;font-weight:bold;letter-spacing:2px;'>YOUR BOOKING ID</div>
                  <div style='color:#d4a017;font-size:24px;font-weight:bold;font-family:Georgia,serif;margin-top:4px;'>{bookingId}</div>
                </td>
              </tr>
            </table>

            <!-- Details table -->
            <table width='100%' cellpadding='8' cellspacing='0' style='border:1px solid #e0e0e0;border-radius:8px;font-size:13px;'>
              <tr style='background:#f9f9f9;'>
                <td style='color:#888;font-weight:bold;padding:10px 16px;width:40%;'>Booking Type</td>
                <td style='color:#333;padding:10px 16px;'>{bookingType}</td>
              </tr>
              <tr>
                <td style='color:#888;font-weight:bold;padding:10px 16px;'>Date</td>
                <td style='color:#333;padding:10px 16px;'>{dateInfo}</td>
              </tr>
              <tr style='background:#f9f9f9;'>
                <td style='color:#888;font-weight:bold;padding:10px 16px;'>Total Amount</td>
                <td style='color:#333;font-weight:bold;padding:10px 16px;'>₱{totalAmount:N2}</td>
              </tr>
              <tr>
                <td style='color:#888;font-weight:bold;padding:10px 16px;'>Payment Method</td>
                <td style='color:#333;padding:10px 16px;'>{paymentMethod}</td>
              </tr>
            </table>

            <!-- QR section -->
            <div style='text-align:center;margin:28px 0 16px;'>
              <div style='font-size:13px;color:#555;margin-bottom:12px;'>
                📱 <strong>Your QR Code</strong> — Scan this at the accommodation terminal or use it to log in to the Guest Portal
              </div>
              <img src='cid:qrcode' width='180' height='180' style='border:1px solid #ddd;border-radius:8px;padding:8px;background:#fff;' alt='QR Code'/>
              <div style='font-size:11px;color:#999;margin-top:8px;'>QR Code for Booking {bookingId}</div>
            </div>

            <!-- How to use -->
            <div style='background:#f0f7ff;border-left:4px solid #1565c0;border-radius:6px;padding:14px 18px;margin:20px 0;font-size:13px;color:#1a237e;'>
              <strong>How to access your Guest Portal:</strong><br/>
              Option 1 — Enter your Booking ID <strong>{bookingId}</strong> + this email address<br/>
              Option 2 — Scan the QR code attached above
            </div>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style='background:#071a0e;padding:20px 40px;text-align:center;'>
            <div style='color:#8fb89a;font-size:12px;'>WildNest Zoo Resort · Carmen, Cebu, Philippines</div>
            <div style='color:#4a6741;font-size:11px;margin-top:4px;'>This is an automated confirmation email.</div>
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>";

                // Attach QR as inline image (cid:qrcode) + as downloadable attachment
                var qrStream = new MemoryStream(qrBytes);
                var inlineImg = builder.LinkedResources.Add("qrcode.png", qrStream, new ContentType("image", "png"));
                inlineImg.ContentId = "qrcode";
                inlineImg.ContentDisposition = new ContentDisposition(ContentDisposition.Inline);

                // Also add as regular attachment so guest can save it
                var attachStream = new MemoryStream(qrBytes);
                builder.Attachments.Add($"WildNest_QR_{bookingId}.png", attachStream, new ContentType("image", "png"));

                message.Body = builder.ToMessageBody();

                // Send
                using var client = new SmtpClient();
                client.Connect(SMTP_HOST, SMTP_PORT, SecureSocketOptions.StartTls);
                client.Authenticate(SMTP_USER, SMTP_PASS);
                client.Send(message);
                client.Disconnect(true);
            }
            catch (Exception ex)
            {
                // Don't crash the booking if email fails — just log it
                System.Diagnostics.Debug.WriteLine($"[EmailService] Failed to send: {ex.Message}");
            }
        }
    }
}
