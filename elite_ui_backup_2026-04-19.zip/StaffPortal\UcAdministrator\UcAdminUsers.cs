using System.Collections.Generic;
using System.Windows.Forms;

namespace Project.UcAdministrator
{
    public partial class UcAdminUsers : UserControl
    {
        public UcAdminUsers()
        {
            Dock = DockStyle.Fill;
            Load += (s, e) => Render();
        }

        private void Render()
        {
            Controls.Clear();

            int totalUsers = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_users;");
            int activeUsers = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_users WHERE IsActive = 1;");
            int receptionUsers = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_users WHERE Role LIKE '%Reception%';");
            int fieldOpsUsers = StaffPortalDb.Count("SELECT COUNT(*) FROM tbl_users WHERE Role LIKE '%Tour%' OR Role LIKE '%Zoo%';");

            var users = StaffPortalDb.GetTable(@"
SELECT UserID AS `User ID`,
       FullName AS `Full Name`,
       Username,
       Role,
       ContactNo AS `Contact No.`,
       CASE WHEN IsActive = 1 THEN 'Active' ELSE 'Inactive' END AS `Status`
FROM tbl_users
ORDER BY FullName;");

            var page = StaffPortalUi.BuildPage(
                "User Management",
                "Staff account directory from tbl_users.",
                new List<Control>
                {
                    StaffPortalUi.StatsRow(
                        (totalUsers.ToString(), "Total Accounts", WildNestUI.Blue),
                        (activeUsers.ToString(), "Active Accounts", WildNestUI.Green),
                        (receptionUsers.ToString(), "Reception Staff", WildNestUI.Amber),
                        (fieldOpsUsers.ToString(), "Tour + Zoo Operations", WildNestUI.Green)),
                    StaffPortalUi.GridCard("User Accounts", users)
                });

            Controls.Add(page);
        }
    }
}
