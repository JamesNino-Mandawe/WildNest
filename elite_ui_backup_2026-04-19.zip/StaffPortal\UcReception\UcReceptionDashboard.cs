using Project.StaffPortal.UcReception;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Project.UcReception
{
    /// <summary>
    /// Reception / Front Desk shell dashboard.
    /// Sidebar mirrors prototype fd nav (7 items + Guest Chat + Staff Chat).
    /// Both chat channels are clearly separated and independently functional.
    /// </summary>
    public partial class UcReceptionDashboard : UserControl
    {
        private StaffDashboard _parent;
        private Button         _activeBtn;
        private Button         _btnNavGuestChat  = null!;
        private Button         _btnNavStaffChat  = null!;
        private string         _displayName      = "Reception";

        public UcReceptionDashboard()
        {
            InitializeComponent();
            this.Load += OnLoad;
        }

        // ── Public API ────────────────────────────────────────────────────────
        public void SetParentDashboard(StaffDashboard parent) => _parent = parent;

        public void SetDisplayName(string name)
        {
            _displayName     = name;
            lblSideUser.Text = name;
            lblSideRole.Text = "Front Desk Operations";
        }

        // ── Load ──────────────────────────────────────────────────────────────
        private void OnLoad(object sender, EventArgs e)
        {
            BuildSidebar();
            WireNavButtons();
            WildNestUI.SetActive(ref _activeBtn, btnNavDashboard);
            LoadPage(new UcReceptionDashboardContent());
        }

        // ── Sidebar ───────────────────────────────────────────────────────────
        private void BuildSidebar()
        {
            // Guest chat button (already existed)
            _btnNavGuestChat = new Button { Text = "💬  Guest Chat",  Name = "btnNavGuestChat" };
            // Staff chat button (new — internal messaging)
            _btnNavStaffChat = new Button { Text = "🔒  Staff Chat",  Name = "btnNavStaffChat" };

            pnlReceptionSidebar.Controls.Add(_btnNavGuestChat);
            pnlReceptionSidebar.Controls.Add(_btnNavStaffChat);

            Button[] navBtns =
            {
                btnNavDashboard, btnNavNewBooking, btnNavCheckIn,
                btnNavCheckOut,  btnNavGuests,     btnNavCabins,
                btnNavEncounters, _btnNavGuestChat, _btnNavStaffChat
            };

            WildNestUI.StyleSidebar(
                pnlReceptionSidebar, pnlReceptionContent,
                lblSideTitle, lblSideRole, lblSideUser,
                navBtns, btnSignOut,
                ref _activeBtn);

            btnNavDashboard.Text   = "🏠  My Dashboard";
            btnNavNewBooking.Text  = "📅  New Booking";
            btnNavCheckIn.Text     = "✅  Check-In";
            btnNavCheckOut.Text    = "🚪  Check-Out & Billing";
            btnNavGuests.Text      = "👤  Guest Profiles";
            btnNavCabins.Text      = "🏡  Cabin Availability";
            btnNavEncounters.Text  = "🎯  Book Encounter";
            _btnNavGuestChat.Text  = "💬  Guest Chat";
            _btnNavStaffChat.Text  = "🔒  Staff Chat";
        }

        // ── Navigation ────────────────────────────────────────────────────────
        private void WireNavButtons()
        {
            btnNavDashboard.Click    += (s, e) => Navigate(btnNavDashboard,  new UcReceptionDashboardContent());
            btnNavNewBooking.Click   += (s, e) => Navigate(btnNavNewBooking, new UcReceptionNewBooking());
            btnNavCheckIn.Click      += (s, e) => Navigate(btnNavCheckIn,    new UcReceptionCheckIn());
            btnNavCheckOut.Click     += (s, e) => Navigate(btnNavCheckOut,   new UcReceptionCheckOut());
            btnNavGuests.Click       += (s, e) => Navigate(btnNavGuests,     new UcReceptionGuests());
            btnNavCabins.Click       += (s, e) => Navigate(btnNavCabins,     new UcReceptionCabins());
            btnNavEncounters.Click   += (s, e) => Navigate(btnNavEncounters, new UcReceptionEncounters());
            btnSignOut.Click         += (s, e) => _parent?.SignOut();

            // Guest chat — existing guest ↔ reception channel
            _btnNavGuestChat.Click   += (s, e) => Navigate(_btnNavGuestChat, new UcReceptionChat());

            // Staff chat — internal reception ↔ administrator channel
            _btnNavStaffChat.Click   += (s, e) => Navigate(_btnNavStaffChat,
                new Project.UcStaffChat("Reception", _displayName));
        }

        // ── Helpers ───────────────────────────────────────────────────────────
        private void Navigate(Button btn, UserControl uc)
        {
            WildNestUI.SetActive(ref _activeBtn, btn);
            LoadPage(uc);
        }

        private void LoadPage(UserControl uc)
        {
            pnlReceptionContent.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            pnlReceptionContent.Controls.Add(uc);
            uc.BringToFront();
        }
    }
}
